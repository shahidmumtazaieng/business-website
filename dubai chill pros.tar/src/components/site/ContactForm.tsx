"use client";

import { useState } from "react";
import { Send, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export function ContactForm() {
  const [status, setStatus] = useState<"idle" | "submitting" | "done">("idle");

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus("submitting");
    // Simulated submit — no backend endpoint needed for static demo.
    await new Promise((r) => setTimeout(r, 900));
    setStatus("done");
    toast.success("Thanks! We'll call you back within 15 minutes.");
    (e.currentTarget as HTMLFormElement).reset();
    setTimeout(() => setStatus("idle"), 4000);
  };

  return (
    <form onSubmit={handleSubmit} className="mt-6 space-y-4">
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="Your name" name="name" type="text" placeholder="e.g. Ahmed Khan" required />
        <Field label="Phone number" name="phone" type="tel" placeholder="+971 5X XXX XXXX" required />
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <SelectField
          label="Service needed"
          name="service"
          required
          options={[
            "AC Repair",
            "AC Installation",
            "AC Maintenance / AMC",
            "Electrical Repair",
            "Electrical Installation",
            "Emergency Service",
            "Other / Not sure",
          ]}
        />
        <SelectField
          label="Area in Dubai"
          name="area"
          required
          options={[
            "Jumeirah Lakes Towers",
            "Dubai Marina",
            "Downtown Dubai",
            "Jumeirah",
            "Palm Jumeirah",
            "Business Bay",
            "Arabian Ranches",
            "Dubai Hills Estate",
            "Other Dubai area",
          ]}
        />
      </div>
      <div>
        <label
          htmlFor="message"
          className="block text-xs font-bold text-navy uppercase tracking-wider mb-1.5"
        >
          Describe the issue
        </label>
        <textarea
          id="message"
          name="message"
          rows={4}
          placeholder="e.g. My split AC is blowing warm air and dripping water since last night..."
          className="w-full rounded-xl border border-border bg-muted/30 px-4 py-3 text-sm placeholder:text-muted-foreground/70 focus:outline-none focus:border-ice focus:ring-2 focus:ring-ice/30 transition-colors resize-none"
        />
      </div>

      <button
        type="submit"
        disabled={status !== "idle"}
        className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-amber hover:bg-amber-dark disabled:opacity-70 text-navy px-6 py-4 text-base font-bold shadow-amber-glow transition-all hover:-translate-y-0.5 disabled:translate-y-0"
      >
        {status === "submitting" ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            Sending...
          </>
        ) : status === "done" ? (
          <>
            <CheckCircle2 className="w-5 h-5" />
            Request sent!
          </>
        ) : (
          <>
            <Send className="w-5 h-5" />
            Get my free callback
          </>
        )}
      </button>
      <p className="text-center text-xs text-muted-foreground">
        By submitting, you agree to be contacted by Dubai Chill Pros about your
        service request. No spam, ever.
      </p>
    </form>
  );
}

function Field({
  label,
  name,
  type,
  placeholder,
  required,
}: {
  label: string;
  name: string;
  type: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label
        htmlFor={name}
        className="block text-xs font-bold text-navy uppercase tracking-wider mb-1.5"
      >
        {label} {required && <span className="text-amber-dark">*</span>}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        placeholder={placeholder}
        className="w-full rounded-xl border border-border bg-muted/30 px-4 py-3 text-sm placeholder:text-muted-foreground/70 focus:outline-none focus:border-ice focus:ring-2 focus:ring-ice/30 transition-colors"
      />
    </div>
  );
}

function SelectField({
  label,
  name,
  required,
  options,
}: {
  label: string;
  name: string;
  required?: boolean;
  options: string[];
}) {
  return (
    <div>
      <label
        htmlFor={name}
        className="block text-xs font-bold text-navy uppercase tracking-wider mb-1.5"
      >
        {label} {required && <span className="text-amber-dark">*</span>}
      </label>
      <select
        id={name}
        name={name}
        required={required}
        defaultValue=""
        className="w-full rounded-xl border border-border bg-muted/30 px-4 py-3 text-sm focus:outline-none focus:border-ice focus:ring-2 focus:ring-ice/30 transition-colors appearance-none bg-[length:1rem] bg-[right_0.75rem_center] bg-no-repeat"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%234A5C70' stroke-width='2.5'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7'/%3E%3C/svg%3E\")",
        }}
      >
        <option value="" disabled>
          Select...
        </option>
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
    </div>
  );
}
