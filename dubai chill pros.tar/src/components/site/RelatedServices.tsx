import Link from "next/link";
import { ArrowRight, Check } from "lucide-react";
import { SERVICES, type ServiceSummary } from "@/lib/site-data";
import { Reveal } from "@/components/site/Reveal";
import { cn } from "@/lib/utils";

const ICON_MAP = {
  ac: "❄️",
  install: "💨",
  maintenance: "🛠️",
  electric: "⚡",
  wiring: "🔌",
  emergency: "🚨",
} as const;

/**
 * "Related Services" sidebar — internal links to sibling service pages.
 * Powers the SILO structure on each service detail page.
 */
export function RelatedServices({
  currentSlug,
  relatedSlugs,
}: {
  currentSlug: string;
  relatedSlugs: string[];
}) {
  const related = relatedSlugs
    .map((slug) => SERVICES.find((s) => s.slug === slug))
    .filter(Boolean) as ServiceSummary[];

  if (related.length === 0) return null;

  return (
    <Reveal>
      <div className="rounded-2xl bg-white border border-border shadow-brand-sm p-6">
        <p className="text-xs font-bold uppercase tracking-[0.12em] text-ice-dark mb-4">
          Related Services
        </p>
        <ul className="space-y-2.5">
          {related.map((s) => (
            <li key={s.url}>
              <Link
                href={s.url}
                className="group flex items-start gap-3 rounded-xl p-3 hover:bg-ice/8 transition-colors"
              >
                <span className="text-base leading-none mt-0.5" aria-hidden>
                  {ICON_MAP[s.icon]}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-navy group-hover:text-ice-dark transition-colors leading-tight">
                    {s.title}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                    {s.short}
                  </p>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-muted-foreground group-hover:text-ice-dark group-hover:translate-x-0.5 transition-all flex-shrink-0 mt-1" />
              </Link>
            </li>
          ))}
        </ul>
        <Link
          href="/services"
          className="mt-4 inline-flex items-center justify-center w-full gap-1.5 rounded-lg border border-border hover:border-ice hover:bg-ice/8 px-4 py-2.5 text-xs font-bold text-navy hover:text-ice-dark transition-colors"
        >
          View all services
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </Reveal>
  );
}

/**
 * Full services grid — used on /services hub page and on home page.
 */
export function ServicesGrid({ excludeSlug }: { excludeSlug?: string }) {
  const items = excludeSlug
    ? SERVICES.filter((s) => s.slug !== excludeSlug)
    : SERVICES;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
      {items.map((service, idx) => (
        <Reveal key={service.url} delay={idx * 60}>
          <Link
            href={service.url}
            className={cn(
              "group relative h-full rounded-2xl bg-white border p-6 md:p-7 transition-all duration-300 hover:-translate-y-1.5 block",
              service.popular
                ? "border-ice/30 shadow-brand-md hover:shadow-ice-glow"
                : "border-border shadow-brand-sm hover:shadow-brand-md hover:border-ice/40"
            )}
          >
            {service.popular && (
              <span className="absolute top-5 right-5 inline-flex items-center gap-1 rounded-full bg-amber/15 text-amber-dark px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider">
                Popular
              </span>
            )}
            <div className="w-14 h-14 rounded-xl flex items-center justify-center mb-5 bg-ice/12 text-ice-dark group-hover:bg-ice group-hover:text-white transition-colors text-2xl">
              <span aria-hidden>{ICON_MAP[service.icon]}</span>
            </div>
            <h3 className="font-display font-bold text-navy text-xl md:text-[1.4rem] leading-tight">
              {service.title}
            </h3>
            <p className="mt-1.5 text-sm font-semibold text-ice-dark">
              {service.short}
            </p>
            <p className="mt-3 text-sm text-muted-foreground leading-relaxed line-clamp-3">
              {service.description}
            </p>
            <ul className="mt-4 space-y-2">
              {service.bullets.slice(0, 3).map((b) => (
                <li key={b} className="flex items-start gap-2 text-xs">
                  <span className="mt-0.5 flex-shrink-0 w-3.5 h-3.5 rounded-full bg-ice/15 flex items-center justify-center">
                    <Check className="w-2.5 h-2.5 text-ice-dark" />
                  </span>
                  <span className="text-foreground/80">{b}</span>
                </li>
              ))}
            </ul>
            <div className="mt-5 pt-4 border-t border-border flex items-center gap-1.5 text-sm font-bold text-ice-dark group-hover:gap-2.5 transition-all">
              Learn more
              <ArrowRight className="w-4 h-4" />
            </div>
          </Link>
        </Reveal>
      ))}
    </div>
  );
}
