"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import {
  Menu,
  X,
  Phone,
  MessageCircle,
  ChevronDown,
  Snowflake,
  AirVent,
  Wind,
  Zap,
  Cable,
  Siren,
  ArrowRight,
} from "lucide-react";
import { BUSINESS, NAV, SERVICES } from "@/lib/site-data";
import { cn } from "@/lib/utils";

const ICON_MAP = {
  ac: Snowflake,
  install: AirVent,
  maintenance: Wind,
  electric: Zap,
  wiring: Cable,
  emergency: Siren,
} as const;

export function Header() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false);

  // Detect if current page has a dark hero (home + service pages) → header starts transparent.
  const isHome = pathname === "/";
  const transparentOnTop = isHome;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = drawerOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [drawerOpen]);

  // Close drawer/menu on route change (via pathname effect).
  // We use a single effect that listens for pathname changes and resets UI state.
  // This is the standard pattern for syncing nav UI with router state.
  useEffect(() => {
    setDrawerOpen(false);
    setServicesOpen(false);
    setMobileServicesOpen(false);
    // We intentionally read state here only to close menus on navigation.
  }, [pathname]);

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  const solidHeader = scrolled || !transparentOnTop;

  return (
    <>
      <header
        className={cn(
          "fixed top-0 inset-x-0 z-50 transition-all duration-300",
          solidHeader
            ? "bg-white/95 backdrop-blur-md border-b border-border shadow-brand-sm"
            : "bg-transparent"
        )}
      >
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="flex h-16 md:h-20 items-center justify-between gap-4">
            {/* Logo */}
            <Link
              href="/"
              className="flex items-center gap-3 group flex-shrink-0"
              aria-label={`${BUSINESS.name} home`}
            >
              <LogoMark className="w-10 h-10 md:w-11 md:h-11 transition-transform group-hover:scale-105" />
              <span
                className={cn(
                  "font-display font-extrabold text-base md:text-lg leading-tight transition-colors whitespace-nowrap",
                  solidHeader ? "text-navy" : "text-white"
                )}
              >
                Dubai Chill
                <span className="text-ice"> Pros</span>
              </span>
            </Link>

            {/* Desktop nav */}
            <nav
              className="hidden lg:flex items-center gap-1 xl:gap-2"
              aria-label="Primary"
            >
              {NAV.map((link) => {
                const active = isActive(link.href);
                if (link.children) {
                  return (
                    <div
                      key={link.href}
                      className="relative"
                      onMouseEnter={() => setServicesOpen(true)}
                      onMouseLeave={() => setServicesOpen(false)}
                    >
                      <Link
                        href={link.href}
                        className={cn(
                          "inline-flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-semibold transition-colors",
                          active || servicesOpen
                            ? solidHeader
                              ? "text-ice-dark bg-ice/8"
                              : "text-white bg-white/10"
                            : solidHeader
                              ? "text-navy hover:text-ice-dark hover:bg-ice/8"
                              : "text-white/90 hover:text-white hover:bg-white/10"
                        )}
                        aria-expanded={servicesOpen}
                      >
                        {link.label}
                        <ChevronDown
                          className={cn(
                            "w-3.5 h-3.5 transition-transform",
                            servicesOpen && "rotate-180"
                          )}
                        />
                      </Link>

                      {/* Dropdown */}
                      <div
                        className={cn(
                          "absolute left-0 top-full pt-2 w-[34rem] transition-all duration-200",
                          servicesOpen
                            ? "opacity-100 translate-y-0 pointer-events-auto"
                            : "opacity-0 -translate-y-1 pointer-events-none"
                        )}
                      >
                        <div className="rounded-2xl bg-white border border-border shadow-brand-lg overflow-hidden">
                          <div className="p-2 grid grid-cols-2 gap-1">
                            {link.children.map((child) => {
                              const service = SERVICES.find(
                                (s) => s.url === child.href
                              );
                              const Icon = service
                                ? ICON_MAP[service.icon]
                                : Snowflake;
                              return (
                                <Link
                                  key={child.href}
                                  href={child.href}
                                  className="group flex gap-3 rounded-xl p-3 hover:bg-ice/8 transition-colors"
                                >
                                  <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-ice/12 text-ice-dark flex items-center justify-center group-hover:bg-ice group-hover:text-white transition-colors">
                                    <Icon className="w-4.5 h-4.5" />
                                  </div>
                                  <div className="min-w-0">
                                    <p className="text-sm font-bold text-navy leading-tight">
                                      {child.label}
                                    </p>
                                    <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug line-clamp-2">
                                      {child.description}
                                    </p>
                                  </div>
                                </Link>
                              );
                            })}
                          </div>
                          <Link
                            href="/services"
                            className="flex items-center justify-between gap-2 px-5 py-3 bg-navy text-white text-sm font-bold hover:bg-navy-light transition-colors"
                          >
                            View all services
                            <ArrowRight className="w-4 h-4" />
                          </Link>
                        </div>
                      </div>
                    </div>
                  );
                }
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={cn(
                      "rounded-lg px-3 py-2 text-sm font-semibold transition-colors",
                      active
                        ? solidHeader
                          ? "text-ice-dark bg-ice/8"
                          : "text-white bg-white/10"
                        : solidHeader
                          ? "text-navy hover:text-ice-dark hover:bg-ice/8"
                          : "text-white/90 hover:text-white hover:bg-white/10"
                    )}
                  >
                    {link.label}
                  </Link>
                );
              })}
            </nav>

            {/* Desktop CTAs */}
            <div className="hidden md:flex items-center gap-2.5 flex-shrink-0">
              <a
                href={BUSINESS.whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className={cn(
                  "inline-flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-bold transition-all",
                  solidHeader
                    ? "text-whatsapp hover:bg-whatsapp/10"
                    : "text-white hover:bg-white/10"
                )}
                aria-label="Chat on WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
                <span className="hidden xl:inline">WhatsApp</span>
              </a>
              <a
                href={BUSINESS.phoneHref}
                className="inline-flex items-center gap-2 rounded-lg bg-amber hover:bg-amber-dark text-navy px-4 py-2.5 text-sm font-bold shadow-amber-glow transition-all hover:-translate-y-0.5"
              >
                <Phone className="w-4 h-4" />
                <span className="hidden sm:inline">{BUSINESS.phoneDisplay}</span>
                <span className="sm:hidden">Call</span>
              </a>
            </div>

            {/* Mobile toggle */}
            <button
              type="button"
              className={cn(
                "lg:hidden inline-flex items-center justify-center w-11 h-11 rounded-lg border transition-colors flex-shrink-0",
                solidHeader
                  ? "border-border text-navy hover:bg-muted"
                  : "border-white/30 text-white hover:bg-white/10"
              )}
              aria-label={drawerOpen ? "Close menu" : "Open menu"}
              aria-expanded={drawerOpen}
              onClick={() => setDrawerOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile drawer */}
      <div
        className={cn(
          "fixed inset-0 z-[60] lg:hidden transition-opacity duration-300",
          drawerOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        )}
        aria-hidden={!drawerOpen}
      >
        <div
          className="absolute inset-0 bg-navy-dark/55 backdrop-blur-sm"
          onClick={() => setDrawerOpen(false)}
        />
        <aside
          className={cn(
            "absolute right-0 top-0 h-full w-[88%] max-w-sm bg-white shadow-brand-lg flex flex-col transition-transform duration-300",
            drawerOpen ? "translate-x-0" : "translate-x-full"
          )}
          role="dialog"
          aria-modal="true"
          aria-label="Mobile navigation"
        >
          <div className="flex items-center justify-between p-4 border-b border-border">
            <Link href="/" className="flex items-center gap-3">
              <LogoMark className="w-9 h-9" />
              <span className="font-display font-extrabold text-navy">
                Dubai Chill<span className="text-ice"> Pros</span>
              </span>
            </Link>
            <button
              type="button"
              className="inline-flex items-center justify-center w-10 h-10 rounded-lg border border-border text-navy hover:bg-muted"
              aria-label="Close menu"
              onClick={() => setDrawerOpen(false)}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <nav
            className="flex-1 overflow-y-auto p-4 flex flex-col gap-1"
            aria-label="Mobile"
          >
            <Link
              href="/"
              className={cn(
                "rounded-lg px-4 py-3 text-base font-semibold transition-colors",
                isActive("/") ? "bg-ice/10 text-ice-dark" : "text-navy hover:bg-muted"
              )}
            >
              Home
            </Link>

            {/* Services collapsible */}
            <button
              type="button"
              onClick={() => setMobileServicesOpen(!mobileServicesOpen)}
              className={cn(
                "flex items-center justify-between rounded-lg px-4 py-3 text-base font-semibold transition-colors w-full",
                isActive("/services") ? "bg-ice/10 text-ice-dark" : "text-navy hover:bg-muted"
              )}
              aria-expanded={mobileServicesOpen}
            >
              Services
              <ChevronDown
                className={cn("w-4 h-4 transition-transform", mobileServicesOpen && "rotate-180")}
              />
            </button>
            {mobileServicesOpen && (
              <div className="pl-3 flex flex-col gap-0.5 mb-1">
                <Link
                  href="/services"
                  className="rounded-lg px-4 py-2.5 text-sm font-semibold text-ice-dark hover:bg-ice/8"
                >
                  All Services
                </Link>
                {SERVICES.map((s) => {
                  const Icon = ICON_MAP[s.icon];
                  return (
                    <Link
                      key={s.url}
                      href={s.url}
                      className="flex items-center gap-2.5 rounded-lg px-4 py-2.5 text-sm font-medium text-foreground/85 hover:bg-muted"
                    >
                      <Icon className="w-4 h-4 text-ice-dark flex-shrink-0" />
                      {s.title}
                    </Link>
                  );
                })}
              </div>
            )}

            {/* Other links */}
            {NAV.filter((n) => n.href !== "/" && n.href !== "/services").map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "rounded-lg px-4 py-3 text-base font-semibold transition-colors",
                  isActive(link.href) ? "bg-ice/10 text-ice-dark" : "text-navy hover:bg-muted"
                )}
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="p-4 border-t border-border flex flex-col gap-2.5">
            <a
              href={BUSINESS.phoneHref}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-amber hover:bg-amber-dark text-navy px-4 py-3.5 text-sm font-bold shadow-amber-glow transition-colors"
            >
              <Phone className="w-4 h-4" />
              Call {BUSINESS.phoneDisplay}
            </a>
            <a
              href={BUSINESS.whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-whatsapp hover:bg-whatsapp-dark text-white px-4 py-3.5 text-sm font-bold transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp Us
            </a>
            <p className="text-center text-xs text-muted-foreground mt-1">
              {BUSINESS.hours} · {BUSINESS.addressLine}
            </p>
          </div>
        </aside>
      </div>
    </>
  );
}

/** The official Dubai Chill Pros logo mark — snowflake + lightning bolt. */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      role="img"
      aria-label="Dubai Chill Pros logo"
    >
      <defs>
        <linearGradient id="logo-navy" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#0A1B2E" />
          <stop offset="100%" stopColor="#1A3050" />
        </linearGradient>
        <linearGradient id="logo-ice" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#66D4ED" />
          <stop offset="100%" stopColor="#00B8E0" />
        </linearGradient>
      </defs>
      <rect width="100" height="100" rx="22" fill="url(#logo-navy)" />
      {/* Snowflake — cooling */}
      <g
        stroke="url(#logo-ice)"
        strokeWidth="3.5"
        strokeLinecap="round"
        fill="none"
        transform="translate(36,38)"
      >
        <line x1="0" y1="-12" x2="0" y2="12" />
        <line x1="-12" y1="0" x2="12" y2="0" />
        <line x1="-8.5" y1="-8.5" x2="8.5" y2="8.5" />
        <line x1="-8.5" y1="8.5" x2="8.5" y2="-8.5" />
      </g>
      {/* Lightning bolt — electrical */}
      <path
        d="M62 52 L52 70 L60 70 L56 84 L72 64 L64 64 L68 52 Z"
        fill="#FFB100"
        stroke="#FFB100"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
    </svg>
  );
}
