import Link from "next/link";
import { Phone, MessageCircle, ArrowRight } from "lucide-react";
import { BUSINESS } from "@/lib/site-data";
import { Reveal } from "@/components/site/Reveal";

type CTASectionProps = {
  eyebrow?: string;
  title?: string;
  description?: string;
  primaryLabel?: string;
  primaryHref?: string;
  showSecondary?: boolean;
};

export function CTASection({
  eyebrow = "Book Your Service Today",
  title = "AC or electrical issue in Dubai? We're 45–90 minutes away.",
  description = "Call now and a certified technician is dispatched immediately. Genuine spare parts in every van. Written quote before any work. 12-month workmanship warranty on every job.",
  primaryLabel = `Call ${BUSINESS.phoneDisplay}`,
  primaryHref = BUSINESS.phoneHref,
  showSecondary = true,
}: CTASectionProps) {
  return (
    <section className="relative py-20 md:py-24 bg-navy-dark text-white overflow-hidden">
      <div aria-hidden className="absolute inset-0 bg-grid-navy opacity-50" />
      <div
        aria-hidden
        className="absolute -top-32 left-1/4 w-96 h-96 rounded-full bg-ice/15 blur-3xl"
      />
      <div
        aria-hidden
        className="absolute -bottom-32 right-1/4 w-96 h-96 rounded-full bg-amber/12 blur-3xl"
      />

      <div className="relative mx-auto max-w-[1080px] px-4 md:px-8 text-center">
        <Reveal>
          <p className="text-ice font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
            {eyebrow}
          </p>
          <h2 className="font-display font-extrabold text-3xl md:text-4xl lg:text-5xl tracking-tight leading-[1.1]">
            {title}
          </h2>
          <p className="mt-5 text-base md:text-lg text-white/75 leading-relaxed max-w-2xl mx-auto">
            {description}
          </p>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <a
              href={primaryHref}
              className="inline-flex items-center justify-center gap-2.5 rounded-xl bg-amber hover:bg-amber-dark text-navy px-7 py-4 text-base font-bold shadow-amber-glow transition-all hover:-translate-y-0.5 w-full sm:w-auto"
            >
              <Phone className="w-5 h-5" />
              {primaryLabel}
            </a>
            {showSecondary && (
              <a
                href={BUSINESS.whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 rounded-xl bg-whatsapp hover:bg-whatsapp-dark text-white px-7 py-4 text-base font-bold shadow-lg transition-all hover:-translate-y-0.5 w-full sm:w-auto"
              >
                <MessageCircle className="w-5 h-5" />
                WhatsApp Us
              </a>
            )}
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-white/55">
            <span>{BUSINESS.hours}</span>
            <span className="hidden sm:inline">·</span>
            <span>Avg pickup under 12 seconds</span>
            <span className="hidden sm:inline">·</span>
            <Link
              href="/contact"
              className="inline-flex items-center gap-1 text-ice hover:text-ice-light font-semibold"
            >
              Request a callback
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
