import { LogoMark } from "@/components/site/Header";
import { Phone, MessageCircle, Mail, MapPin, Clock, Star } from "lucide-react";
import { BUSINESS, SERVICES, SERVICE_AREAS } from "@/lib/site-data";

const QUICK_LINKS = [
  { href: "/services", label: "All Services" },
  { href: "/service-areas", label: "Service Areas" },
  { href: "/pricing", label: "Pricing" },
  { href: "/reviews", label: "Reviews" },
  { href: "/about", label: "About Us" },
  { href: "/faq", label: "FAQ" },
  { href: "/contact", label: "Contact" },
];

export function Footer() {
  return (
    <footer className="bg-navy-dark text-white">
      <div className="mx-auto max-w-[1280px] px-4 md:px-8 py-14 md:py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-[1.6fr_1fr_1fr_1.2fr] gap-10 md:gap-8">
          {/* Brand col */}
          <div className="col-span-2 md:col-span-1 lg:col-span-1">
            <div className="flex items-center gap-3">
              <LogoMark className="w-11 h-11" />
              <span className="font-display font-extrabold text-lg">
                Dubai Chill <span className="text-ice">Pros</span>
              </span>
            </div>
            <p className="mt-4 text-sm text-white/65 leading-relaxed max-w-sm">
              Dubai&rsquo;s trusted same-day AC repair, AC installation, AC
              maintenance and licensed electrical services company. Certified
              technicians, genuine spare parts, transparent pricing — serving
              every community across Dubai, 24/7.
            </p>
            <div className="mt-5 inline-flex items-center gap-2 rounded-lg bg-white/8 border border-white/15 px-3 py-2">
              <div className="flex">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-amber text-amber" />
                ))}
              </div>
              <span className="text-xs text-white/80">
                <span className="font-bold">{BUSINESS.rating}</span> · {BUSINESS.reviewCount} reviews
              </span>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-white mb-4">
              Services
            </h3>
            <ul className="space-y-2.5">
              {SERVICES.map((s) => (
                <li key={s.url}>
                  <a
                    href={s.url}
                    className="text-sm text-white/65 hover:text-ice transition-colors"
                  >
                    {s.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick links */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-white mb-4">
              Company
            </h3>
            <ul className="space-y-2.5">
              {QUICK_LINKS.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="text-sm text-white/65 hover:text-ice transition-colors"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="col-span-2 md:col-span-1">
            <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-white mb-4">
              Get in touch
            </h3>
            <ul className="space-y-3">
              <li>
                <a
                  href={BUSINESS.phoneHref}
                  className="flex items-start gap-3 text-sm text-white/80 hover:text-amber transition-colors"
                >
                  <Phone className="w-4 h-4 text-amber mt-0.5 flex-shrink-0" />
                  <span>
                    <span className="block text-[11px] uppercase tracking-wider text-white/50 font-semibold">
                      Call us 24/7
                    </span>
                    <span className="font-bold">{BUSINESS.phoneDisplay}</span>
                  </span>
                </a>
              </li>
              <li>
                <a
                  href={BUSINESS.whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3 text-sm text-white/80 hover:text-whatsapp transition-colors"
                >
                  <MessageCircle className="w-4 h-4 text-whatsapp mt-0.5 flex-shrink-0" />
                  <span>
                    <span className="block text-[11px] uppercase tracking-wider text-white/50 font-semibold">
                      WhatsApp
                    </span>
                    <span className="font-bold">{BUSINESS.phoneDisplay}</span>
                  </span>
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${BUSINESS.email}`}
                  className="flex items-start gap-3 text-sm text-white/80 hover:text-ice transition-colors break-all"
                >
                  <Mail className="w-4 h-4 text-ice mt-0.5 flex-shrink-0" />
                  <span>
                    <span className="block text-[11px] uppercase tracking-wider text-white/50 font-semibold">
                      Email
                    </span>
                    <span className="font-bold">{BUSINESS.email}</span>
                  </span>
                </a>
              </li>
              <li>
                <a
                  href="https://www.google.com/maps/search/?api=1&query=W+Cluster+Jumeirah+Lakes+Towers+Dubai"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3 text-sm text-white/80 hover:text-ice transition-colors"
                >
                  <MapPin className="w-4 h-4 text-ice mt-0.5 flex-shrink-0" />
                  <span>
                    <span className="block text-[11px] uppercase tracking-wider text-white/50 font-semibold">
                      Visit HQ
                    </span>
                    <span className="font-bold">{BUSINESS.addressFull}</span>
                  </span>
                </a>
              </li>
              <li className="flex items-start gap-3 text-sm text-white/80">
                <Clock className="w-4 h-4 text-ice mt-0.5 flex-shrink-0" />
                <span>
                  <span className="block text-[11px] uppercase tracking-wider text-white/50 font-semibold">
                    Hours
                  </span>
                  <span className="font-bold">{BUSINESS.hours}</span>
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Service areas strip */}
        <div className="mt-12 pt-8 border-t border-white/10">
          <p className="text-[11px] uppercase tracking-wider text-white/40 font-semibold mb-3">
            Proudly serving all of Dubai, including
          </p>
          <p className="text-xs text-white/55 leading-relaxed">
            {SERVICE_AREAS.map((a) => a.name).join(" · ")} — and every other
            community in Dubai.{" "}
            <a href="/service-areas" className="text-ice hover:underline font-semibold">
              See all service areas →
            </a>
          </p>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8 py-5 flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="text-xs text-white/55 text-center md:text-left">
            &copy; {new Date().getFullYear()} {BUSINESS.name}. All rights
            reserved. Licensed AC repair &amp; electrical services in Dubai, UAE.
          </p>
          <div className="flex items-center gap-4 text-xs text-white/55">
            <a href="/about" className="hover:text-ice transition-colors">Privacy</a>
            <a href="/about" className="hover:text-ice transition-colors">Terms</a>
            <a href="/sitemap.xml" className="hover:text-ice transition-colors">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
