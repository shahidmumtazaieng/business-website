"use client";

import { useEffect, useState } from "react";
import { Phone, MessageCircle, X } from "lucide-react";
import { BUSINESS } from "@/lib/site-data";
import { cn } from "@/lib/utils";

export function FloatingButtons() {
  const [scrolled, setScrolled] = useState(false);
  const [callOpen, setCallOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      {/* Mobile call popup */}
      {callOpen && (
        <div
          className="fixed inset-0 z-[70] md:hidden flex items-end justify-center"
          aria-modal="true"
          role="dialog"
        >
          <div
            className="absolute inset-0 bg-navy-dark/55 backdrop-blur-sm"
            onClick={() => setCallOpen(false)}
          />
          <div className="relative w-full bg-white rounded-t-3xl p-6 pb-8 shadow-brand-lg animate-in slide-in-from-bottom">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-display font-extrabold text-navy text-lg">
                Talk to a Dubai technician
              </h3>
              <button
                type="button"
                onClick={() => setCallOpen(false)}
                aria-label="Close"
                className="w-9 h-9 rounded-lg border border-border text-navy flex items-center justify-center hover:bg-muted"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <a
              href={BUSINESS.phoneHref}
              className="w-full inline-flex items-center justify-center gap-2.5 rounded-xl bg-amber hover:bg-amber-dark text-navy px-5 py-4 text-base font-bold shadow-amber-glow mb-2.5"
            >
              <Phone className="w-5 h-5" />
              Call {BUSINESS.phoneDisplay}
            </a>
            <a
              href={BUSINESS.whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex items-center justify-center gap-2.5 rounded-xl bg-whatsapp hover:bg-whatsapp-dark text-white px-5 py-4 text-base font-bold"
            >
              <MessageCircle className="w-5 h-5" />
              WhatsApp us
            </a>
            <p className="mt-4 text-center text-xs text-muted-foreground">
              {BUSINESS.hours} · Average pickup under 12 seconds
            </p>
          </div>
        </div>
      )}

      {/* Desktop side rail */}
      <div
        className={cn(
          "hidden md:flex fixed left-5 top-1/2 -translate-y-1/2 z-40 flex-col gap-2.5 transition-all duration-300",
          scrolled ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-4 pointer-events-none"
        )}
      >
        <a
          href={BUSINESS.phoneHref}
          className="group relative flex flex-col items-center justify-center w-14 h-14 rounded-2xl bg-amber text-navy shadow-amber-glow hover:bg-amber-dark transition-all hover:scale-105"
          aria-label={`Call ${BUSINESS.phoneDisplay}`}
        >
          <Phone className="w-5 h-5" />
          <span className="absolute left-full ml-3 whitespace-nowrap rounded-lg bg-navy text-white text-xs font-bold px-3 py-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            {BUSINESS.phoneDisplay}
          </span>
        </a>
        <a
          href={BUSINESS.whatsappHref}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative flex flex-col items-center justify-center w-14 h-14 rounded-2xl bg-whatsapp text-white shadow-lg hover:bg-whatsapp-dark transition-all hover:scale-105"
          aria-label="Chat on WhatsApp"
        >
          <MessageCircle className="w-5 h-5" />
          <span className="absolute left-full ml-3 whitespace-nowrap rounded-lg bg-navy text-white text-xs font-bold px-3 py-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            WhatsApp chat
          </span>
        </a>
      </div>

      {/* Mobile floating action stack */}
      <div className="md:hidden fixed bottom-5 right-5 z-40 flex flex-col gap-3">
        <a
          href={BUSINESS.whatsappHref}
          target="_blank"
          rel="noopener noreferrer"
          className="w-14 h-14 rounded-full bg-whatsapp text-white shadow-lg flex items-center justify-center hover:scale-105 transition-transform"
          aria-label="Chat on WhatsApp"
        >
          <MessageCircle className="w-6 h-6" />
        </a>
        <button
          type="button"
          onClick={() => setCallOpen(true)}
          className="relative w-14 h-14 rounded-full bg-amber text-navy shadow-amber-glow flex items-center justify-center hover:scale-105 transition-transform animate-pulse-ring"
          aria-label={`Call ${BUSINESS.phoneDisplay}`}
        >
          <Phone className="w-6 h-6" />
        </button>
      </div>
    </>
  );
}
