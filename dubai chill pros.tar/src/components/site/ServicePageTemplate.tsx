import Link from "next/link";
import Image from "next/image";
import {
  Phone,
  MessageCircle,
  Check,
  ArrowRight,
  ChevronRight,
  Wrench,
  AlertTriangle,
  ShieldCheck,
  Clock,
  MapPin,
  Star,
} from "lucide-react";
import {
  BUSINESS,
  SERVICE_PAGES,
  type ServicePage,
} from "@/lib/site-data";
import { InnerHero } from "@/components/site/InnerHero";
import { CTASection } from "@/components/site/CTASection";
import { RelatedServices } from "@/components/site/RelatedServices";
import { Reveal } from "@/components/site/Reveal";

const ICON_GLYPH = {
  ac: "❄️",
  install: "💨",
  maintenance: "🛠️",
  electric: "⚡",
  wiring: "🔌",
  emergency: "🚨",
} as const;

/**
 * Service page template — renders a complete SEO-optimized service detail page.
 * Powers all 6 individual service URLs under /services/[slug].
 */
export function ServicePageTemplate({ slug }: { slug: string }) {
  const page: ServicePage | undefined = SERVICE_PAGES[slug];
  if (!page) {
    throw new Error(`No service page found for slug: ${slug}`);
  }

  return (
    <>
      <InnerHero
        eyebrow={page.category === "AC" ? "AC Services" : "Electrical Services"}
        title={page.heroTitle}
        subtitle={page.heroSubtitle}
        image={page.heroImage}
        imageAlt={`${page.heroTitle} — Dubai Chill Pros certified technician at work`}
        breadcrumbItems={[
          { label: "Services", href: "/services" },
          { label: page.heroTitle.split(" — ")[0].split(" | ")[0] },
        ]}
        badge={page.heroBadge}
      />

      {/* Quick contact strip */}
      <section className="bg-navy text-white border-b border-white/10">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm">
            <Clock className="w-4 h-4 text-ice" />
            <span className="font-semibold">{BUSINESS.hours}</span>
            <span className="hidden sm:inline text-white/40">·</span>
            <span className="hidden sm:inline text-white/70">
              Avg response {BUSINESS.responseTime}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <a
              href={BUSINESS.whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-lg bg-whatsapp hover:bg-whatsapp-dark px-3.5 py-2 text-xs font-bold transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              WhatsApp
            </a>
            <a
              href={BUSINESS.phoneHref}
              className="inline-flex items-center gap-1.5 rounded-lg bg-amber hover:bg-amber-dark text-navy px-3.5 py-2 text-xs font-bold transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              {BUSINESS.phoneDisplay}
            </a>
          </div>
        </div>
      </section>

      {/* Intro */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="grid lg:grid-cols-[1fr_340px] gap-10 lg:gap-14">
            <div>
              <Reveal>
                <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                  {page.category === "AC"
                    ? "Air Conditioning Service"
                    : "Licensed Electrical Service"}
                </p>
                <div className="space-y-4 text-base text-foreground/80 leading-relaxed">
                  {page.intro.map((para, idx) => (
                    <p key={idx}>{para}</p>
                  ))}
                </div>
              </Reveal>
            </div>

            {/* Sidebar: stats card */}
            <Reveal delay={120}>
              <div className="lg:sticky lg:top-24 space-y-4">
                <div className="rounded-2xl bg-navy text-white p-6 shadow-brand-md">
                  <p className="text-xs uppercase tracking-wider text-ice font-semibold mb-3">
                    Why Dubai chooses us
                  </p>
                  <div className="grid grid-cols-2 gap-3 mb-5">
                    <Stat label="Response time" value={BUSINESS.responseTime} />
                    <Stat label="Jobs done" value={BUSINESS.jobsCompleted} />
                    <Stat label="Rating" value={`${BUSINESS.rating}★`} />
                    <Stat label="Years" value={`${BUSINESS.yearsInBusiness}`} />
                  </div>
                  <a
                    href={BUSINESS.phoneHref}
                    className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-amber hover:bg-amber-dark text-navy px-4 py-3 text-sm font-bold transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                    Get a free quote
                  </a>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Sub-services */}
      <section className="py-16 md:py-20 bg-muted/40 relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 bg-grid-frost opacity-50" />
        <div className="relative mx-auto max-w-[1280px] px-4 md:px-8">
          <Reveal className="max-w-2xl mb-12">
            <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              What We Cover
            </p>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              {page.subServicesTitle}
            </h2>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {page.subServices.map((sub, idx) => (
              <Reveal key={idx} delay={idx * 60}>
                <article className="h-full rounded-2xl bg-white border border-border p-6 shadow-brand-sm hover:shadow-brand-md hover:-translate-y-1 transition-all duration-300">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-ice/12 text-ice-dark flex items-center justify-center">
                      <Wrench className="w-4 h-4" />
                    </div>
                    <h3 className="font-display font-bold text-navy text-base md:text-lg leading-tight pt-1">
                      {sub.title}
                    </h3>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {sub.description}
                  </p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Common problems (only for repair-type services) */}
      {page.commonProblems && page.commonProblems.length > 0 && (
        <section className="py-16 md:py-20 bg-background">
          <div className="mx-auto max-w-[1280px] px-4 md:px-8">
            <Reveal className="max-w-2xl mb-12">
              <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                Common Problems We Fix
              </p>
              <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
                Symptoms we diagnose & repair every day
              </h2>
              <p className="mt-4 text-muted-foreground text-base md:text-lg leading-relaxed">
                Click any symptom to see the most likely root cause and how our
                certified technicians fix it permanently — not just patch it.
              </p>
            </Reveal>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {page.commonProblems.map((problem, idx) => (
                <Reveal key={idx} delay={idx * 60}>
                  <article className="h-full rounded-2xl bg-white border border-border p-6 shadow-brand-sm hover:shadow-brand-md transition-all duration-300">
                    <div className="flex items-start gap-3 mb-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-amber/15 text-amber-dark flex items-center justify-center">
                        <AlertTriangle className="w-5 h-5" />
                      </div>
                      <h3 className="font-display font-bold text-navy text-base md:text-lg leading-tight pt-1.5">
                        {problem.symptom}
                      </h3>
                    </div>
                    <div className="space-y-3 text-sm">
                      <div>
                        <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground mb-1">
                          Likely cause
                        </p>
                        <p className="text-foreground/80 leading-relaxed">
                          {problem.cause}
                        </p>
                      </div>
                      <div className="pt-3 border-t border-border">
                        <p className="text-[11px] font-bold uppercase tracking-wider text-ice-dark mb-1">
                          How we fix it
                        </p>
                        <p className="text-foreground/80 leading-relaxed">
                          {problem.fix}
                        </p>
                      </div>
                    </div>
                  </article>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Why choose us (specific to this service) */}
      <section className="py-16 md:py-20 bg-navy-dark text-white relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 bg-grid-navy opacity-50" />
        <div
          aria-hidden
          className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-ice/15 blur-3xl"
        />
        <div className="relative mx-auto max-w-[1280px] px-4 md:px-8">
          <Reveal className="max-w-2xl mb-12">
            <p className="text-ice font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              Why Dubai Chill Pros
            </p>
            <h2 className="font-display font-extrabold text-3xl md:text-4xl tracking-tight">
              The difference is in the details
            </h2>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {page.whyChooseUs.map((reason, idx) => (
              <Reveal key={idx} delay={idx * 60}>
                <div className="flex gap-4 rounded-2xl bg-white/5 border border-white/10 p-5 hover:bg-white/8 transition-colors h-full">
                  <div className="flex-shrink-0 w-11 h-11 rounded-xl bg-ice/20 border border-ice/40 text-ice flex items-center justify-center">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-white text-base md:text-lg leading-tight">
                      {reason.title}
                    </h3>
                    <p className="mt-1.5 text-sm text-white/70 leading-relaxed">
                      {reason.description}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <Reveal className="text-center max-w-2xl mx-auto mb-12">
            <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              Our Process
            </p>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              From your call to a permanent fix
            </h2>
          </Reveal>

          <div className="relative grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            <div
              aria-hidden
              className="hidden lg:block absolute top-10 left-[12%] right-[12%] h-[2px] bg-gradient-to-r from-ice/30 via-ice/60 to-amber/60"
            />
            {page.processSteps.map((step, idx) => (
              <Reveal key={idx} delay={idx * 80}>
                <div className="relative flex flex-col items-center text-center">
                  <div className="relative w-16 h-16 rounded-full bg-navy border-2 border-ice/40 flex items-center justify-center mb-4 shadow-ice-glow">
                    <span className="font-display font-extrabold text-lg text-gradient-ice">
                      {step.num}
                    </span>
                  </div>
                  <h3 className="font-display font-bold text-navy text-base md:text-lg mb-2">
                    {step.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Brands (if applicable) */}
      {page.brands && page.brands.length > 0 && (
        <section className="py-12 md:py-16 bg-muted/40 border-y border-border">
          <div className="mx-auto max-w-[1280px] px-4 md:px-8">
            <Reveal className="text-center mb-6">
              <p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">
                Certified to service & install every brand used in Dubai
              </p>
            </Reveal>
            <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-4">
              {page.brands.map((brand) => (
                <span
                  key={brand}
                  className="font-display font-bold text-lg md:text-xl text-navy/40 hover:text-ice-dark transition-colors cursor-default"
                >
                  {brand}
                </span>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Service areas */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="grid lg:grid-cols-[1fr_340px] gap-10 lg:gap-14 items-start">
            <div>
              <Reveal>
                <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                  Service Areas
                </p>
                <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
                  Serving {page.heroTitle.split(" — ")[0].split(" | ")[0]} across all of Dubai
                </h2>
                <p className="mt-4 text-muted-foreground text-base md:text-lg leading-relaxed">
                  Based at Jumeirah Lakes Towers, our certified technicians reach
                  every Dubai community within {BUSINESS.responseTime}. Whether
                  you&rsquo;re in a JLT apartment, a Marina tower, a Palm villa
                  or a Downtown office, we&rsquo;re 45–90 minutes away — 24/7,
                  365 days a year.
                </p>
              </Reveal>

              <Reveal delay={120}>
                <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {[
                    "Jumeirah Lakes Towers",
                    "Dubai Marina",
                    "Downtown Dubai",
                    "Jumeirah",
                    "Palm Jumeirah",
                    "Business Bay",
                    "Arabian Ranches",
                    "Dubai Hills Estate",
                    "Al Barsha",
                    "The Springs & Meadows",
                    "Jumeirah Beach Residence",
                    "DIFC",
                  ].map((area) => (
                    <Link
                      key={area}
                      href="/service-areas"
                      className="rounded-lg bg-white border border-border px-3 py-2.5 text-xs font-semibold text-navy hover:border-ice/40 hover:bg-ice/8 transition-colors flex items-center gap-1.5"
                    >
                      <MapPin className="w-3 h-3 text-ice-dark flex-shrink-0" />
                      <span className="truncate">{area}</span>
                    </Link>
                  ))}
                </div>
                <Link
                  href="/service-areas"
                  className="mt-4 inline-flex items-center gap-1.5 text-sm font-bold text-ice-dark hover:gap-2 transition-all"
                >
                  View all 18+ service areas
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </Reveal>
            </div>

            <RelatedServices
              currentSlug={page.slug}
              relatedSlugs={page.relatedServiceSlugs}
            />
          </div>
        </div>
      </section>

      {/* FAQ (service-specific) */}
      <section className="py-16 md:py-20 bg-muted/40 relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 bg-grid-frost opacity-50" />
        <div className="relative mx-auto max-w-[1080px] px-4 md:px-8">
          <Reveal className="text-center max-w-2xl mx-auto mb-10">
            <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              {page.heroTitle.split(" — ")[0].split(" | ")[0]} — Your Questions Answered
            </p>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              Frequently asked questions
            </h2>
          </Reveal>

          <div className="space-y-3">
            {page.faqs.map((faq, idx) => (
              <Reveal key={idx} delay={idx * 40}>
                <details className="group rounded-2xl bg-white border border-border shadow-brand-sm overflow-hidden">
                  <summary className="px-5 md:px-6 py-5 cursor-pointer list-none flex items-start justify-between gap-4 hover:bg-muted/30 transition-colors">
                    <span className="font-display font-bold text-navy text-base md:text-lg pr-4">
                      {faq.q}
                    </span>
                    <ChevronRight className="w-5 h-5 text-ice-dark flex-shrink-0 mt-1 group-open:rotate-90 transition-transform" />
                  </summary>
                  <div className="px-5 md:px-6 pb-5 text-sm md:text-[15px] text-muted-foreground leading-relaxed">
                    {faq.a}
                  </div>
                </details>
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-8 text-center">
            <p className="text-sm text-muted-foreground">
              Still have a question?{" "}
              <a
                href={BUSINESS.phoneHref}
                className="font-bold text-ice-dark hover:underline"
              >
                Call {BUSINESS.phoneDisplay}
              </a>{" "}
              and speak to a real certified technician.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Pricing CTA */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <Reveal>
            <div className="rounded-3xl bg-gradient-to-br from-navy to-navy-light text-white p-8 md:p-12 grid md:grid-cols-[1.4fr_1fr] gap-8 items-center shadow-brand-lg">
              <div>
                <p className="text-ice font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                  Transparent Pricing
                </p>
                <h2 className="font-display font-extrabold text-2xl md:text-3xl lg:text-4xl leading-tight">
                  Get a fixed, written quote before any work begins
                </h2>
                <p className="mt-4 text-white/75 text-base leading-relaxed">
                  No call-out surprises. No inflated spare-parts invoices. No
                  upsell. We diagnose, we explain, we quote — and we fix only
                  what actually needs fixing.
                </p>
                <div className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-white/70">
                  <span className="inline-flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5 text-ice" />
                    12-month workmanship warranty
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5 text-ice" />
                    Genuine spare parts
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5 text-ice" />
                    Compliance report
                  </span>
                </div>
              </div>
              <div className="flex flex-col gap-2.5">
                <a
                  href={BUSINESS.phoneHref}
                  className="inline-flex items-center justify-center gap-2.5 rounded-xl bg-amber hover:bg-amber-dark text-navy px-6 py-4 text-base font-bold shadow-amber-glow transition-all hover:-translate-y-0.5"
                >
                  <Phone className="w-5 h-5" />
                  {BUSINESS.phoneDisplay}
                </a>
                <a
                  href={BUSINESS.whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2.5 rounded-xl bg-whatsapp hover:bg-whatsapp-dark text-white px-6 py-4 text-base font-bold transition-colors"
                >
                  <MessageCircle className="w-5 h-5" />
                  WhatsApp for a quote
                </a>
                <Link
                  href="/pricing"
                  className="inline-flex items-center justify-center gap-2 text-sm font-semibold text-ice hover:text-ice-light pt-2"
                >
                  See all pricing plans
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <CTASection />
    </>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-white/5 border border-white/10 p-2.5">
      <p className="text-base font-display font-extrabold text-white leading-none">
        {value}
      </p>
      <p className="text-[10px] uppercase tracking-wider text-white/55 mt-1 font-semibold">
        {label}
      </p>
    </div>
  );
}
