import Link from "next/link";
import Image from "next/image";
import { ChevronRight, Home } from "lucide-react";
import { cn } from "@/lib/utils";

export type Crumb = { label: string; href?: string };

export function Breadcrumbs({ items }: { items: Crumb[] }) {
  return (
    <nav
      aria-label="Breadcrumb"
      className="text-xs md:text-sm text-white/70 font-medium"
    >
      <ol className="flex flex-wrap items-center gap-1.5">
        <li>
          <Link
            href="/"
            className="inline-flex items-center gap-1 hover:text-ice transition-colors"
          >
            <Home className="w-3.5 h-3.5" />
            <span className="sr-only">Home</span>
          </Link>
        </li>
        {items.map((item, idx) => {
          const isLast = idx === items.length - 1;
          return (
            <li key={idx} className="flex items-center gap-1.5">
              <ChevronRight className="w-3 h-3 text-white/40" />
              {item.href && !isLast ? (
                <Link
                  href={item.href}
                  className="hover:text-ice transition-colors"
                >
                  {item.label}
                </Link>
              ) : (
                <span
                  className={cn(isLast && "text-white font-semibold")}
                  aria-current={isLast ? "page" : undefined}
                >
                  {item.label}
                </span>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

/** Inner page hero with image background + breadcrumb */
export function InnerHero({
  eyebrow,
  title,
  subtitle,
  image,
  imageAlt,
  breadcrumbItems,
  badge,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  image: string;
  imageAlt: string;
  breadcrumbItems: Crumb[];
  badge?: string;
}) {
  return (
    <section className="relative isolate overflow-hidden bg-navy-dark text-white">
      <div className="absolute inset-0 -z-10">
        <Image
          src={image}
          alt={imageAlt}
          fill
          priority
          sizes="100vw"
          className="object-cover object-center"
        />
        <div
          aria-hidden
          className="absolute inset-0 bg-gradient-to-r from-navy-dark via-navy-dark/92 to-navy-dark/55"
        />
        <div
          aria-hidden
          className="absolute inset-0 bg-gradient-to-t from-navy-dark via-transparent to-navy-dark/30"
        />
        <div aria-hidden className="absolute inset-0 bg-grid-navy opacity-60" />
      </div>

      <div className="mx-auto max-w-[1280px] px-4 md:px-8 pt-28 md:pt-36 pb-14 md:pb-20">
        <Breadcrumbs items={breadcrumbItems} />

        {badge && (
          <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-ice/40 bg-ice/10 backdrop-blur-sm px-3.5 py-1.5 text-xs font-bold uppercase tracking-[0.1em] text-ice">
            <span className="relative flex w-2 h-2">
              <span className="absolute inset-0 rounded-full bg-ice animate-ping opacity-70" />
              <span className="relative w-2 h-2 rounded-full bg-ice" />
            </span>
            {badge}
          </div>
        )}

        <h1 className="mt-5 font-display font-extrabold leading-[1.08] tracking-tight text-3xl sm:text-4xl md:text-5xl lg:text-[3.4rem] max-w-4xl">
          {title}
        </h1>
        <p className="mt-5 text-base md:text-lg text-white/80 leading-relaxed max-w-3xl">
          {subtitle}
        </p>
      </div>

      <div
        aria-hidden
        className="absolute bottom-0 inset-x-0 h-12 bg-gradient-to-t from-background to-transparent"
      />
    </section>
  );
}
