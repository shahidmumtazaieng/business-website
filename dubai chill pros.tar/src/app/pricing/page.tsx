import type { Metadata } from "next";
import Link from "next/link";
import { Phone, MessageCircle, Check, ArrowRight, Star, ShieldCheck, HelpCircle } from "lucide-react";
import { BUSINESS, PRICING, FAQS } from "@/lib/site-data";
import { InnerHero } from "@/components/site/InnerHero";
import { CTASection } from "@/components/site/CTASection";
import { Reveal } from "@/components/site/Reveal";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "AC & Electrical Services Pricing in Dubai",
  description:
    "Transparent pricing for AC repair, AC installation, AC maintenance (AMC) and electrical services in Dubai. One-off call-out, annual contracts and commercial SLAs. No hidden charges.",
  alternates: { canonical: "https://dubaichillpros.com/pricing" },
  openGraph: {
    title: "AC & Electrical Services Pricing in Dubai | Dubai Chill Pros",
    description:
      "Clear, upfront pricing for AC repair, installation, maintenance and electrical services in Dubai. AED 150 call-out, AED 699 AMC, custom commercial contracts.",
    url: "https://dubaichillpros.com/pricing",
  },
};

const PRICING_TABLE = [
  { service: "AC diagnostic call-out", price: "AED 150", note: "Waived if repair approved" },
  { service: "Split AC repair (minor)", price: "from AED 250", note: "Capacitor, thermostat, filter clean" },
  { service: "Split AC repair (major)", price: "from AED 450", note: "Fan motor, PCB, contactor" },
  { service: "Compressor replacement", price: "AED 900–2,400", note: "Depends on tonnage & brand" },
  { service: "Refrigerant gas top-up (R410A/R32)", price: "AED 250–450", note: "Includes leak pressure test" },
  { service: "AC deep clean (single split)", price: "AED 199", note: "Coil, filter, drain, sanitise" },
  { service: "Split AC installation", price: "from AED 450/unit", note: "Bracket, piping ≤3m, vacuum, gas" },
  { service: "Ducted AC installation", price: "Quoted per project", note: "Free site survey" },
  { service: "Annual AMC (per split unit)", price: "AED 699/year", note: "4 visits + priority response" },
  { service: "Electrician call-out", price: "AED 150", note: "Waived if repair approved" },
  { service: "Socket/switch replacement", price: "from AED 120", note: "Per point, certified parts" },
  { service: "Distribution board inspection", price: "from AED 350", note: "Includes compliance report" },
  { service: "EV charger installation", price: "from AED 1,200", note: "Dedicated circuit + RCBO" },
  { service: "Emergency night-rate (22:00–06:00)", price: "+ AED 100–150", note: "Disclosed upfront, capped" },
];

export default function PricingPage() {
  const pricingFaqs = FAQS.filter((f) => f.category === "Pricing" || f.category === "Warranty");

  return (
    <>
      <InnerHero
        eyebrow="Pricing"
        title="Transparent AC & Electrical Pricing in Dubai"
        subtitle="No call-out surprises. No inflated spare-parts invoices. No upsell. We diagnose, we explain, we quote — and we fix only what actually needs fixing. The price you approve is the price you pay."
        image="/images/electrician-panel.png"
        imageAlt="Dubai Chill Pros electrician working on a distribution board with transparent pricing"
        breadcrumbItems={[{ label: "Pricing" }]}
        badge="No hidden charges · Written quotes"
      />

      {/* Pricing tiers */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <Reveal className="text-center max-w-2xl mx-auto mb-12">
            <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              Choose Your Plan
            </p>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              Three ways to work with us
            </h2>
            <p className="mt-4 text-muted-foreground text-base md:text-lg leading-relaxed">
              Whether you need a one-off repair, an annual maintenance contract
              for your villa, or a multi-unit SLA for your building — pick the
              plan that fits.
            </p>
          </Reveal>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 md:gap-6 items-stretch">
            {PRICING.map((tier, idx) => (
              <Reveal key={tier.name} delay={idx * 80}>
                <div
                  className={cn(
                    "relative h-full rounded-2xl p-6 md:p-8 flex flex-col transition-all duration-300",
                    tier.highlight
                      ? "bg-navy text-white border-2 border-ice/50 shadow-ice-glow lg:-translate-y-3"
                      : "bg-white border border-border shadow-brand-sm hover:shadow-brand-md hover:-translate-y-1"
                  )}
                >
                  {tier.highlight && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 inline-flex items-center gap-1 rounded-full bg-amber text-navy px-3 py-1 text-[11px] font-bold uppercase tracking-wider shadow-amber-glow">
                      <Star className="w-3 h-3 fill-navy" />
                      Best value
                    </span>
                  )}
                  <h3 className={cn("font-display font-bold text-lg md:text-xl", tier.highlight ? "text-ice" : "text-navy")}>
                    {tier.name}
                  </h3>
                  <p className={cn("mt-1 text-sm", tier.highlight ? "text-white/70" : "text-muted-foreground")}>
                    {tier.description}
                  </p>
                  <div className="mt-5 flex items-baseline gap-1.5">
                    <span className={cn("font-display font-extrabold text-3xl md:text-4xl", tier.highlight ? "text-white" : "text-navy")}>
                      {tier.price}
                    </span>
                    <span className={cn("text-xs", tier.highlight ? "text-white/60" : "text-muted-foreground")}>
                      / {tier.unit}
                    </span>
                  </div>
                  <ul className="mt-6 space-y-3 flex-1">
                    {tier.features.map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-sm">
                        <span
                          className={cn(
                            "mt-0.5 flex-shrink-0 w-4 h-4 rounded-full flex items-center justify-center",
                            tier.highlight ? "bg-ice/25 text-ice" : "bg-ice/15 text-ice-dark"
                          )}
                        >
                          <Check className="w-3 h-3" />
                        </span>
                        <span className={tier.highlight ? "text-white/90" : "text-foreground/85"}>
                          {f}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <a
                    href={BUSINESS.phoneHref}
                    className={cn(
                      "mt-7 w-full inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3.5 text-sm font-bold transition-all",
                      tier.highlight
                        ? "bg-amber hover:bg-amber-dark text-navy shadow-amber-glow"
                        : "bg-navy hover:bg-navy-light text-white"
                    )}
                  >
                    <Phone className="w-4 h-4" />
                    {tier.cta}
                  </a>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Itemised price list */}
      <section className="py-16 md:py-20 bg-muted/40 relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 bg-grid-frost opacity-50" />
        <div className="relative mx-auto max-w-[1080px] px-4 md:px-8">
          <Reveal className="text-center max-w-2xl mx-auto mb-10">
            <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              Itemised Price List
            </p>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              Typical prices for common jobs
            </h2>
            <p className="mt-4 text-muted-foreground text-base leading-relaxed">
              These are indicative prices. Every job is quoted in writing after
              diagnosis. Final price depends on AC type, brand, capacity, parts
              required and accessibility.
            </p>
          </Reveal>

          <Reveal>
            <div className="rounded-2xl bg-white border border-border shadow-brand-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-navy text-white">
                      <th className="text-left px-5 py-4 font-display font-bold">Service</th>
                      <th className="text-left px-5 py-4 font-display font-bold whitespace-nowrap">Indicative price</th>
                      <th className="text-left px-5 py-4 font-display font-bold hidden md:table-cell">Notes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {PRICING_TABLE.map((row, idx) => (
                      <tr
                        key={idx}
                        className={cn(
                          "border-t border-border",
                          idx % 2 === 1 && "bg-muted/30"
                        )}
                      >
                        <td className="px-5 py-4 font-semibold text-navy">
                          {row.service}
                        </td>
                        <td className="px-5 py-4 font-bold text-ice-dark whitespace-nowrap">
                          {row.price}
                        </td>
                        <td className="px-5 py-4 text-muted-foreground hidden md:table-cell">
                          {row.note}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </Reveal>

          <Reveal className="mt-6">
            <p className="text-xs text-muted-foreground text-center max-w-2xl mx-auto">
              All prices are in AED and include standard labour. Spare parts are
              charged at cost with the manufacturer&rsquo;s warranty. Emergency
              night-rate surcharge (22:00–06:00 and public holidays) is capped at
              AED 100–150 and always disclosed before dispatch.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Pricing FAQs */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1080px] px-4 md:px-8">
          <Reveal className="text-center max-w-2xl mx-auto mb-10">
            <div className="inline-flex items-center gap-2 rounded-full bg-ice/10 border border-ice/30 px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider text-ice-dark mb-4">
              <HelpCircle className="w-3.5 h-3.5" />
              Pricing questions
            </div>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              Pricing &amp; warranty — explained
            </h2>
          </Reveal>

          <div className="space-y-3">
            {pricingFaqs.map((faq, idx) => (
              <Reveal key={idx} delay={idx * 40}>
                <details className="group rounded-2xl bg-white border border-border shadow-brand-sm overflow-hidden">
                  <summary className="px-5 md:px-6 py-5 cursor-pointer list-none flex items-start justify-between gap-4 hover:bg-muted/30 transition-colors">
                    <span className="font-display font-bold text-navy text-base md:text-lg pr-4">
                      {faq.q}
                    </span>
                  </summary>
                  <div className="px-5 md:px-6 pb-5 text-sm md:text-[15px] text-muted-foreground leading-relaxed">
                    {faq.a}
                  </div>
                </details>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Reassurance strip */}
      <section className="py-12 bg-navy-dark text-white">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: ShieldCheck, title: "12-month warranty", text: "On every job" },
              { icon: Check, title: "Genuine parts only", text: "OEM, DEWA-approved" },
              { icon: Star, title: "4.9★ rated", text: "327 verified reviews" },
              { icon: Phone, title: "Free phone consult", text: "No call-out fee to call" },
            ].map((item, i) => (
              <div key={i} className="text-center md:text-left">
                <div className="inline-flex md:flex w-10 h-10 rounded-lg bg-ice/20 border border-ice/40 text-ice items-center justify-center mb-2">
                  <item.icon className="w-5 h-5" />
                </div>
                <p className="font-display font-bold text-sm">{item.title}</p>
                <p className="text-xs text-white/60 mt-0.5">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTASection
        eyebrow="Get A Written Quote"
        title="Call us with your symptom — get a fixed price in minutes."
        description="Most quotes can be given over the phone once we understand the AC type, brand and symptom. For larger jobs (installation, rewiring, commercial), we'll visit free of charge and give you a written quote within 24 hours."
      />
    </>
  );
}
