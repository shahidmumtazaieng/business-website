import Link from "next/link";
import Image from "next/image";
import {
  Phone,
  MessageCircle,
  Star,
  ShieldCheck,
  Clock,
  MapPin,
  ArrowRight,
  Check,
} from "lucide-react";
import { BUSINESS, SERVICES, PROCESS, SERVICE_AREAS, TESTIMONIALS, PRICING } from "@/lib/site-data";
import { Reveal } from "@/components/site/Reveal";
import { ServicesGrid } from "@/components/site/RelatedServices";
import { CTASection } from "@/components/site/CTASection";
import { cn } from "@/lib/utils";

export default function Home() {
  return (
    <>
      <Hero />
      <TrustBar />
      <ServicesSection />
      <BrandsStrip />
      <WhyChooseUs />
      <Process />
      <AreasPreview />
      <Testimonials />
      <PricingPreview />
      <CTASection
        eyebrow="Book Your Service Today"
        title="AC or electrical issue in Dubai? We're 45–90 minutes away."
        description="Call now and a certified technician is dispatched immediately. Genuine spare parts in every van. Written quote before any work. 12-month workmanship warranty on every job."
      />
    </>
  );
}

// ---------------- Hero ----------------
function Hero() {
  return (
    <section
      id="top"
      className="relative isolate overflow-hidden bg-navy-dark text-white"
    >
      <div className="absolute inset-0 -z-10">
        <Image
          src="/images/hero-ac-technician.png"
          alt="Dubai Chill Pros HVAC technician servicing an outdoor air conditioner condenser unit in Dubai"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center"
        />
        <div
          aria-hidden
          className="absolute inset-0 bg-gradient-to-r from-navy-dark via-navy-dark/90 to-navy-dark/40"
        />
        <div
          aria-hidden
          className="absolute inset-0 bg-gradient-to-t from-navy-dark via-transparent to-navy-dark/40"
        />
        <div aria-hidden className="absolute inset-0 bg-grid-navy opacity-70" />
      </div>

      <div className="mx-auto max-w-[1280px] px-4 md:px-8 pt-28 md:pt-36 pb-16 md:pb-24">
        <div className="grid lg:grid-cols-[1.05fr_1fr] gap-12 items-center">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-ice/40 bg-ice/10 backdrop-blur-sm px-3.5 py-1.5 text-xs font-bold uppercase tracking-[0.1em] text-ice">
              <span className="relative flex w-2 h-2">
                <span className="absolute inset-0 rounded-full bg-ice animate-ping opacity-70" />
                <span className="relative w-2 h-2 rounded-full bg-ice" />
              </span>
              {BUSINESS.hours}
            </div>

            <h1 className="mt-6 font-display font-extrabold leading-[1.05] tracking-tight text-4xl sm:text-5xl md:text-6xl">
              AC Repair &amp; Electrical
              <br />
              Services in{" "}
              <span className="text-gradient-ice-amber">Dubai</span> — Done
              Right, Done Today.
            </h1>

            <p className="mt-6 text-base md:text-lg text-white/80 leading-relaxed max-w-xl">
              Dubai&rsquo;s most trusted same-day AC repair, installation and
              licensed electrical service. Certified technicians, genuine spare
              parts, transparent pricing — serving JLT, Dubai Marina, Downtown,
              Jumeirah, Palm Jumeirah and every community in between.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <a
                href={BUSINESS.phoneHref}
                className="inline-flex items-center justify-center gap-2.5 rounded-xl bg-amber hover:bg-amber-dark text-navy px-6 py-4 text-base font-bold shadow-amber-glow transition-all hover:-translate-y-0.5"
              >
                <Phone className="w-5 h-5" />
                Call {BUSINESS.phoneDisplay}
              </a>
              <a
                href={BUSINESS.whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 rounded-xl bg-whatsapp hover:bg-whatsapp-dark text-white px-6 py-4 text-base font-bold shadow-lg transition-all hover:-translate-y-0.5"
              >
                <MessageCircle className="w-5 h-5" />
                WhatsApp Us
              </a>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm">
              <div className="flex items-center gap-2">
                <div className="flex" aria-label={`Rated ${BUSINESS.rating} out of 5`}>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber text-amber" aria-hidden />
                  ))}
                </div>
                <span className="text-white/85 font-semibold">
                  {BUSINESS.rating} · {BUSINESS.reviewCount} reviews
                </span>
              </div>
              <div className="flex items-center gap-2 text-white/85">
                <ShieldCheck className="w-4 h-4 text-ice" />
                <span className="font-medium">Licensed &amp; insured</span>
              </div>
              <div className="flex items-center gap-2 text-white/85">
                <Clock className="w-4 h-4 text-ice" />
                <span className="font-medium">{BUSINESS.responseTime} response</span>
              </div>
            </div>
          </div>

          <div className="relative hidden lg:block">
            <div className="relative animate-float-soft">
              <div className="absolute -inset-3 rounded-3xl bg-gradient-to-br from-ice/20 via-transparent to-amber/20 blur-xl" />
              <div className="relative rounded-2xl bg-white/[0.08] backdrop-blur-md border border-white/15 p-6 shadow-brand-lg">
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-ice/20 border border-ice/40 flex items-center justify-center">
                      <MapPin className="w-5 h-5 text-ice" />
                    </div>
                    <div>
                      <p className="text-xs uppercase tracking-wider text-white/60 font-semibold">
                        Dispatch HQ
                      </p>
                      <p className="text-sm font-bold text-white">
                        {BUSINESS.addressLine}
                      </p>
                    </div>
                  </div>
                  <span className="rounded-full bg-whatsapp/20 text-whatsapp px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide">
                    Live
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-3 mb-5">
                  <Stat label="Response time" value={BUSINESS.responseTime} />
                  <Stat label="Jobs completed" value={BUSINESS.jobsCompleted} />
                  <Stat label="Certified techs" value={`${BUSINESS.certifiedTechs}`} />
                  <Stat label="Years in Dubai" value={`${BUSINESS.yearsInBusiness}`} />
                </div>
                <div className="rounded-xl bg-navy-dark/60 border border-white/10 p-4">
                  <p className="text-xs uppercase tracking-wider text-ice font-semibold mb-1.5">
                    Now servicing
                  </p>
                  <p className="text-sm text-white/85 leading-relaxed">
                    JLT · Dubai Marina · Downtown · Jumeirah · Palm Jumeirah ·
                    Business Bay · Arabian Ranches · Dubai Hills · +14 more
                    communities.
                  </p>
                </div>
                <a
                  href={BUSINESS.phoneHref}
                  className="mt-5 w-full inline-flex items-center justify-center gap-2 rounded-xl bg-amber hover:bg-amber-dark text-navy px-4 py-3 text-sm font-bold transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  Same-day dispatch — call now
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div aria-hidden className="absolute bottom-0 inset-x-0 h-12 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-white/5 border border-white/10 p-3">
      <p className="text-xl font-display font-extrabold text-white leading-none">{value}</p>
      <p className="text-[11px] uppercase tracking-wider text-white/60 mt-1.5 font-semibold">{label}</p>
    </div>
  );
}

// ---------------- Trust bar ----------------
function TrustBar() {
  const TRUST = [
    { icon: ShieldCheck, label: "Licensed & insured", sub: "Dubai Municipality approved" },
    { icon: Clock, label: "24/7 emergency", sub: "Every day, every night" },
    { icon: Star, label: `${BUSINESS.rating}★ rating`, sub: `${BUSINESS.reviewCount} verified reviews` },
    { icon: Check, label: "Same-day repair", sub: "9 of 10 fixes done first visit" },
    { icon: MapPin, label: `${BUSINESS.certifiedTechs} certified techs`, sub: "HVAC + electrical experts" },
  ];
  return (
    <section className="relative -mt-px bg-navy text-white">
      <div className="mx-auto max-w-[1280px] px-4 md:px-8 py-7">
        <ul className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-x-6 gap-y-5">
          {TRUST.map((item, i) => (
            <li key={i} className="flex items-center gap-3 justify-center md:justify-start">
              <div className="w-10 h-10 rounded-lg bg-white/8 border border-white/15 flex items-center justify-center flex-shrink-0">
                <item.icon className="w-5 h-5 text-ice" />
              </div>
              <div>
                <p className="text-sm font-bold leading-tight">{item.label}</p>
                <p className="text-[11px] text-white/60 mt-0.5">{item.sub}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

// ---------------- Services section ----------------
function ServicesSection() {
  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="mx-auto max-w-[1280px] px-4 md:px-8">
        <Reveal className="text-center max-w-2xl mx-auto mb-14">
          <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
            Our Services
          </p>
          <h2 className="font-display font-extrabold text-navy text-3xl md:text-5xl tracking-tight">
            AC &amp; Electrical Services Built for{" "}
            <span className="text-gradient-ice">Dubai Living</span>
          </h2>
          <p className="mt-4 text-muted-foreground text-base md:text-lg leading-relaxed">
            From a single faulty capacitor to a full villa rewire, our certified
            technicians handle every cooling and electrical need under one roof —
            with genuine parts, transparent pricing and a workmanship warranty on
            every job.
          </p>
        </Reveal>

        <ServicesGrid />

        <Reveal className="mt-10 text-center">
          <Link
            href="/services"
            className="inline-flex items-center gap-2 rounded-xl bg-navy hover:bg-navy-light text-white px-6 py-3.5 text-sm font-bold transition-colors"
          >
            Explore all services in detail
            <ArrowRight className="w-4 h-4" />
          </Link>
        </Reveal>
      </div>
    </section>
  );
}

// ---------------- Brands strip ----------------
function BrandsStrip() {
  const BRANDS = [
    "Daikin", "LG", "Samsung", "Carrier", "Trane", "York", "Gree", "Midea",
    "Super General", "Hisense", "Hitachi", "Panasonic", "Sharp", "Nikai", "Skyworth",
  ];
  const doubled = [...BRANDS, ...BRANDS];
  return (
    <section className="py-12 md:py-16 bg-white border-y border-border">
      <div className="mx-auto max-w-[1280px] px-4 md:px-8">
        <Reveal className="text-center mb-7">
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">
            Genuine parts &amp; certified service for every AC brand sold in the UAE
          </p>
        </Reveal>
        <div className="relative overflow-hidden">
          <div aria-hidden className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-white to-transparent z-10" />
          <div aria-hidden className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-white to-transparent z-10" />
          <ul className="flex items-center gap-10 md:gap-14 animate-marquee w-max">
            {doubled.map((brand, idx) => (
              <li
                key={`${brand}-${idx}`}
                className="font-display font-extrabold text-xl md:text-2xl text-navy/35 whitespace-nowrap hover:text-ice-dark transition-colors"
                aria-hidden={idx >= BRANDS.length}
              >
                {brand}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

// ---------------- Why choose us ----------------
function WhyChooseUs() {
  const REASONS = [
    { icon: Clock, title: "45–90 minute response, anywhere in Dubai", text: "Our HQ in Jumeirah Lakes Towers puts every Dubai community within an hour of a certified technician — day or night, weekday or weekend." },
    { icon: ShieldCheck, title: "Licensed, insured & warranty-backed", text: "Every technician is Dubai Municipality-approved, HVAC and electrical certified, and fully insured. Every job comes with a written workmanship warranty." },
    { icon: Check, title: "Transparent, upfront pricing", text: "We quote before we work. No call-out surprises, no inflated spare-parts invoices, no upsell. The price you approve is the price you pay." },
    { icon: MessageCircle, title: "Stocked vans — done first visit", text: "Our vans carry genuine spare parts for Daikin, LG, Samsung, Carrier, Trane, Gree, Midea and every major brand — so 9 of 10 repairs are completed same day." },
    { icon: Star, title: "Energy-efficient, DEWA-friendly work", text: "A properly serviced AC and a clean electrical installation can cut your DEWA bill by 15–25%. We optimise every system we touch." },
    { icon: Phone, title: "Local Dubai team, not a call centre", text: "Call +971 55 166 3574 and you'll speak to a real Dubai-based coordinator who knows your building, your community and your AC system." },
  ];
  return (
    <section className="py-20 md:py-28 bg-muted/40 relative overflow-hidden">
      <div aria-hidden className="absolute inset-0 bg-grid-frost opacity-60" />
      <div className="relative mx-auto max-w-[1280px] px-4 md:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <Reveal className="relative">
            <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-brand-lg">
              <Image
                src="/images/ac-maintenance.png"
                alt="Dubai Chill Pros technician performing deep coil cleaning and AC maintenance"
                fill
                sizes="(min-width: 1024px) 40vw, 100vw"
                className="object-cover"
              />
              <div aria-hidden className="absolute inset-0 bg-gradient-to-tr from-navy-dark/55 via-transparent to-transparent" />
              <div className="absolute bottom-5 left-5 right-5 rounded-2xl bg-white/95 backdrop-blur-md border border-white/40 p-5 shadow-brand-md">
                <div className="flex items-center gap-4">
                  <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br from-ice to-ice-dark flex items-center justify-center text-white">
                    <ShieldCheck className="w-7 h-7" />
                  </div>
                  <div>
                    <p className="font-display font-extrabold text-navy text-lg leading-tight">
                      12-month workmanship warranty
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      On every AC installation &amp; electrical job
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="hidden md:block absolute -top-5 -right-3 rounded-2xl bg-amber text-navy px-5 py-3 shadow-amber-glow rotate-3">
              <p className="font-display font-extrabold text-2xl leading-none">{BUSINESS.jobsCompleted}</p>
              <p className="text-[11px] font-bold uppercase tracking-wider mt-1">Jobs completed</p>
            </div>
          </Reveal>

          <div>
            <Reveal>
              <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                Why Dubai Chill Pros
              </p>
              <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl lg:text-5xl tracking-tight leading-[1.1]">
                The AC &amp; electrical team Dubai homeowners{" "}
                <span className="text-gradient-ice-amber">actually call back.</span>
              </h2>
              <p className="mt-4 text-muted-foreground text-base md:text-lg leading-relaxed">
                We&rsquo;ve spent over a decade earning the trust of villa owners,
                tenants, property managers and businesses across Dubai. Here&rsquo;s
                what keeps them coming back — and referring their neighbours.
              </p>
            </Reveal>
            <div className="mt-8 grid sm:grid-cols-2 gap-5">
              {REASONS.map((reason, i) => (
                <Reveal key={i} delay={i * 60}>
                  <div className="flex gap-3.5">
                    <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-ice/12 text-ice-dark flex items-center justify-center">
                      <reason.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-display font-bold text-navy text-[15px] leading-snug">
                        {reason.title}
                      </h3>
                      <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">
                        {reason.text}
                      </p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ---------------- Process ----------------
function Process() {
  return (
    <section className="py-20 md:py-28 bg-navy-dark text-white relative overflow-hidden">
      <div aria-hidden className="absolute inset-0 bg-grid-navy opacity-50" />
      <div aria-hidden className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-ice/15 blur-3xl" />
      <div aria-hidden className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-amber/12 blur-3xl" />

      <div className="relative mx-auto max-w-[1280px] px-4 md:px-8">
        <Reveal className="text-center max-w-2xl mx-auto mb-14">
          <p className="text-ice font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
            How It Works
          </p>
          <h2 className="font-display font-extrabold text-3xl md:text-5xl tracking-tight">
            From call to cool in{" "}
            <span className="text-gradient-ice-amber">4 simple steps</span>
          </h2>
          <p className="mt-4 text-white/70 text-base md:text-lg leading-relaxed">
            No phone trees, no four-hour service windows, no &ldquo;we&rsquo;ll
            email you a quote next week&rdquo;. Just a real human, a fast
            dispatch, and a fix you can rely on.
          </p>
        </Reveal>

        <div className="relative grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-5">
          <div aria-hidden className="hidden lg:block absolute top-12 left-[12%] right-[12%] h-[2px] bg-gradient-to-r from-ice/30 via-ice/60 to-amber/60" />
          {PROCESS.map((step, idx) => (
            <Reveal key={step.num} delay={idx * 80} className="relative">
              <div className="relative flex flex-col items-center text-center">
                <div className="relative w-20 h-20 rounded-full bg-navy border-2 border-ice/40 flex items-center justify-center mb-5 shadow-ice-glow">
                  <span className="font-display font-extrabold text-2xl text-gradient-ice">
                    {step.num}
                  </span>
                </div>
                <h3 className="font-display font-bold text-lg md:text-xl text-white mb-2">
                  {step.title}
                </h3>
                <p className="text-sm text-white/70 leading-relaxed max-w-xs">
                  {step.description}
                </p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-14 text-center">
          <a
            href={BUSINESS.phoneHref}
            className="inline-flex items-center justify-center gap-2.5 rounded-xl bg-amber hover:bg-amber-dark text-navy px-7 py-4 text-base font-bold shadow-amber-glow transition-all hover:-translate-y-0.5"
          >
            Start now — {BUSINESS.phoneDisplay}
          </a>
          <p className="mt-3 text-xs text-white/50">Average pickup time: under 12 seconds.</p>
        </Reveal>
      </div>
    </section>
  );
}

// ---------------- Areas preview ----------------
function AreasPreview() {
  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="mx-auto max-w-[1280px] px-4 md:px-8">
        <div className="grid lg:grid-cols-[1fr_1.1fr] gap-12 items-center">
          <Reveal className="relative order-2 lg:order-1">
            <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-brand-lg">
              <Image
                src="/images/dubai-jlt-skyline.png"
                alt="Aerial view of Dubai Jumeirah Lakes Towers skyline at golden hour, the home base of Dubai Chill Pros"
                fill
                sizes="(min-width: 1024px) 40vw, 100vw"
                className="object-cover"
              />
              <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-navy-dark/60 via-transparent to-transparent" />
              <div className="absolute bottom-5 left-5 right-5 rounded-2xl bg-white/95 backdrop-blur-md p-5 border border-white/40 shadow-brand-md">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-11 h-11 rounded-xl bg-ice/15 flex items-center justify-center text-ice-dark">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-display font-extrabold text-navy leading-tight">
                      HQ: {BUSINESS.addressLine}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Dispatching certified technicians to all 18+ communities across Dubai — within the hour.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>

          <div className="order-1 lg:order-2">
            <Reveal>
              <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                Service Areas
              </p>
              <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl lg:text-5xl tracking-tight leading-[1.1]">
                Serving every corner of{" "}
                <span className="text-gradient-ice">Dubai</span>
              </h2>
              <p className="mt-4 text-muted-foreground text-base md:text-lg leading-relaxed">
                From our dispatch base at Jumeirah Lakes Towers, our certified
                technicians reach every Dubai community within 45–90 minutes.
                Here&rsquo;s where we&rsquo;re most often called to — but if your
                community isn&rsquo;t listed, just call. If it&rsquo;s in Dubai,
                we&rsquo;re there.
              </p>
            </Reveal>

            <Reveal delay={120}>
              <ul className="mt-8 grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {SERVICE_AREAS.slice(0, 9).map((area, idx) => (
                  <li key={area.name}>
                    <div
                      className={cn(
                        "group rounded-xl border p-3 transition-all hover:-translate-y-0.5",
                        area.type === "HQ"
                          ? "bg-ice/8 border-ice/40"
                          : "bg-white border-border hover:border-ice/40 hover:shadow-brand-sm"
                      )}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-sm font-bold text-navy leading-tight">
                          {area.name}
                        </p>
                        <MapPin
                          className={cn(
                            "w-3.5 h-3.5 flex-shrink-0 mt-0.5",
                            area.type === "HQ" ? "text-ice-dark" : "text-muted-foreground/60 group-hover:text-ice-dark"
                          )}
                        />
                      </div>
                      <p className="mt-1 text-[11px] font-semibold text-muted-foreground">
                        {area.type === "HQ" ? "Our HQ" : `~${area.type} away`}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal delay={180}>
              <div className="mt-6 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <Link
                  href="/service-areas"
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-navy hover:bg-navy-light text-white px-5 py-3 text-sm font-bold transition-colors"
                >
                  View all 18+ areas
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <a
                  href={BUSINESS.phoneHref}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber hover:bg-amber-dark text-navy px-5 py-3 text-sm font-bold shadow-amber-glow transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  Call now
                </a>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

// ---------------- Testimonials preview ----------------
function Testimonials() {
  return (
    <section className="py-20 md:py-28 bg-muted/40 relative overflow-hidden">
      <div aria-hidden className="absolute inset-0 bg-grid-frost opacity-50" />
      <div className="relative mx-auto max-w-[1280px] px-4 md:px-8">
        <Reveal className="text-center max-w-2xl mx-auto mb-14">
          <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
            Customer Reviews
          </p>
          <h2 className="font-display font-extrabold text-navy text-3xl md:text-5xl tracking-tight">
            Loved by{" "}
            <span className="text-gradient-ice-amber">{BUSINESS.reviewCount}+ Dubai customers</span>
          </h2>
          <div className="mt-5 inline-flex items-center gap-2 rounded-full bg-white border border-border px-4 py-2 shadow-brand-sm">
            <div className="flex">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber text-amber" />
              ))}
            </div>
            <span className="text-sm font-bold text-navy">{BUSINESS.rating}</span>
            <span className="text-sm text-muted-foreground">/ 5.0</span>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
          {TESTIMONIALS.slice(0, 6).map((t, idx) => (
            <Reveal key={idx} delay={idx * 60}>
              <figure className="h-full rounded-2xl bg-white border border-border p-6 md:p-7 shadow-brand-sm hover:shadow-brand-md hover:-translate-y-1 transition-all duration-300 flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex" aria-label={`Rated ${t.rating} out of 5`}>
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber text-amber" />
                    ))}
                  </div>
                  <span className="text-xs text-muted-foreground">{t.date}</span>
                </div>
                <blockquote className="text-sm md:text-[15px] text-foreground/85 leading-relaxed flex-1">
                  &ldquo;{t.text}&rdquo;
                </blockquote>
                <figcaption className="mt-5 pt-5 border-t border-border flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-ice to-ice-dark flex items-center justify-center text-white font-display font-bold text-sm flex-shrink-0">
                    {t.name.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-navy text-sm truncate">{t.name}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {t.area} · {t.service}
                    </p>
                  </div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-10 text-center">
          <Link
            href="/reviews"
            className="inline-flex items-center gap-2 rounded-xl bg-navy hover:bg-navy-light text-white px-6 py-3.5 text-sm font-bold transition-colors"
          >
            Read all {BUSINESS.reviewCount} reviews
            <ArrowRight className="w-4 h-4" />
          </Link>
        </Reveal>
      </div>
    </section>
  );
}

// ---------------- Pricing preview ----------------
function PricingPreview() {
  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="mx-auto max-w-[1280px] px-4 md:px-8">
        <Reveal className="text-center max-w-2xl mx-auto mb-14">
          <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
            Simple, Honest Pricing
          </p>
          <h2 className="font-display font-extrabold text-navy text-3xl md:text-5xl tracking-tight">
            No hidden charges.{" "}
            <span className="text-gradient-ice">Just clear quotes.</span>
          </h2>
          <p className="mt-4 text-muted-foreground text-base md:text-lg leading-relaxed">
            Whether you need a one-off repair, an annual maintenance contract for
            your villa, or a multi-unit SLA for your building — pick the plan that
            fits.
          </p>
        </Reveal>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 md:gap-6 items-stretch">
          {PRICING.map((tier, idx) => (
            <Reveal key={tier.name} delay={idx * 80}>
              <div
                className={cn(
                  "relative h-full rounded-2xl p-6 md:p-8 flex flex-col transition-all duration-300",
                  tier.highlight
                    ? "bg-navy text-white border-2 border-ice/50 shadow-ice-glow lg:-translate-y-3"
                    : "bg-white border border-border shadow-brand-sm hover:shadow-brand-md hover:-translate-y-1"
                )}
              >
                {tier.highlight && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 inline-flex items-center gap-1 rounded-full bg-amber text-navy px-3 py-1 text-[11px] font-bold uppercase tracking-wider shadow-amber-glow">
                    <Star className="w-3 h-3 fill-navy" />
                    Best value
                  </span>
                )}
                <h3 className={cn("font-display font-bold text-lg md:text-xl", tier.highlight ? "text-ice" : "text-navy")}>
                  {tier.name}
                </h3>
                <p className={cn("mt-1 text-sm", tier.highlight ? "text-white/70" : "text-muted-foreground")}>
                  {tier.description}
                </p>
                <div className="mt-5 flex items-baseline gap-1.5">
                  <span className={cn("font-display font-extrabold text-3xl md:text-4xl", tier.highlight ? "text-white" : "text-navy")}>
                    {tier.price}
                  </span>
                  <span className={cn("text-xs", tier.highlight ? "text-white/60" : "text-muted-foreground")}>
                    / {tier.unit}
                  </span>
                </div>
                <ul className="mt-6 space-y-3 flex-1">
                  {tier.features.slice(0, 4).map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm">
                      <span
                        className={cn(
                          "mt-0.5 flex-shrink-0 w-4 h-4 rounded-full flex items-center justify-center",
                          tier.highlight ? "bg-ice/25 text-ice" : "bg-ice/15 text-ice-dark"
                        )}
                      >
                        <Check className="w-3 h-3" />
                      </span>
                      <span className={tier.highlight ? "text-white/90" : "text-foreground/85"}>
                        {f}
                      </span>
                    </li>
                  ))}
                </ul>
                <a
                  href={BUSINESS.phoneHref}
                  className={cn(
                    "mt-7 w-full inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3.5 text-sm font-bold transition-all",
                    tier.highlight
                      ? "bg-amber hover:bg-amber-dark text-navy shadow-amber-glow"
                      : "bg-navy hover:bg-navy-light text-white"
                  )}
                >
                  <Phone className="w-4 h-4" />
                  {tier.cta}
                </a>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-10 text-center">
          <Link
            href="/pricing"
            className="inline-flex items-center gap-1.5 font-bold text-ice-dark hover:gap-2 transition-all text-sm"
          >
            See full pricing details
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </Reveal>
      </div>
    </section>
  );
}
