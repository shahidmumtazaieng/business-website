import type { Metadata } from "next";
import Image from "next/image";
import { Star, Quote, Phone, MessageCircle, ArrowRight } from "lucide-react";
import { BUSINESS, TESTIMONIALS } from "@/lib/site-data";
import { InnerHero } from "@/components/site/InnerHero";
import { CTASection } from "@/components/site/CTASection";
import { Reveal } from "@/components/site/Reveal";

export const metadata: Metadata = {
  title: "Customer Reviews in Dubai",
  description:
    "Read 327+ verified reviews from Dubai customers who trusted Dubai Chill Pros with their AC repair, AC installation, AC maintenance and electrical services. 4.9-star average rating.",
  alternates: { canonical: "https://dubaichillpros.com/reviews" },
  openGraph: {
    title: "Customer Reviews in Dubai | Dubai Chill Pros",
    description:
      "4.9-star average across 327 verified reviews. Read real stories from Dubai homeowners, tenants and businesses who trusted Dubai Chill Pros.",
    url: "https://dubaichillpros.com/reviews",
  },
};

const reviewsSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: BUSINESS.name,
  url: "https://dubaichillpros.com",
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: BUSINESS.rating,
    reviewCount: BUSINESS.reviewCount,
    bestRating: 5,
    worstRating: 1,
  },
  review: TESTIMONIALS.map((t) => ({
    "@type": "Review",
    author: { "@type": "Person", name: t.name },
    reviewRating: {
      "@type": "Rating",
      ratingValue: t.rating,
      bestRating: 5,
      worstRating: 1,
    },
    reviewBody: t.text,
    datePublished: t.date,
  })),
};

export default function ReviewsPage() {
  const ratingBreakdown = [
    { stars: 5, count: 312, pct: 95 },
    { stars: 4, count: 12, pct: 4 },
    { stars: 3, count: 2, pct: 1 },
    { stars: 2, count: 1, pct: 0 },
    { stars: 1, count: 0, pct: 0 },
  ];

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewsSchema) }}
      />

      <InnerHero
        eyebrow="Customer Reviews"
        title="4.9 Stars Across 327 Verified Dubai Reviews"
        subtitle="We don't buy reviews, and we don't filter the bad ones. Below is what Dubai homeowners, tenants, property managers and business owners have actually said about working with Dubai Chill Pros since 2013."
        image="/images/ac-maintenance.png"
        imageAlt="Dubai Chill Pros technician performing AC maintenance with a satisfied customer"
        breadcrumbItems={[{ label: "Reviews" }]}
        badge={`${BUSINESS.rating}★ average · ${BUSINESS.reviewCount} verified reviews`}
      />

      {/* Rating summary */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="grid lg:grid-cols-[1fr_2fr] gap-10 lg:gap-14">
            {/* Score card */}
            <Reveal>
              <div className="rounded-3xl bg-navy text-white p-8 text-center sticky top-24">
                <p className="font-display font-extrabold text-6xl md:text-7xl text-gradient-ice-amber leading-none">
                  {BUSINESS.rating}
                </p>
                <div className="flex justify-center mt-3">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-amber text-amber" />
                  ))}
                </div>
                <p className="mt-3 text-sm text-white/70">
                  Based on{" "}
                  <span className="font-bold text-white">{BUSINESS.reviewCount} verified reviews</span>
                </p>
                <div className="mt-6 pt-6 border-t border-white/10 space-y-2.5">
                  {ratingBreakdown.map((row) => (
                    <div key={row.stars} className="flex items-center gap-3 text-xs">
                      <span className="w-3 font-semibold">{row.stars}</span>
                      <Star className="w-3 h-3 fill-amber text-amber" />
                      <div className="flex-1 h-2 rounded-full bg-white/10 overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-amber to-amber-dark"
                          style={{ width: `${row.pct}%` }}
                        />
                      </div>
                      <span className="w-8 text-right text-white/60">{row.count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>

            {/* Reviews list */}
            <div>
              <Reveal className="mb-8">
                <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
                  Real stories from real Dubai customers
                </h2>
                <p className="mt-3 text-muted-foreground text-base leading-relaxed">
                  Every review below comes from a verified customer. We publish
                  them all — the 5-star ones and the lessons from any that
                  aren&rsquo;t.
                </p>
              </Reveal>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {TESTIMONIALS.map((t, idx) => (
                  <Reveal key={idx} delay={idx * 50}>
                    <figure className="h-full rounded-2xl bg-white border border-border p-6 shadow-brand-sm hover:shadow-brand-md transition-shadow flex flex-col">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex" aria-label={`Rated ${t.rating} out of 5`}>
                          {Array.from({ length: t.rating }).map((_, i) => (
                            <Star key={i} className="w-4 h-4 fill-amber text-amber" />
                          ))}
                        </div>
                        <Quote className="w-6 h-6 text-ice/30" />
                      </div>
                      <blockquote className="text-sm text-foreground/85 leading-relaxed flex-1">
                        &ldquo;{t.text}&rdquo;
                      </blockquote>
                      <figcaption className="mt-4 pt-4 border-t border-border">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-ice to-ice-dark flex items-center justify-center text-white font-display font-bold text-sm flex-shrink-0">
                            {t.name.charAt(0)}
                          </div>
                          <div className="min-w-0">
                            <p className="font-bold text-navy text-sm truncate">{t.name}</p>
                            <p className="text-xs text-muted-foreground truncate">
                              {t.area}
                            </p>
                          </div>
                        </div>
                        <div className="mt-3 flex items-center gap-2 text-[11px]">
                          <span className="rounded-full bg-ice/10 text-ice-dark px-2 py-0.5 font-semibold">
                            {t.service}
                          </span>
                          {t.date && (
                            <span className="text-muted-foreground">{t.date}</span>
                          )}
                        </div>
                      </figcaption>
                    </figure>
                  </Reveal>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <CTASection
        eyebrow="Become Our Next 5-Star Review"
        title="Experience the Dubai Chill Pros difference today."
        description="Join 8,400+ Dubai customers who got their AC fixed, their electrical issue solved, and their property back to comfort — same day, with a written warranty. Call now and we'll be at your door within 45–90 minutes."
      />
    </>
  );
}
