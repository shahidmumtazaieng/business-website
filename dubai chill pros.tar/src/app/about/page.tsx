import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Phone, MessageCircle, ArrowRight, Check, Award, Heart, Shield, Clock, MapPin, Star } from "lucide-react";
import { BUSINESS, VALUES, STATS } from "@/lib/site-data";
import { InnerHero } from "@/components/site/InnerHero";
import { CTASection } from "@/components/site/CTASection";
import { Reveal } from "@/components/site/Reveal";

export const metadata: Metadata = {
  title: "About Us — 12 Years of AC & Electrical Service in Dubai",
  description:
    "Dubai Chill Pros is a JLT-based AC repair & electrical services company founded in 2013. Meet the team, our values, our certifications and what makes us Dubai's most trusted HVAC + electrical provider.",
  alternates: { canonical: "https://dubaichillpros.com/about" },
  openGraph: {
    title: "About Dubai Chill Pros | 12 Years of AC & Electrical Service in Dubai",
    description:
      "Founded 2013 in Jumeirah Lakes Towers. Certified HVAC + electrical team serving all of Dubai. Licensed, insured, 4.9★ rated by 327 customers.",
    url: "https://dubaichillpros.com/about",
  },
};

export default function AboutPage() {
  return (
    <>
      <InnerHero
        eyebrow="About Us"
        title="Built in Dubai, for Dubai — Since 2013"
        subtitle="Dubai Chill Pros is a Jumeirah Lakes Towers-based AC repair and licensed electrical services company. We've spent 12 years earning the trust of Dubai homeowners, tenants, property managers and businesses — one honest, certified, on-time job at a time."
        image="/images/dubai-jlt-skyline.png"
        imageAlt="Aerial view of Jumeirah Lakes Towers Dubai — the home of Dubai Chill Pros"
        breadcrumbItems={[{ label: "About" }]}
        badge={`Founded ${BUSINESS.founded} · ${BUSINESS.yearsInBusiness} years in Dubai`}
      />

      {/* Stats strip */}
      <section className="py-12 md:py-14 bg-navy text-white">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <ul className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-x-6 gap-y-6">
            {STATS.map((s, i) => (
              <li key={i} className="text-center md:text-left">
                <p className="font-display font-extrabold text-2xl md:text-3xl text-ice">{s.value}</p>
                <p className="text-xs uppercase tracking-wider text-white/60 mt-1 font-semibold">{s.label}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Story */}
      <section className="py-16 md:py-24 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <Reveal className="relative">
              <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-brand-lg">
                <Image
                  src="/images/ac-installation.png"
                  alt="Dubai Chill Pros technician installing a split AC unit in a Dubai villa"
                  fill
                  sizes="(min-width: 1024px) 40vw, 100vw"
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-5 -right-3 rounded-2xl bg-amber text-navy px-5 py-3 shadow-amber-glow rotate-3 hidden md:block">
                <p className="font-display font-extrabold text-2xl leading-none">4.9★</p>
                <p className="text-[11px] font-bold uppercase tracking-wider mt-1">327 reviews</p>
              </div>
            </Reveal>

            <div>
              <Reveal>
                <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                  Our Story
                </p>
                <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight leading-[1.1]">
                  From one van in JLT to Dubai&rsquo;s most-called AC &amp; electrical team
                </h2>
                <div className="mt-5 space-y-4 text-base text-muted-foreground leading-relaxed">
                  <p>
                    Dubai Chill Pros was founded in {BUSINESS.founded} by a small
                    team of Dubai-certified HVAC technicians and electricians who
                    were tired of the city&rsquo;s &ldquo;patch-it-and-leave&rdquo;
                    service culture. Calls not answered. Technicians showing up
                    four hours late. Spare parts invoiced at triple the market
                    price. Compliance reports that didn&rsquo;t exist. Warranty
                    promises that vanished the moment the van pulled away.
                  </p>
                  <p>
                    We started with one promise: do the job right, charge
                    honestly, and answer the phone. Twelve years later, that
                    promise has taken us from a single van in Jumeirah Lakes
                    Towers to a team of {BUSINESS.certifiedTechs} certified
                    technicians, {BUSINESS.jobsCompleted} completed jobs, and a
                    4.9-star average rating across {BUSINESS.reviewCount} verified
                    customer reviews — serving every community in Dubai, 24 hours
                    a day, 365 days a year.
                  </p>
                  <p>
                    We&rsquo;re still based in Jumeirah Lakes Towers. We still
                    answer the phone ourselves. And we still believe that an AC
                    repair company in Dubai should be able to fix the AC the same
                    day you call — not book you in for next week.
                  </p>
                </div>
              </Reveal>

              <Reveal delay={120}>
                <div className="mt-7 flex flex-col sm:flex-row gap-3">
                  <a
                    href={BUSINESS.phoneHref}
                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber hover:bg-amber-dark text-navy px-6 py-3.5 text-sm font-bold shadow-amber-glow transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                    Call {BUSINESS.phoneDisplay}
                  </a>
                  <Link
                    href="/services"
                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-navy hover:bg-navy-light text-white px-6 py-3.5 text-sm font-bold transition-colors"
                  >
                    View our services
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 md:py-24 bg-muted/40 relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 bg-grid-frost opacity-50" />
        <div className="relative mx-auto max-w-[1280px] px-4 md:px-8">
          <Reveal className="text-center max-w-2xl mx-auto mb-12">
            <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              What We Stand For
            </p>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              Six values that shape every job we do
            </h2>
            <p className="mt-4 text-muted-foreground text-base md:text-lg leading-relaxed">
              These aren&rsquo;t marketing slogans. They&rsquo;re the rules every
              technician on our team follows on every job — from a AED 150
              capacitor swap to a full villa rewire.
            </p>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {VALUES.map((value, idx) => (
              <Reveal key={idx} delay={idx * 60}>
                <article className="h-full rounded-2xl bg-white border border-border p-6 shadow-brand-sm hover:shadow-brand-md transition-shadow">
                  <div className="w-11 h-11 rounded-xl bg-ice/12 text-ice-dark flex items-center justify-center mb-4">
                    <Check className="w-5 h-5" />
                  </div>
                  <h3 className="font-display font-bold text-navy text-lg leading-tight mb-2">
                    {value.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications strip */}
      <section className="py-16 md:py-20 bg-navy-dark text-white relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 bg-grid-navy opacity-50" />
        <div className="relative mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Shield, title: "Dubai Municipality approved", text: "Every technician is licensed by Dubai Municipality for HVAC and electrical work." },
              { icon: Award, title: "DEWA-certified", text: "Our electricians handle DEWA compliance, inspection and reconnection." },
              { icon: Heart, title: "Fully insured", text: "AED 5M public liability insurance covers every job, every property, every visit." },
              { icon: Clock, title: "24/7/365 operation", text: "Real technicians — not a call centre — answer the phone every night of the year." },
            ].map((item, i) => (
              <Reveal key={i} delay={i * 60}>
                <div className="flex flex-col items-center text-center md:items-start md:text-left">
                  <div className="w-12 h-12 rounded-xl bg-ice/20 border border-ice/40 text-ice flex items-center justify-center mb-4">
                    <item.icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-display font-bold text-white text-base mb-1.5">
                    {item.title}
                  </h3>
                  <p className="text-sm text-white/70 leading-relaxed">
                    {item.text}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Service area highlight */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="rounded-3xl bg-gradient-to-br from-navy to-navy-light text-white p-8 md:p-12 grid md:grid-cols-2 gap-8 items-center shadow-brand-lg">
            <div>
              <p className="text-ice font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                Where We&rsquo;re Based
              </p>
              <h2 className="font-display font-extrabold text-2xl md:text-3xl leading-tight mb-4">
                W Cluster, Jumeirah Lakes Towers — Dubai
              </h2>
              <p className="text-white/75 text-base leading-relaxed">
                Our dispatch base at W Cluster, JLT puts every Dubai community
                within {BUSINESS.responseTime} of a certified technician. We know
                your building&rsquo;s AC system, your distribution board, your
                DEWA connection process and your property manager — because
                we&rsquo;ve been working in your neighbourhood since 2013.
              </p>
              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <Link
                  href="/service-areas"
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber hover:bg-amber-dark text-navy px-5 py-3 text-sm font-bold shadow-amber-glow transition-colors"
                >
                  <MapPin className="w-4 h-4" />
                  View all service areas
                </Link>
                <a
                  href={BUSINESS.whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-whatsapp hover:bg-whatsapp-dark text-white px-5 py-3 text-sm font-bold transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp
                </a>
              </div>
            </div>
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden">
              <Image
                src="/images/dubai-jlt-skyline.png"
                alt="Jumeirah Lakes Towers Dubai skyline at golden hour"
                fill
                sizes="(min-width: 768px) 40vw, 100vw"
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <CTASection
        eyebrow="Work With Dubai Chill Pros"
        title="Ready to experience the difference?"
        description="Call now and join 8,400+ Dubai customers who trust Dubai Chill Pros with their AC and electrical systems. Same-day response, certified technicians, transparent pricing, 12-month warranty — every job, every time."
      />
    </>
  );
}
