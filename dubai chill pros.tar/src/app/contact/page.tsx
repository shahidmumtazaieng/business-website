import type { Metadata } from "next";
import Image from "next/image";
import { Phone, MessageCircle, Mail, MapPin, Clock, Send, CheckCircle2, Star } from "lucide-react";
import { BUSINESS, SERVICE_AREAS, SERVICES } from "@/lib/site-data";
import { InnerHero } from "@/components/site/InnerHero";
import { Reveal } from "@/components/site/Reveal";
import { ContactForm } from "@/components/site/ContactForm";

export const metadata: Metadata = {
  title: "Contact Us — AC & Electrical Service in Dubai",
  description:
    "Contact Dubai Chill Pros for AC repair, AC installation, AC maintenance and licensed electrical services across Dubai. Call +971 55 166 3574, WhatsApp, email or fill our callback form. 24/7, 365 days a year.",
  alternates: { canonical: "https://dubaichillpros.com/contact" },
  openGraph: {
    title: "Contact Dubai Chill Pros | AC & Electrical Service in Dubai",
    description:
      "Call +971 55 166 3574, WhatsApp, email basarali512m@gmail.com or visit W Cluster, Jumeirah Lakes Towers, Dubai. Open 24/7.",
    url: "https://dubaichillpros.com/contact",
  },
};

export default function ContactPage() {
  return (
    <>
      <InnerHero
        eyebrow="Contact Us"
        title="Get In Touch — We're 45–90 Minutes Away"
        subtitle="Call us, WhatsApp us, email us, or fill in the callback form below. A real Dubai-based coordinator will respond within 15 minutes — 24/7, 365 days a year. For emergencies, call now — don't fill a form."
        image="/images/emergency-service.png"
        imageAlt="Dubai Chill Pros emergency service van dispatched across Dubai"
        breadcrumbItems={[{ label: "Contact" }]}
        badge={`Avg pickup under 12 seconds · ${BUSINESS.hours}`}
      />

      {/* Contact options */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-14 items-start">
            {/* Left: contact details */}
            <div>
              <Reveal>
                <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                  Contact Details
                </p>
                <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
                  Reach Dubai Chill Pros — any way you prefer
                </h2>
                <p className="mt-4 text-muted-foreground text-base leading-relaxed">
                  For AC or electrical emergencies, call us directly — the form
                  below is monitored continuously but a phone call gets you the
                  fastest dispatch. We&rsquo;re based at W Cluster, Jumeirah
                  Lakes Towers, Dubai — visit by appointment.
                </p>
              </Reveal>

              <Reveal delay={120}>
                <div className="mt-8 space-y-3">
                  <ContactCard
                    icon={<Phone className="w-5 h-5" />}
                    label="Call us — 24/7, 365 days"
                    value={BUSINESS.phoneDisplay}
                    sub="Real technician answers, avg pickup <12 sec"
                    href={BUSINESS.phoneHref}
                    accent
                  />
                  <ContactCard
                    icon={<MessageCircle className="w-5 h-5" />}
                    label="WhatsApp"
                    value={BUSINESS.phoneDisplay}
                    sub="Send photos of the AC unit, fault or panel"
                    href={BUSINESS.whatsappHref}
                  />
                  <ContactCard
                    icon={<Mail className="w-5 h-5" />}
                    label="Email"
                    value={BUSINESS.email}
                    sub="Quotes, AMCs, commercial contracts"
                    href={`mailto:${BUSINESS.email}`}
                  />
                  <ContactCard
                    icon={<MapPin className="w-5 h-5" />}
                    label="Visit our HQ"
                    value={`${BUSINESS.addressLine}, ${BUSINESS.addressCity}`}
                    sub="By appointment — call ahead"
                    href="https://www.google.com/maps/search/?api=1&query=W+Cluster+Jumeirah+Lakes+Towers+Dubai"
                  />
                  <ContactCard
                    icon={<Clock className="w-5 h-5" />}
                    label="Hours of operation"
                    value={BUSINESS.hours}
                    sub="Including Eid & all UAE public holidays"
                  />
                </div>
              </Reveal>

              {/* Map */}
              <Reveal delay={180}>
                <div className="mt-6 rounded-2xl overflow-hidden border border-border shadow-brand-sm">
                  <div className="relative aspect-[16/9] bg-muted">
                    <Image
                      src="/images/dubai-jlt-skyline.png"
                      alt="Jumeirah Lakes Towers Dubai — location of Dubai Chill Pros HQ"
                      fill
                      sizes="(min-width: 1024px) 40vw, 100vw"
                      className="object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-dark/70 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="inline-flex items-center gap-2 rounded-lg bg-white/95 backdrop-blur-md px-4 py-2.5 shadow-brand-md">
                        <MapPin className="w-4 h-4 text-ice-dark" />
                        <span className="text-sm font-bold text-navy">
                          {BUSINESS.addressFull}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </Reveal>
            </div>

            {/* Right: callback form */}
            <Reveal delay={120}>
              <div className="rounded-3xl bg-white border border-border p-6 md:p-8 shadow-brand-lg">
                <h2 className="font-display font-extrabold text-navy text-2xl">
                  Request a free callback
                </h2>
                <p className="mt-2 text-sm text-muted-foreground">
                  Fill in the form and our Dubai coordinator will call you back
                  within 15 minutes — 24/7. For emergencies, call{" "}
                  <a
                    href={BUSINESS.phoneHref}
                    className="font-bold text-ice-dark hover:underline"
                  >
                    {BUSINESS.phoneDisplay}
                  </a>{" "}
                  instead.
                </p>
                <ContactForm />
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Service area + services strip */}
      <section className="py-16 md:py-20 bg-muted/40 relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 bg-grid-frost opacity-50" />
        <div className="relative mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-14">
            <Reveal>
              <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                Service Areas
              </p>
              <h2 className="font-display font-extrabold text-navy text-2xl md:text-3xl tracking-tight mb-4">
                We serve every community in Dubai
              </h2>
              <p className="text-muted-foreground text-base leading-relaxed mb-5">
                From our JLT dispatch base, our certified technicians reach all
                of Dubai within {BUSINESS.responseTime}. Below are the
                communities we most commonly serve.
              </p>
              <ul className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {SERVICE_AREAS.slice(0, 12).map((area) => (
                  <li
                    key={area.name}
                    className="rounded-lg bg-white border border-border px-3 py-2 text-xs font-semibold text-navy truncate"
                  >
                    {area.name}
                  </li>
                ))}
              </ul>
              <a
                href="/service-areas"
                className="mt-4 inline-flex items-center gap-1.5 text-sm font-bold text-ice-dark hover:gap-2 transition-all"
              >
                View all {SERVICE_AREAS.length}+ areas
                <MapPin className="w-4 h-4" />
              </a>
            </Reveal>

            <Reveal delay={120}>
              <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                Popular Services
              </p>
              <h2 className="font-display font-extrabold text-navy text-2xl md:text-3xl tracking-tight mb-4">
                What do you need help with?
              </h2>
              <ul className="space-y-2">
                {SERVICES.map((s) => (
                  <li key={s.url}>
                    <a
                      href={s.url}
                      className="group flex items-center justify-between gap-3 rounded-xl bg-white border border-border p-3.5 hover:border-ice/40 hover:shadow-brand-sm transition-all"
                    >
                      <div className="min-w-0">
                        <p className="font-bold text-navy text-sm group-hover:text-ice-dark transition-colors">
                          {s.title}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          {s.short}
                        </p>
                      </div>
                      <Send className="w-4 h-4 text-muted-foreground group-hover:text-ice-dark flex-shrink-0" />
                    </a>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Emergency strip */}
      <section className="py-12 bg-navy-dark text-white">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-5 text-center md:text-left">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-amber text-navy flex items-center justify-center flex-shrink-0 shadow-amber-glow">
                <Phone className="w-7 h-7" />
              </div>
              <div>
                <p className="font-display font-extrabold text-xl">
                  AC or electrical emergency in Dubai?
                </p>
                <p className="text-sm text-white/70 mt-1">
                  Call us right now — a real certified technician is on the line in under 12 seconds.
                </p>
              </div>
            </div>
            <a
              href={BUSINESS.phoneHref}
              className="inline-flex items-center justify-center gap-2.5 rounded-xl bg-amber hover:bg-amber-dark text-navy px-7 py-4 text-base font-bold shadow-amber-glow transition-all hover:-translate-y-0.5 flex-shrink-0"
            >
              <Phone className="w-5 h-5" />
              {BUSINESS.phoneDisplay}
            </a>
          </div>
        </div>
      </section>
    </>
  );
}

function ContactCard({
  icon,
  label,
  value,
  sub,
  href,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
  href?: string;
  accent?: boolean;
}) {
  const inner = (
    <>
      <div
        className={`flex-shrink-0 w-11 h-11 rounded-xl flex items-center justify-center ${
          accent
            ? "bg-amber text-navy shadow-amber-glow"
            : "bg-ice/12 text-ice-dark"
        }`}
      >
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold">
          {label}
        </p>
        <p className="text-base font-bold text-navy truncate">{value}</p>
        {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
      </div>
    </>
  );
  if (href) {
    return (
      <a
        href={href}
        target={href.startsWith("http") ? "_blank" : undefined}
        rel={href.startsWith("http") ? "noopener noreferrer" : undefined}
        className="flex items-center gap-3.5 rounded-2xl bg-white border border-border p-4 hover:border-ice/40 hover:shadow-brand-sm transition-all"
      >
        {inner}
      </a>
    );
  }
  return (
    <div className="flex items-center gap-3.5 rounded-2xl bg-white border border-border p-4">
      {inner}
    </div>
  );
}
