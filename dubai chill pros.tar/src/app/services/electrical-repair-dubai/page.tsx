import { buildServiceMetadata, buildServiceJsonLd } from "@/lib/service-seo";
import { ServicePageTemplate } from "@/components/site/ServicePageTemplate";

export const metadata = buildServiceMetadata("electrical-repair-dubai");

export default function ElectricalRepairPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: buildServiceJsonLd("electrical-repair-dubai") }}
      />
      <ServicePageTemplate slug="electrical-repair-dubai" />
    </>
  );
}
