import { buildServiceMetadata, buildServiceJsonLd } from "@/lib/service-seo";
import { ServicePageTemplate } from "@/components/site/ServicePageTemplate";

export const metadata = buildServiceMetadata("ac-installation-dubai");

export default function ACInstallationPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: buildServiceJsonLd("ac-installation-dubai") }}
      />
      <ServicePageTemplate slug="ac-installation-dubai" />
    </>
  );
}
