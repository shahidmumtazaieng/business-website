import type { Metadata } from "next";
import Link from "next/link";
import { Phone, MessageCircle, ArrowRight, Check } from "lucide-react";
import { BUSINESS, SERVICES } from "@/lib/site-data";
import { InnerHero } from "@/components/site/InnerHero";
import { ServicesGrid } from "@/components/site/RelatedServices";
import { CTASection } from "@/components/site/CTASection";
import { Reveal } from "@/components/site/Reveal";

export const metadata: Metadata = {
  title: "AC & Electrical Services in Dubai",
  description:
    "Full range of AC repair, AC installation, AC maintenance, electrical repair, electrical installation and 24/7 emergency services across Dubai. Certified technicians, genuine parts, 12-month warranty.",
  alternates: { canonical: "https://dubaichillpros.com/services" },
  openGraph: {
    title: "AC & Electrical Services in Dubai | Dubai Chill Pros",
    description:
      "Same-day licensed AC repair, installation, maintenance & electrical services across Dubai. Certified technicians, transparent pricing, 24/7 emergency support.",
    url: "https://dubaichillpros.com/services",
  },
};

const servicesSchema = {
  "@context": "https://schema.org",
  "@type": "ItemList",
  itemListElement: SERVICES.map((s, idx) => ({
    "@type": "ListItem",
    position: idx + 1,
    name: s.title,
    url: `https://dubaichillpros.com${s.url}`,
  })),
};

export default function ServicesHubPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(servicesSchema) }}
      />

      <InnerHero
        eyebrow="Our Services"
        title="AC & Electrical Services in Dubai — All Under One Roof"
        subtitle="From a single faulty capacitor to a full villa rewire, Dubai Chill Pros is your single point of contact for every cooling and electrical need. Certified technicians, genuine spare parts, transparent pricing and a 12-month workmanship warranty on every job."
        image="/images/hero-ac-technician.png"
        imageAlt="Dubai Chill Pros certified HVAC technician servicing AC condenser unit"
        breadcrumbItems={[{ label: "Services" }]}
        badge="12-month workmanship warranty"
      />

      {/* Intro + services grid */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <Reveal className="max-w-3xl mb-12">
            <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              Complete AC & Electrical Coverage
            </p>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              Six core services. One certified team.
            </h2>
            <p className="mt-4 text-muted-foreground text-base md:text-lg leading-relaxed">
              Most Dubai properties have both cooling and electrical systems that
              need certified, licensed attention. Instead of juggling three
              different contractors — an AC guy, an electrician, an installer —
              Dubai Chill Pros handles all six core services below under one
              workmanship warranty, one phone number and one point of contact.
              Click any service below to see exactly what&rsquo;s included, common
              problems we fix, FAQs and pricing.
            </p>
          </Reveal>

          <ServicesGrid />
        </div>
      </section>

      {/* Why one team is better */}
      <section className="py-16 md:py-20 bg-navy-dark text-white relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 bg-grid-navy opacity-50" />
        <div aria-hidden className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-ice/15 blur-3xl" />
        <div className="relative mx-auto max-w-[1280px] px-4 md:px-8">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-14 items-center">
            <Reveal>
              <p className="text-ice font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
                Why One Team Is Better
              </p>
              <h2 className="font-display font-extrabold text-3xl md:text-4xl tracking-tight leading-[1.1]">
                When your AC trips the breaker, who do you call?
              </h2>
              <p className="mt-4 text-white/75 text-base md:text-lg leading-relaxed">
                Most AC faults have an electrical cause. Most electrical faults
                in Dubai involve an AC unit. With a single-team provider like
                Dubai Chill Pros, one certified technician arrives, diagnoses both
                sides of the fault, and fixes it permanently — no finger-pointing
                between two contractors, no second call-out fee, no waiting for
                the &ldquo;other guy&rdquo; to be available.
              </p>
              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <a
                  href={BUSINESS.phoneHref}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber hover:bg-amber-dark text-navy px-6 py-3.5 text-sm font-bold shadow-amber-glow transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  {BUSINESS.phoneDisplay}
                </a>
                <a
                  href={BUSINESS.whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-whatsapp hover:bg-whatsapp-dark text-white px-6 py-3.5 text-sm font-bold transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp
                </a>
              </div>
            </Reveal>

            <Reveal delay={120}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { title: "Single phone number", text: "One call. One coordinator. One warranty. No finger-pointing between contractors." },
                  { title: "Single visit, both systems", text: "AC + electrical diagnosis in one visit — most faults are fixed same day." },
                  { title: "Single compliance report", text: "DEWA + HVAC compliance in one document. Insurance-friendly." },
                  { title: "Single relationship", text: "Same technician learns your property. Same coordinator remembers your history." },
                ].map((item, i) => (
                  <div
                    key={i}
                    className="rounded-2xl bg-white/5 border border-white/10 p-5 hover:bg-white/8 transition-colors"
                  >
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-ice/20 border border-ice/40 text-ice flex items-center justify-center">
                        <Check className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="font-display font-bold text-white text-sm leading-tight">
                          {item.title}
                        </h3>
                        <p className="mt-1.5 text-xs text-white/70 leading-relaxed">
                          {item.text}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <CTASection
        eyebrow="Not Sure Which Service You Need?"
        title="Call us. We'll diagnose over the phone — free."
        description="Tell us the symptom: 'AC not cooling', 'breaker tripping', 'burning smell', 'need a new unit'. Our coordinator will route you to the right certified technician and give you an honest ETA. No obligation, no call-out fee for the phone consult."
      />
    </>
  );
}
