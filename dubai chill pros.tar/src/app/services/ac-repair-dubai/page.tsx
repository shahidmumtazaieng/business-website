import { buildServiceMetadata, buildServiceJsonLd } from "@/lib/service-seo";
import { ServicePageTemplate } from "@/components/site/ServicePageTemplate";

export const metadata = buildServiceMetadata("ac-repair-dubai");

export default function ACRepairPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: buildServiceJsonLd("ac-repair-dubai") }}
      />
      <ServicePageTemplate slug="ac-repair-dubai" />
    </>
  );
}
