import { buildServiceMetadata, buildServiceJsonLd } from "@/lib/service-seo";
import { ServicePageTemplate } from "@/components/site/ServicePageTemplate";

export const metadata = buildServiceMetadata("electrical-installation-dubai");

export default function ElectricalInstallationPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: buildServiceJsonLd("electrical-installation-dubai") }}
      />
      <ServicePageTemplate slug="electrical-installation-dubai" />
    </>
  );
}
