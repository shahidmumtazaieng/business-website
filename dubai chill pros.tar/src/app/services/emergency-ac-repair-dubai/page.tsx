import { buildServiceMetadata, buildServiceJsonLd } from "@/lib/service-seo";
import { ServicePageTemplate } from "@/components/site/ServicePageTemplate";

export const metadata = buildServiceMetadata("emergency-ac-repair-dubai");

export default function EmergencyACRepairPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: buildServiceJsonLd("emergency-ac-repair-dubai") }}
      />
      <ServicePageTemplate slug="emergency-ac-repair-dubai" />
    </>
  );
}
