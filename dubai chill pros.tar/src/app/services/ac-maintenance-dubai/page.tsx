import { buildServiceMetadata, buildServiceJsonLd } from "@/lib/service-seo";
import { ServicePageTemplate } from "@/components/site/ServicePageTemplate";

export const metadata = buildServiceMetadata("ac-maintenance-dubai");

export default function ACMaintenancePage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: buildServiceJsonLd("ac-maintenance-dubai") }}
      />
      <ServicePageTemplate slug="ac-maintenance-dubai" />
    </>
  );
}
