import type { Metadata, Viewport } from "next";
import { Inter, Sora } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { FloatingButtons } from "@/components/site/FloatingButtons";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const sora = Sora({
  variable: "--font-sora",
  subsets: ["latin"],
  weight: ["500", "600", "700", "800"],
  display: "swap",
});

const SITE_URL = "https://dubaichillpros.com";
const SITE_NAME = "Dubai Chill Pros";
const PHONE = "+971551663574";
const EMAIL = "basarali512m@gmail.com";
const ADDRESS = "W Cluster, Jumeirah Lakes Towers, Dubai, UAE";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "AC Repair & Electrical Services in Dubai | Dubai Chill Pros",
    template: "%s | Dubai Chill Pros",
  },
  description:
    "Dubai's #1 licensed AC repair & electrical services company. Same-day AC installation, maintenance & emergency electrical repairs across JLT, Marina, Downtown & all Dubai areas. Certified technicians, transparent pricing. Call +971 55 166 3574.",
  keywords: [
    "AC repair Dubai",
    "AC maintenance Dubai",
    "AC installation Dubai",
    "electrical services Dubai",
    "electrician Dubai",
    "emergency AC repair Dubai",
    "HVAC Dubai",
    "air conditioning service Dubai",
    "AC servicing JLT",
    "split AC repair Dubai",
    "duct AC repair Dubai",
    "chiller repair Dubai",
    "electrical panel repair Dubai",
    "lighting installation Dubai",
    "AC technician Dubai",
    "Jumeirah Lakes Towers AC repair",
    "Dubai Marina AC service",
    "Downtown Dubai electrician",
  ],
  authors: [{ name: "Dubai Chill Pros" }],
  creator: "Dubai Chill Pros",
  publisher: "Dubai Chill Pros",
  alternates: {
    canonical: SITE_URL,
  },
  category: "Home Services",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  icons: {
    icon: "/logo.svg",
    apple: "/logo.svg",
  },
  openGraph: {
    title: "AC Repair & Electrical Services in Dubai | Dubai Chill Pros",
    description:
      "Same-day licensed AC repair, installation & electrical services across Dubai. Certified technicians, transparent pricing, 24/7 emergency support.",
    url: SITE_URL,
    siteName: SITE_NAME,
    images: [
      {
        url: "/images/hero-ac-technician.png",
        width: 1344,
        height: 768,
        alt: "Dubai Chill Pros HVAC technician servicing AC unit",
      },
    ],
    locale: "en_AE",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "AC Repair & Electrical Services in Dubai | Dubai Chill Pros",
    description:
      "Same-day licensed AC repair & electrical services across Dubai. Call +971 55 166 3574.",
    images: ["/images/hero-ac-technician.png"],
  },
  other: {
    "geo.region": "AE-DU",
    "geo.placename": "Dubai",
    "geo.position": "25.0705;55.1395",
    ICBM: "25.0705, 55.1395",
    "theme-color": "#0A1B2E",
  },
};

export const viewport: Viewport = {
  themeColor: "#0A1B2E",
  width: "device-width",
  initialScale: 1,
};

const localBusinessSchema = {
  "@context": "https://schema.org",
  "@type": ["HVACBusiness", "Electrician"],
  "@id": `${SITE_URL}/#business`,
  name: SITE_NAME,
  alternateName: "DubaiChillPros",
  description:
    "Licensed AC repair, AC installation, AC maintenance and electrical services company serving all of Dubai. Same-day service, certified technicians, transparent pricing.",
  url: SITE_URL,
  telephone: PHONE,
  email: EMAIL,
  image: `${SITE_URL}/images/hero-ac-technician.png`,
  logo: `${SITE_URL}/logo.svg`,
  priceRange: "$$",
  currenciesAccepted: "AED",
  paymentAccepted: "Cash, Credit Card, Bank Transfer",
  address: {
    "@type": "PostalAddress",
    streetAddress: "W Cluster, Jumeirah Lakes Towers",
    addressLocality: "Dubai",
    addressRegion: "Dubai",
    addressCountry: "AE",
    postalCode: "00000",
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: 25.0705,
    longitude: 55.1395,
  },
  areaServed: [
    { "@type": "City", name: "Dubai" },
    { "@type": "AdministrativeArea", name: "Jumeirah Lakes Towers" },
    { "@type": "AdministrativeArea", name: "Dubai Marina" },
    { "@type": "AdministrativeArea", name: "Downtown Dubai" },
    { "@type": "AdministrativeArea", name: "Jumeirah" },
    { "@type": "AdministrativeArea", name: "Business Bay" },
    { "@type": "AdministrativeArea", name: "Palm Jumeirah" },
    { "@type": "AdministrativeArea", name: "Al Barsha" },
    { "@type": "AdministrativeArea", name: "Deira" },
    { "@type": "AdministrativeArea", name: "Bur Dubai" },
  ],
  openingHoursSpecification: [
    {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
      ],
      opens: "00:00",
      closes: "23:59",
    },
  ],
  sameAs: [],
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: "4.9",
    reviewCount: "327",
    bestRating: "5",
    worstRating: "1",
  },
};

const breadcrumbSchema = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "Home",
      item: SITE_URL,
    },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
        />
      </head>
      <body
        className={`${inter.variable} ${sora.variable} font-sans antialiased bg-background text-foreground`}
      >
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
        </div>
        <FloatingButtons />
        <Toaster />
      </body>
    </html>
  );
}
