import type { Metadata } from "next";
import Link from "next/link";
import { HelpCircle, Phone, MessageCircle, ArrowRight } from "lucide-react";
import { BUSINESS, FAQS, SERVICES } from "@/lib/site-data";
import { InnerHero } from "@/components/site/InnerHero";
import { CTASection } from "@/components/site/CTASection";
import { Reveal } from "@/components/site/Reveal";

export const metadata: Metadata = {
  title: "AC & Electrical Services FAQ in Dubai",
  description:
    "Answers to the most common questions about AC repair, AC installation, AC maintenance, electrical services and emergency response in Dubai. Pricing, response times, warranties, brands serviced, AMC plans.",
  alternates: { canonical: "https://dubaichillpros.com/faq" },
  openGraph: {
    title: "AC & Electrical Services FAQ in Dubai | Dubai Chill Pros",
    description:
      "Detailed answers about AC repair, electrical services, pricing, response times, warranties and AMC contracts in Dubai.",
    url: "https://dubaichillpros.com/faq",
  },
};

const fullFaqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: FAQS.map((f) => ({
    "@type": "Question",
    name: f.q,
    acceptedAnswer: {
      "@type": "Answer",
      text: f.a,
    },
  })),
};

export default function FAQPage() {
  const categories = Array.from(new Set(FAQS.map((f) => f.category)));

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(fullFaqSchema) }}
      />

      <InnerHero
        eyebrow="Frequently Asked Questions"
        title="AC & Electrical Questions — Answered by Certified Technicians"
        subtitle="Real answers from our certified HVAC technicians and licensed electricians, for Dubai homeowners, tenants and property managers. Still unsure? Call us — we're happy to help."
        image="/images/electrician-panel.png"
        imageAlt="Dubai Chill Pros electrician explaining an electrical panel to a customer"
        breadcrumbItems={[{ label: "FAQ" }]}
        badge="12 categories · 24/7 phone support"
      />

      {/* Category navigation */}
      <section className="py-8 bg-muted/40 border-b border-border">
        <div className="mx-auto max-w-[1080px] px-4 md:px-8">
          <div className="flex flex-wrap items-center gap-2 justify-center">
            {categories.map((cat) => (
              <a
                key={cat}
                href={`#category-${cat.toLowerCase().replace(/[^a-z]+/g, "-")}`}
                className="inline-flex items-center gap-1.5 rounded-full bg-white border border-border px-3.5 py-1.5 text-xs font-bold text-navy hover:border-ice/40 hover:bg-ice/8 transition-colors"
              >
                <HelpCircle className="w-3 h-3 text-ice-dark" />
                {cat}
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ by category */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1080px] px-4 md:px-8 space-y-12">
          {categories.map((category) => {
            const catFaqs = FAQS.filter((f) => f.category === category);
            const catId = `category-${category.toLowerCase().replace(/[^a-z]+/g, "-")}`;
            return (
              <div key={category} id={catId} className="scroll-mt-28">
                <Reveal>
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-xl bg-ice/12 text-ice-dark flex items-center justify-center">
                      <HelpCircle className="w-5 h-5" />
                    </div>
                    <h2 className="font-display font-extrabold text-navy text-2xl md:text-3xl tracking-tight">
                      {category}
                    </h2>
                  </div>
                </Reveal>

                <div className="space-y-3">
                  {catFaqs.map((faq, idx) => (
                    <Reveal key={idx} delay={idx * 30}>
                      <details className="group rounded-2xl bg-white border border-border shadow-brand-sm overflow-hidden hover:shadow-brand-md transition-shadow">
                        <summary className="px-5 md:px-6 py-5 cursor-pointer list-none flex items-start justify-between gap-4 hover:bg-muted/30 transition-colors">
                          <span className="font-display font-bold text-navy text-base md:text-lg pr-4">
                            {faq.q}
                          </span>
                          <ArrowRight className="w-5 h-5 text-ice-dark flex-shrink-0 mt-1 group-open:rotate-90 transition-transform" />
                        </summary>
                        <div className="px-5 md:px-6 pb-5 text-sm md:text-[15px] text-muted-foreground leading-relaxed">
                          {faq.a}
                        </div>
                      </details>
                    </Reveal>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Service-specific FAQ teaser */}
      <section className="py-16 md:py-20 bg-muted/40 relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 bg-grid-frost opacity-50" />
        <div className="relative mx-auto max-w-[1080px] px-4 md:px-8">
          <Reveal className="text-center max-w-2xl mx-auto mb-10">
            <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              Service-Specific FAQs
            </p>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              Looking for answers about a specific service?
            </h2>
            <p className="mt-4 text-muted-foreground text-base leading-relaxed">
              Each of our service pages has its own dedicated FAQ section —
              answering questions about pricing, process, brands serviced and
              warranty specific to that service.
            </p>
          </Reveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {SERVICES.map((s, idx) => (
              <Reveal key={s.url} delay={idx * 40}>
                <Link
                  href={s.url}
                  className="group flex items-center gap-3 rounded-2xl bg-white border border-border p-5 hover:border-ice/40 hover:shadow-brand-md hover:-translate-y-1 transition-all"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-display font-bold text-navy text-sm leading-tight group-hover:text-ice-dark transition-colors">
                      {s.title}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      See FAQs &amp; pricing
                    </p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-ice-dark group-hover:translate-x-0.5 transition-all flex-shrink-0" />
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <CTASection
        eyebrow="Still Have A Question?"
        title="Speak to a real certified technician — free."
        description="No call centre, no answering service, no 'please hold'. Call +971 55 166 3574 and a real Dubai-based HVAC tech or licensed electrician answers — 24/7, 365 days a year."
      />
    </>
  );
}
