import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { MapPin, Clock, Phone, MessageCircle, ArrowRight, Check, Building2, Home as HomeIcon, Store } from "lucide-react";
import { BUSINESS, SERVICE_AREAS, SERVICES } from "@/lib/site-data";
import { InnerHero } from "@/components/site/InnerHero";
import { CTASection } from "@/components/site/CTASection";
import { Reveal } from "@/components/site/Reveal";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "AC & Electrical Service Areas in Dubai",
  description:
    "Dubai Chill Pros serves all of Dubai from Jumeirah Lakes Towers — JLT, Marina, Downtown, Jumeirah, Palm Jumeirah, Business Bay, Arabian Ranches, Dubai Hills + 10 more communities. 45–90 min response, 24/7.",
  alternates: { canonical: "https://dubaichillpros.com/service-areas" },
  openGraph: {
    title: "AC & Electrical Service Areas in Dubai | Dubai Chill Pros",
    description:
      "Serving 18+ Dubai communities from JLT HQ. 45–90 minute response time, 24/7/365. JLT, Marina, Downtown, Palm Jumeirah, Business Bay, Arabian Ranches & more.",
    url: "https://dubaichillpros.com/service-areas",
  },
};

const areaSchema = {
  "@context": "https://schema.org",
  "@type": "Place",
  name: "Dubai",
  description:
    "Dubai Chill Pros provides AC repair, AC installation, AC maintenance and licensed electrical services across all of Dubai, UAE.",
  address: {
    "@type": "PostalAddress",
    addressLocality: "Dubai",
    addressCountry: "AE",
  },
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: BUSINESS.rating,
    reviewCount: BUSINESS.reviewCount,
  },
};

export default function ServiceAreasPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(areaSchema) }}
      />

      <InnerHero
        eyebrow="Service Areas"
        title="Serving Every Corner of Dubai — Within the Hour"
        subtitle="From our dispatch base at Jumeirah Lakes Towers, our certified AC and electrical technicians reach every Dubai community within 45–90 minutes. If your community isn't listed below, just call — if it's in Dubai, we're there."
        image="/images/dubai-jlt-skyline.png"
        imageAlt="Aerial view of Dubai Jumeirah Lakes Towers skyline at golden hour — Dubai Chill Pros dispatch HQ"
        breadcrumbItems={[{ label: "Service Areas" }]}
        badge={`45–90 min response · 18+ communities`}
      />

      {/* Areas grid */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <Reveal className="max-w-3xl mb-12">
            <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              Communities We Serve
            </p>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              18+ Dubai communities — and counting
            </h2>
            <p className="mt-4 text-muted-foreground text-base md:text-lg leading-relaxed">
              Below are the Dubai communities we most commonly serve, with
              typical response times from our JLT dispatch base. Don&rsquo;t see
              your area? Call us — if you&rsquo;re in Dubai, we&rsquo;ll come to
              you.
            </p>
          </Reveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {SERVICE_AREAS.map((area, idx) => (
              <Reveal key={area.name} delay={idx * 30}>
                <Link
                  href="/contact"
                  className={cn(
                    "group block rounded-2xl border p-5 transition-all hover:-translate-y-1",
                    area.type === "HQ"
                      ? "bg-navy text-white border-navy"
                      : "bg-white border-border hover:border-ice/40 hover:shadow-brand-md"
                  )}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div
                        className={cn(
                          "w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0",
                          area.type === "HQ"
                            ? "bg-amber text-navy"
                            : "bg-ice/12 text-ice-dark group-hover:bg-ice group-hover:text-white"
                        )}
                      >
                        <MapPin className="w-5 h-5" />
                      </div>
                      <div>
                        <p className={cn(
                          "font-display font-bold text-base leading-tight",
                          area.type === "HQ" ? "text-white" : "text-navy"
                        )}>
                          {area.name}
                        </p>
                        <p className={cn(
                          "text-xs mt-0.5",
                          area.type === "HQ" ? "text-amber" : "text-muted-foreground"
                        )}>
                          {area.type === "HQ" ? "Our dispatch HQ" : `~${area.type} away`}
                        </p>
                      </div>
                    </div>
                    {area.type === "HQ" && (
                      <span className="rounded-full bg-amber text-navy px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">
                        HQ
                      </span>
                    )}
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>

          {/* CTA strip */}
          <Reveal className="mt-10">
            <div className="rounded-2xl bg-gradient-to-r from-ice/10 to-amber/8 border border-ice/30 p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-5">
              <div className="text-center md:text-left">
                <h3 className="font-display font-bold text-navy text-xl">
                  Don&rsquo;t see your area listed?
                </h3>
                <p className="text-sm text-muted-foreground mt-1.5">
                  If your community is in Dubai, we service it. Call us now and
                  we&rsquo;ll give you an honest ETA.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-2.5 flex-shrink-0">
                <a
                  href={BUSINESS.phoneHref}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber hover:bg-amber-dark text-navy px-5 py-3 text-sm font-bold shadow-amber-glow transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  Call now
                </a>
                <a
                  href={BUSINESS.whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-whatsapp hover:bg-whatsapp-dark text-white px-5 py-3 text-sm font-bold transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Property types */}
      <section className="py-16 md:py-20 bg-muted/40 relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 bg-grid-frost opacity-50" />
        <div className="relative mx-auto max-w-[1280px] px-4 md:px-8">
          <Reveal className="text-center max-w-2xl mx-auto mb-12">
            <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              Property Types We Service
            </p>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              From studio apartments to chiller-served buildings
            </h2>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {[
              {
                icon: HomeIcon,
                title: "Residential — Villas & Apartments",
                text: "Single split units, multi-unit ducted systems, full villa rewiring, EV chargers, smart lighting. From studios to 6-bedroom villas.",
                services: ["AC repair", "AC installation", "AMC", "Rewiring", "EV chargers"],
              },
              {
                icon: Building2,
                title: "Commercial — Offices & Retail",
                text: "Cassette AC systems, VRF/VRV, distribution boards, smart lighting, CCTV, access control. After-hours service for zero disruption.",
                services: ["VRF/VRV repair", "AMC contracts", "Fit-outs", "CCTV", "Compliance"],
              },
              {
                icon: Store,
                title: "Buildings & F&B",
                text: "Chiller plants, AHUs, FCUs, BMS, generators, full electrical infrastructure. Dedicated account manager and SLA.",
                services: ["Chiller plant", "BMS", "Generators", "SLA contracts", "Reports"],
              },
            ].map((pt, i) => (
              <Reveal key={i} delay={i * 80}>
                <article className="h-full rounded-2xl bg-white border border-border p-6 md:p-7 shadow-brand-sm">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-ice to-ice-dark text-white flex items-center justify-center mb-5">
                    <pt.icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-display font-bold text-navy text-lg md:text-xl leading-tight mb-2">
                    {pt.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                    {pt.text}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {pt.services.map((s) => (
                      <span
                        key={s}
                        className="inline-flex items-center gap-1 rounded-full bg-ice/10 text-ice-dark px-2.5 py-1 text-[11px] font-semibold"
                      >
                        <Check className="w-2.5 h-2.5" />
                        {s}
                      </span>
                    ))}
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Services we offer in these areas */}
      <section className="py-16 md:py-20 bg-background">
        <div className="mx-auto max-w-[1280px] px-4 md:px-8">
          <Reveal className="text-center max-w-2xl mx-auto mb-10">
            <p className="text-ice-dark font-bold uppercase tracking-[0.12em] text-xs md:text-sm mb-3">
              Services In Your Area
            </p>
            <h2 className="font-display font-extrabold text-navy text-3xl md:text-4xl tracking-tight">
              Whatever the AC or electrical need — we cover it
            </h2>
          </Reveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {SERVICES.map((s, idx) => (
              <Reveal key={s.url} delay={idx * 40}>
                <Link
                  href={s.url}
                  className="group flex items-start gap-3 rounded-2xl bg-white border border-border p-5 hover:border-ice/40 hover:shadow-brand-md hover:-translate-y-1 transition-all"
                >
                  <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-ice/12 text-ice-dark flex items-center justify-center group-hover:bg-ice group-hover:text-white transition-colors">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-display font-bold text-navy text-sm leading-tight group-hover:text-ice-dark transition-colors">
                      {s.title}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {s.short}
                    </p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-ice-dark group-hover:translate-x-0.5 transition-all flex-shrink-0 mt-1" />
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <CTASection
        eyebrow="Local Dubai Service"
        title="Your community is our neighbourhood."
        description={`We've been working in JLT, Dubai Marina, Downtown, Jumeirah, Palm Jumeirah and 13+ other Dubai communities since ${BUSINESS.founded}. Call us and we'll have a certified technician at your door within ${BUSINESS.responseTime}.`}
      />
    </>
  );
}
