import type { Metadata } from "next";
import { SERVICE_PAGES, type ServicePage, BUSINESS } from "@/lib/site-data";

const SITE_URL = "https://dubaichillpros.com";

/**
 * Build Next.js Metadata for a service detail page.
 */
export function buildServiceMetadata(slug: string): Metadata {
  const page: ServicePage | undefined = SERVICE_PAGES[slug];
  if (!page) throw new Error(`Unknown service slug: ${slug}`);

  // Strip the trailing "| Dubai Chill Pros" from the stored title to avoid
  // duplication with the layout's "%s | Dubai Chill Pros" template.
  const cleanTitle = page.metaTitle.replace(/\s*\|\s*Dubai Chill Pros\s*$/i, "");

  return {
    title: cleanTitle,
    description: page.metaDescription,
    keywords: page.keywords,
    alternates: { canonical: `${SITE_URL}${page.url}` },
    openGraph: {
      title: page.metaTitle,
      description: page.metaDescription,
      url: `${SITE_URL}${page.url}`,
      type: "article",
      images: [
        {
          url: page.heroImage,
          width: 1344,
          height: 768,
          alt: page.heroTitle,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: page.metaTitle,
      description: page.metaDescription,
      images: [page.heroImage],
    },
  };
}

/**
 * Build JSON-LD for a service detail page:
 *  - Service schema
 *  - BreadcrumbList
 *  - FAQPage
 */
export function buildServiceJsonLd(slug: string): string {
  const page: ServicePage | undefined = SERVICE_PAGES[slug];
  if (!page) throw new Error(`Unknown service slug: ${slug}`);

  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "@id": `${SITE_URL}${page.url}#service`,
    name: page.heroTitle.split(" — ")[0].split(" | ")[0],
    serviceType:
      page.category === "AC" ? "Air Conditioning Service" : "Electrical Service",
    description: page.metaDescription,
    url: `${SITE_URL}${page.url}`,
    image: `${SITE_URL}${page.heroImage}`,
    areaServed: { "@type": "City", name: "Dubai" },
    provider: {
      "@type": ["HVACBusiness", "Electrician"],
      name: BUSINESS.name,
      telephone: BUSINESS.phoneHref.replace("tel:", ""),
      url: SITE_URL,
    },
    offers: {
      "@type": "Offer",
      priceCurrency: "AED",
      availability: "https://schema.org/InStock",
      url: `${SITE_URL}${page.url}`,
    },
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: SITE_URL,
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Services",
        item: `${SITE_URL}/services`,
      },
      {
        "@type": "ListItem",
        position: 3,
        name: page.heroTitle.split(" — ")[0].split(" | ")[0],
        item: `${SITE_URL}${page.url}`,
      },
    ],
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: page.faqs.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: {
        "@type": "Answer",
        text: f.a,
      },
    })),
  };

  return JSON.stringify([serviceSchema, breadcrumbSchema, faqSchema]);
}
