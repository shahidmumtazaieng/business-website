// ============================================================
// Dubai Chill Pros — Central site data
// Multi-page SILO structure with full SEO content per service
// ============================================================

export const BUSINESS = {
  name: "Dubai Chill Pros",
  domain: "dubaichillpros.com",
  tagline: "AC Repair & Electrical Services in Dubai",
  phoneDisplay: "+971 55 166 3574",
  phoneHref: "tel:+971551663574",
  whatsappHref:
    "https://wa.me/971551663574?text=Hello%20Dubai%20Chill%20Pros%2C%20I%20need%20help%20with%20my%20AC%20%2F%20electrical%20service.",
  email: "basarali512m@gmail.com",
  addressLine: "W Cluster, Jumeirah Lakes Towers",
  addressCity: "Dubai, UAE",
  addressFull: "W Cluster, Jumeirah Lakes Towers, Dubai, UAE",
  hours: "Open 24/7 — 365 days a year",
  rating: 4.9,
  reviewCount: 327,
  yearsInBusiness: 12,
  responseTime: "45–90 min",
  jobsCompleted: "8,400+",
  certifiedTechs: 18,
  founded: 2013,
};

// ---------- Navigation ----------
export type NavItem = {
  label: string;
  href: string;
  children?: { label: string; href: string; description: string }[];
};

export const NAV: NavItem[] = [
  { label: "Home", href: "/" },
  {
    label: "Services",
    href: "/services",
    children: [
      {
        label: "AC Repair Dubai",
        href: "/services/ac-repair-dubai",
        description: "Same-day diagnostics & repair for any AC system.",
      },
      {
        label: "AC Installation Dubai",
        href: "/services/ac-installation-dubai",
        description: "Supply & fit split, ducted, cassette & VRF systems.",
      },
      {
        label: "AC Maintenance & AMC",
        href: "/services/ac-maintenance-dubai",
        description: "Annual contracts that cut DEWA bills & extend AC life.",
      },
      {
        label: "Electrical Repair Dubai",
        href: "/services/electrical-repair-dubai",
        description: "Licensed electricians for any fault, any time.",
      },
      {
        label: "Electrical Installation",
        href: "/services/electrical-installation-dubai",
        description: "Rewiring, lighting, EV chargers & smart home.",
      },
      {
        label: "24/7 Emergency Service",
        href: "/services/emergency-ac-repair-dubai",
        description: "AC down at 2 AM? We're en route across Dubai.",
      },
    ],
  },
  { label: "Service Areas", href: "/service-areas" },
  { label: "Pricing", href: "/pricing" },
  { label: "Reviews", href: "/reviews" },
  { label: "About", href: "/about" },
  { label: "FAQ", href: "/faq" },
  { label: "Contact", href: "/contact" },
];

// ---------- Compact service list (for cards) ----------
export type ServiceSummary = {
  slug: string;
  url: string;
  icon: "ac" | "install" | "maintenance" | "electric" | "wiring" | "emergency";
  title: string;
  short: string;
  description: string;
  bullets: string[];
  popular?: boolean;
  category: "AC" | "Electrical";
};

export const SERVICES: ServiceSummary[] = [
  {
    slug: "ac-repair-dubai",
    url: "/services/ac-repair-dubai",
    icon: "ac",
    title: "AC Repair Dubai",
    short: "Same-day diagnostics & repair",
    description:
      "When your AC stops cooling, leaks water, makes strange noises or trips the breaker, our certified HVAC technicians reach your door anywhere in Dubai within 45–90 minutes. We carry genuine spare parts for Daikin, LG, Samsung, Carrier, Trane, York, Gree, Midea, Super General and all major brands — so most repairs are completed in a single visit.",
    bullets: [
      "Split, duct, cassette & chiller AC systems",
      "Compressor, capacitor & fan motor replacement",
      "Refrigerant gas top-up (R410A, R32, R22)",
      "Thermostat & PCB board repair",
    ],
    popular: true,
    category: "AC",
  },
  {
    slug: "ac-installation-dubai",
    url: "/services/ac-installation-dubai",
    icon: "install",
    title: "AC Installation Dubai",
    short: "New units supplied & fitted",
    description:
      "Buying a new air conditioner? We supply, deliver and install split, ducted, cassette and floor-standing AC units across Dubai — including duct fabrication, electrical connection, gas charging and final commissioning. Every installation is signed off by a Dubai Municipality-approved technician and includes a 12-month workmanship warranty plus the manufacturer's warranty.",
    bullets: [
      "Free site survey & load calculation",
      "All major brands supplied at trade prices",
      "Duct fabrication & bracket fabrication",
      "12-month installation warranty",
    ],
    category: "AC",
  },
  {
    slug: "ac-maintenance-dubai",
    url: "/services/ac-maintenance-dubai",
    icon: "maintenance",
    title: "AC Maintenance & AMC",
    short: "Annual contracts that cut bills",
    description:
      "A clogged AC filter can raise your DEWA bill by up to 25%. Our scheduled AC maintenance and annual contracts (AMC) keep every unit in your villa, apartment or office running at peak efficiency — with deep coil cleaning, filter replacement, gas top-up, drain flushing and a full 21-point performance check. Choose quarterly, bi-annual or monthly plans.",
    bullets: [
      "21-point performance inspection",
      "Coil & filter deep cleaning",
      "Drain line flushing & sanitisation",
      "Priority emergency response",
    ],
    popular: true,
    category: "AC",
  },
  {
    slug: "electrical-repair-dubai",
    url: "/services/electrical-repair-dubai",
    icon: "electric",
    title: "Electrical Repair Dubai",
    short: "Licensed electricians on call",
    description:
      "From a tripping MCB to a burning smell from your distribution board, our licensed electricians handle every residential and commercial electrical fault in Dubai. We follow DEWA regulations, use only certified cables and components, and issue a compliance report on every job — protecting your property, your tenants and your insurance.",
    bullets: [
      "Distribution board & MCB/RCD repair",
      "Short circuit & earth fault tracing",
      "Socket, switch & lighting repair",
      "DEWA-compliant wiring upgrades",
    ],
    category: "Electrical",
  },
  {
    slug: "electrical-installation-dubai",
    url: "/services/electrical-installation-dubai",
    icon: "wiring",
    title: "Electrical Installation",
    short: "Wiring, lighting & EV chargers",
    description:
      "Building, renovating or upgrading? Dubai Chill Pros delivers turnkey electrical installation for villas, apartments, offices, retail and F&B — from full rewiring and smart-home lighting to EV charger points, generator hookups and surge protection. Every circuit is load-tested before sign-off.",
    bullets: [
      "Villa & apartment full rewiring",
      "Smart lighting & dimmer systems",
      "EV charger & generator installation",
      "CCTV, intercom & access control",
    ],
    category: "Electrical",
  },
  {
    slug: "emergency-ac-repair-dubai",
    url: "/services/emergency-ac-repair-dubai",
    icon: "emergency",
    title: "24/7 Emergency Service",
    short: "AC down at 2 AM? We're en route",
    description:
      "Dubai summers wait for no one. Our 24/7 emergency AC and electrical team is on standby every night, every weekend and every public holiday — including Eid. When your AC fails during a heatwave or your distribution board trips at midnight, one call to +971 55 166 3574 dispatches the nearest certified technician. We arrive in fully-stocked vans and aim to restore comfort within 60 minutes.",
    bullets: [
      "24/7/365 emergency dispatch",
      "60-minute average response",
      "Stocked vans — most fixes done first visit",
      "Transparent night-rate pricing",
    ],
    popular: true,
    category: "AC",
  },
];

// ---------- Full service page content (for individual service pages) ----------
export type ServicePage = {
  slug: string;
  url: string;
  category: "AC" | "Electrical";
  icon: "ac" | "install" | "maintenance" | "electric" | "wiring" | "emergency";
  heroImage: string;
  heroBadge: string;
  heroTitle: string;
  heroSubtitle: string;
  metaTitle: string;
  metaDescription: string;
  keywords: string[];
  intro: string[];
  subServicesTitle: string;
  subServices: { title: string; description: string; icon?: string }[];
  commonProblems?: { symptom: string; cause: string; fix: string }[];
  whyChooseUs: { title: string; description: string }[];
  processSteps: { num: string; title: string; description: string }[];
  brands?: string[];
  faqs: { q: string; a: string }[];
  relatedServiceSlugs: string[];
};

export const SERVICE_PAGES: Record<string, ServicePage> = {
  "ac-repair-dubai": {
    slug: "ac-repair-dubai",
    url: "/services/ac-repair-dubai",
    category: "AC",
    icon: "ac",
    heroImage: "/images/hero-ac-technician.png",
    heroBadge: "Same-day AC repair across Dubai",
    heroTitle: "AC Repair Dubai — Same-Day Service, Genuine Parts, Real Warranty",
    heroSubtitle:
      "When your air conditioner stops cooling in the middle of a Dubai summer, every minute counts. Our certified HVAC technicians reach your home, office or shop anywhere in Dubai within 45–90 minutes, diagnose the fault, and complete most repairs in a single visit using genuine spare parts.",
    metaTitle: "AC Repair Dubai | Same-Day Certified HVAC Technicians | Dubai Chill Pros",
    metaDescription:
      "Dubai's #1 AC repair service. Same-day certified HVAC technicians for split, duct, cassette & chiller AC. Genuine spare parts, transparent pricing, 12-month workmanship warranty. Call +971 55 166 3574.",
    keywords: [
      "AC repair Dubai",
      "AC repair near me Dubai",
      "split AC repair Dubai",
      "duct AC repair Dubai",
      "cassette AC repair Dubai",
      "AC not cooling Dubai",
      "AC gas top-up Dubai",
      "AC compressor repair Dubai",
      "AC technician Dubai",
      "air conditioner repair Dubai",
      "HVAC repair Dubai",
      "AC leakage repair Dubai",
    ],
    intro: [
      "Dubai's climate pushes every air conditioner to its limit for at least eight months of the year. When a single component fails — a capacitor, a fan motor, a refrigerant line, a thermostat sensor — your entire comfort collapses within hours. That's why Dubai Chill Pros built the city's most responsive AC repair service: certified technicians, fully-stocked vans, genuine spare parts and a 45–90 minute average response time across every Dubai community.",
      "We don't just patch symptoms. Every AC repair begins with a full system diagnosis — we test compressor amperage, refrigerant pressure, coil temperature differential, condensate drainage, electrical connections and thermostat accuracy before recommending any work. You receive a written, itemised quote, and no repair begins until you approve. That's how we've completed over 8,400 AC repairs across Dubai since 2013 with a 4.9-star average rating.",
    ],
    subServicesTitle: "AC Systems We Repair in Dubai",
    subServices: [
      {
        title: "Split AC Repair",
        description:
          "Wall-mounted, floor-standing and inverter split units from 1 ton to 4 ton capacity. Common fixes include indoor PCB replacement, fan motor swap, evaporator coil cleaning, refrigerant leak detection and gas top-up.",
      },
      {
        title: "Duct AC Repair",
        description:
          "Concealed ducted systems with AHU and FCU components. We repair blowers, condensate pumps, duct dampers, zone motors and digital thermostats — and re-seal leaking ductwork that wastes cooled air.",
      },
      {
        title: "Cassette AC Repair",
        description:
          "Ceiling cassettes from Daikin, LG, Samsung, Carrier and Gree. We service the condensate tray, drain pan, swing motor, refrigerant lines and the indoor coil — restoring even 360° airflow.",
      },
      {
        title: "Chiller & VRF/VRV Repair",
        description:
          "Building-level chiller plants and Daikin VRV / Mitsubishi VRF systems. Our senior technicians handle compressor change-outs, refrigerant management, BMS integration and full plant performance audits.",
      },
      {
        title: "Refrigerant Gas Top-Up & Leak Repair",
        description:
          "R410A, R32 and R22 systems. We pressure-test for leaks, weld or replace the leaking line, vacuum the system, then recharge to manufacturer spec — not just a top-up that leaks again in a month.",
      },
      {
        title: "AC Electrical Fault Repair",
        description:
          "Tripping MCB, burnt capacitor, failed contactor, thermostat fault, sensor drift, control board failure — our HVAC techs are also DEWA-certified for the low-voltage side of your AC system.",
      },
    ],
    commonProblems: [
      {
        symptom: "AC is running but not cooling",
        cause:
          "Low refrigerant from a slow leak, a failed capacitor preventing the compressor from starting, a clogged condenser coil rejecting no heat, or a stuck reversing valve.",
        fix:
          "Full pressure test, leak detection, refrigerant recharge to spec, capacitor and compressor amperage test, deep coil clean. Most resolved same visit.",
      },
      {
        symptom: "Water dripping from indoor unit",
        cause:
          "Blocked condensate drain line, cracked drain pan, frozen evaporator coil melting rapidly, or incorrectly mounted indoor unit (out of level).",
        fix:
          "Drain line flush with compressed nitrogen, drain pan repair or replacement, coil defrost and clean, level correction. We also treat the drain with anti-fungal tablets.",
      },
      {
        symptom: "Strange noises — grinding, squealing, rattling",
        cause:
          "Worn fan motor bearings, loose fan blade, debris in the condenser, failing compressor, or a cracked blower wheel.",
        fix:
          "Bearing replacement or full motor swap, blade balancing, debris removal, compressor health check. We carry motors for all major brands in our vans.",
      },
      {
        symptom: "AC trips the electricity breaker",
        cause:
          "Shorted compressor winding, grounded fan motor, failed run capacitor, or moisture in the electrical compartment.",
        fix:
          "Megger test on compressor and motor, capacitor swap, wiring dry-out, breaker sizing check. Permanent fix — not just resetting the breaker.",
      },
      {
        symptom: "Bad smell when AC is on",
        cause:
          "Mould and bacteria on the evaporator coil, dead matter in the drain pan, or burnt insulation on a failing component.",
        fix:
          "Coil deep-clean with anti-microbial treatment, drain pan sanitisation, full electrical inspection. Optional UV-C lamp installation for permanent air quality.",
      },
      {
        symptom: "Ice forming on AC pipes or indoor coil",
        cause:
          "Severely low refrigerant, restricted airflow from a dirty filter, or a faulty expansion valve — ice is always a symptom, never the root cause.",
        fix:
          "Defrost cycle, refrigerant leak test, filter replacement, expansion valve inspection. We always identify the cause before recharging.",
      },
    ],
    whyChooseUs: [
      {
        title: "45–90 minute response across Dubai",
        description:
          "From our Jumeirah Lakes Towers dispatch base, we reach JLT, Marina, Downtown, Business Bay, Jumeirah, Palm Jumeirah and 12+ other communities within the hour — day or night.",
      },
      {
        title: "Genuine spare parts in every van",
        description:
          "We carry compressors, capacitors, fan motors, PCBs, contactors, thermostats and refrigerant for Daikin, LG, Samsung, Carrier, Trane, York, Gree, Midea and 7+ other brands — so 9 of 10 repairs are done first visit.",
      },
      {
        title: "Written quote before any work",
        description:
          "You approve every line item. No call-out surprises, no inflated spare-parts invoices, no upsell. The price you sign is the price you pay.",
      },
      {
        title: "12-month workmanship warranty",
        description:
          "Every AC repair is covered by our written warranty. If the same fault returns within 12 months due to our work, we fix it free — parts and labour.",
      },
    ],
    processSteps: [
      { num: "01", title: "Call or WhatsApp", description: "Tell us the symptom — not cooling, leaking, noisy, tripping — and we'll book the nearest slot." },
      { num: "02", title: "Full diagnosis & written quote", description: "Certified HVAC tech tests the full system, identifies the root cause, gives you an itemised fixed quote." },
      { num: "03", title: "Same-day repair", description: "Approve the quote and most repairs are completed the same visit using genuine spare parts from the van." },
      { num: "04", title: "Warranty & cleanup", description: "We clean the work area, issue a warranty card, and follow up to confirm everything is cooling perfectly." },
    ],
    brands: ["Daikin", "LG", "Samsung", "Carrier", "Trane", "York", "Gree", "Midea", "Super General", "Hisense", "Hitachi", "Panasonic", "Sharp", "Nikai", "Skyworth"],
    faqs: [
      {
        q: "How fast can you reach my home in Dubai for AC repair?",
        a: "Our average response time across Dubai is 45–90 minutes for standard calls and under 60 minutes for emergencies. We're based in Jumeirah Lakes Towers, so JLT, Dubai Marina, JBR, Downtown, Business Bay, DIFC and Jumeirah are typically 45 minutes away. Palm Jumeirah, Al Barsha and Deira average 60–75 minutes.",
      },
      {
        q: "How much does AC repair cost in Dubai?",
        a: "AC repair in Dubai typically starts from AED 150 for diagnostics and minor fixes (thermostat reset, filter clean, capacitor swap). Compressor replacement ranges from AED 900–2,400 depending on capacity. Gas top-up is AED 250–450. We always provide a transparent, written quote before any work begins — no hidden charges.",
      },
      {
        q: "Do you repair all AC brands used in Dubai?",
        a: "Yes. We service and install Daikin, LG, Samsung, Carrier, Trane, York, Gree, Midea, Super General, Hisense, Hitachi, Panasonic, Sharp, Nikai and Skyworth. Our vans carry common spare parts for all these brands, so 9 of 10 repairs are completed same visit.",
      },
      {
        q: "Is your AC repair work guaranteed?",
        a: "Every AC repair is covered by our 12-month workmanship warranty. If the same fault returns within 12 months due to our workmanship, we return and fix it free — parts and labour included. Spare parts carry the manufacturer's own warranty on top.",
      },
      {
        q: "Can you repair ducted AC and chiller systems in villas?",
        a: "Absolutely. We have a dedicated chiller and ducted AC team for villas, offices, retail and building-level HVAC. Services include chiller plant maintenance, duct cleaning and sealing, AHU servicing, FCU repair, VRF/VRV systems and BMS troubleshooting.",
      },
      {
        q: "What should I do before the technician arrives?",
        a: "Please keep the AC switched on if safe to do so (so the technician can observe the fault), clear access to the indoor and outdoor units, and have your building's parking permit ready if needed. If you smell burning or see sparking, switch the AC off at the breaker immediately and call us.",
      },
    ],
    relatedServiceSlugs: ["ac-maintenance-dubai", "ac-installation-dubai", "emergency-ac-repair-dubai"],
  },

  "ac-installation-dubai": {
    slug: "ac-installation-dubai",
    url: "/services/ac-installation-dubai",
    category: "AC",
    icon: "install",
    heroImage: "/images/ac-installation.png",
    heroBadge: "Supply, deliver, install & commission",
    heroTitle: "AC Installation Dubai — Done Right, Done Once, Done Warrantied",
    heroSubtitle:
      "Buying a new air conditioner in Dubai? We supply, deliver, install and commission split, ducted, cassette and floor-standing AC systems across Dubai — with free site survey, accurate load calculation, duct fabrication and a full 12-month workmanship warranty on every install.",
    metaTitle: "AC Installation Dubai | Split, Duct, Cassette & VRF | Dubai Chill Pros",
    metaDescription:
      "Professional AC installation in Dubai. We supply & install Daikin, LG, Samsung, Carrier, Gree & more. Free site survey, load calculation, 12-month warranty. Call +971 55 166 3574.",
    keywords: [
      "AC installation Dubai",
      "split AC installation Dubai",
      "ducted AC installation Dubai",
      "cassette AC installation Dubai",
      "AC supply and install Dubai",
      "inverter AC installation Dubai",
      "new AC installation Dubai",
      "AC replacement Dubai",
      "VRF VRV installation Dubai",
      "air conditioner installer Dubai",
    ],
    intro: [
      "An air conditioner in Dubai is not an appliance — it's infrastructure. A poorly installed AC will leak refrigerant within a year, trip breakers, cost you 20–30% more on your DEWA bill, and ultimately fail years before its rated lifespan. That's why Dubai Chill Pros treats every AC installation as an engineering project: free site survey, accurate heat-load calculation, certified refrigerant handling, pressure-tested brazing, vacuum drying, and full commissioning with a written performance report.",
      "We are authorised installers for Daikin, LG, Samsung, Carrier, Gree and Midea, and we supply every major brand at trade prices — usually 10–20% below retail. Whether you need a single 1.5-ton split for a studio apartment, eight concealed ducted units for a 5-bedroom villa, or a 30-ton VRF system for an office floor, our installation team delivers the same certified workmanship and 12-month workmanship warranty.",
    ],
    subServicesTitle: "AC Systems We Install in Dubai",
    subServices: [
      {
        title: "Split AC Installation",
        description:
          "Wall-mounted and floor-standing split systems from 1 ton to 4 ton. We mount the indoor unit on anti-vibration brackets, run refrigerant piping with brazed joints, install the condenser on a levelled outdoor pad, pressure-test, vacuum and commission.",
      },
      {
        title: "Ducted AC Installation",
        description:
          "Concealed ducted systems for villas and offices. We fabricate galvanised ductwork in our Al Quoz workshop, install ceiling-mounted AHU and FCU units, fit supply and return grilles, and balance airflow across every zone.",
      },
      {
        title: "Cassette AC Installation",
        description:
          "Ceiling cassettes for open-plan offices and retail spaces. We cut and frame the ceiling opening, suspend the unit on threaded rod, connect refrigerant and condensate lines, then install the decorative panel with 360° airflow.",
      },
      {
        title: "VRF / VRV System Installation",
        description:
          "Daikin VRV, Mitsubishi VRF, LG Multi V and Samsung DVM S systems for villas and commercial buildings. We design the outdoor/indoor unit matrix, run refrigerant branch piping, commission the BC controller and integrate with BMS.",
      },
      {
        title: "Chiller Plant Installation",
        description:
          "Air-cooled and water-cooled chillers for buildings. We handle the full mechanical installation — chiller, pumps, cooling tower, AHUs, FCUs, piping and BMS integration — with full commissioning and performance testing.",
      },
      {
        title: "AC Replacement & Relocation",
        description:
          "Remove and dispose of your old unit safely (we recover refrigerant for recycling), upgrade to a new inverter AC for energy savings, or relocate indoor/outdoor units during a renovation. Includes electrical upgrade if required.",
      },
    ],
    whyChooseUs: [
      {
        title: "Free site survey & heat-load calculation",
        description:
          "We don't guess. Our engineer visits, measures room volume, window orientation, insulation and occupancy, then sizes your AC properly. Undersized units burn out; oversized units short-cycle and waste energy.",
      },
      {
        title: "Trade-price supply on every major brand",
        description:
          "We supply Daikin, LG, Samsung, Carrier, Gree, Midea, Trane, York and more at trade prices — typically 10–20% below retail. We pass that saving to you with full manufacturer warranty intact.",
      },
      {
        title: "Certified refrigerant handling",
        description:
          "Every installation tech is certified for R410A and R32 refrigerant handling. We pressure-test with nitrogen, vacuum the system to 500 microns, and charge by weight — never by guesswork.",
      },
      {
        title: "12-month workmanship warranty",
        description:
          "On top of the manufacturer's warranty on the unit itself, we cover our installation work for 12 months. Any leak, vibration or electrical issue from our install — we fix free.",
      },
    ],
    processSteps: [
      { num: "01", title: "Free site survey", description: "Engineer visits, measures, recommends the right AC system and capacity for your space and budget." },
      { num: "02", title: "Fixed written quote", description: "Itemised quote covering equipment, materials, labour, bracket fabrication and disposal of old unit." },
      { num: "03", title: "Supply & schedule", description: "We order the unit at trade price, deliver to your door, and schedule the install at your convenience." },
      { num: "04", title: "Install & commission", description: "Certified tech installs, pressure-tests, vacuums, charges and commissioning. You get a performance report and warranty card." },
    ],
    brands: ["Daikin", "LG", "Samsung", "Carrier", "Gree", "Midea", "Trane", "York", "Hisense", "Hitachi", "Panasonic"],
    faqs: [
      {
        q: "How much does AC installation cost in Dubai?",
        a: "Standard split AC installation in Dubai starts from AED 450 per unit (bracket, piping up to 3m, electrical connection, vacuum and gas charge). Ducted and cassette installations are quoted per project after a free site survey. We always supply an itemised written quote before any work begins.",
      },
      {
        q: "Do you supply the AC unit or do I buy it myself?",
        a: "Either. We supply every major brand at trade prices (typically 10–20% below retail) with full manufacturer warranty, or we can install a unit you've already purchased. Our recommendation: let us supply — we handle warranty, delivery and any DOA replacement seamlessly.",
      },
      {
        q: "How long does an AC installation take?",
        a: "A standard split AC install takes 2–4 hours per unit. A 5-unit villa with ducted system takes 1–2 days. Full chiller plant installation for a building is a 2–4 week project. We always clean the work area before leaving.",
      },
      {
        q: "Do you remove and dispose of my old AC unit?",
        a: "Yes. We safely recover any remaining refrigerant (for environmental compliance), disconnect the old unit, remove it from site, and dispose of it responsibly. There's a small disposal fee, included in your quote.",
      },
      {
        q: "What warranty do I get on a new AC installation?",
        a: "Two warranties: the manufacturer's warranty on the unit itself (typically 5 years compressor, 1–2 years parts), plus our 12-month workmanship warranty on the installation. Any issue with our install work — leak, vibration, electrical fault — we fix free.",
      },
      {
        q: "Can you install a new AC system during a villa renovation?",
        a: "Absolutely — and we coordinate with your contractor. We can install concealed ducted systems before ceiling closure, run refrigerant piping during framing, and commission after fit-out. We also handle DEWA connection and final electrical certification.",
      },
    ],
    relatedServiceSlugs: ["ac-repair-dubai", "ac-maintenance-dubai", "electrical-installation-dubai"],
  },

  "ac-maintenance-dubai": {
    slug: "ac-maintenance-dubai",
    url: "/services/ac-maintenance-dubai",
    category: "AC",
    icon: "maintenance",
    heroImage: "/images/ac-maintenance.png",
    heroBadge: "Annual contracts that pay for themselves",
    heroTitle: "AC Maintenance Dubai — Lower Bills, Cleaner Air, Longer AC Life",
    heroSubtitle:
      "A clogged AC filter raises your DEWA bill by up to 25% and shortens your compressor's life by years. Our scheduled AC maintenance and annual contracts (AMC) keep every unit in your Dubai villa, apartment or office running at peak efficiency — backed by a 21-point inspection report.",
    metaTitle: "AC Maintenance Dubai | Annual AMC Contracts | Dubai Chill Pros",
    metaDescription:
      "Affordable AC maintenance & annual contracts (AMC) in Dubai. 21-point inspection, coil cleaning, filter replacement, gas top-up. Cut DEWA bills 15–25%. Call +971 55 166 3574.",
    keywords: [
      "AC maintenance Dubai",
      "AC service Dubai",
      "AC cleaning Dubai",
      "annual maintenance contract Dubai",
      "AMC Dubai",
      "AC filter cleaning Dubai",
      "coil cleaning Dubai",
      "AC servicing Dubai",
      "AC AMC Dubai",
      "preventive AC maintenance Dubai",
    ],
    intro: [
      "In Dubai's climate, your air conditioner runs harder and longer than almost any other appliance in your home. Dust from construction, salt from the coast, and sand from the desert coat your AC's condenser and evaporator coils month after month — insulating them, blocking airflow, and forcing the compressor to work overtime. A 1mm layer of dust on a coil cuts cooling efficiency by 20–25%, and your DEWA bill reflects it within a single billing cycle.",
      "Dubai Chill Pros' AC maintenance service removes that penalty. Our certified technicians perform a documented 21-point inspection on every unit, deep-clean the coils and drain pan, replace filters, top up refrigerant, flush condensate lines, sanitise the indoor coil with anti-microbial treatment, and verify performance against the manufacturer's specification. The result: lower DEWA bills, healthier indoor air, fewer breakdowns, and years of extra compressor life. Most clients see their maintenance contract pay for itself within the first quarter.",
    ],
    subServicesTitle: "What Our AC Maintenance Includes",
    subServices: [
      {
        title: "21-Point Performance Inspection",
        description:
          "Compressor amperage, refrigerant pressure, coil temperature differential, condensate flow, electrical connections, capacitor health, thermostat accuracy, fan speed, vibration, duct leakage — documented on every visit.",
      },
      {
        title: "Evaporator & Condenser Coil Deep Clean",
        description:
          "We use coil-specific detergents, low-pressure wash and soft brushes — never high-pressure water that bends fins. Coils come out spotless, restoring full heat-exchange capacity.",
      },
      {
        title: "Filter Cleaning & Replacement",
        description:
          "Reusable mesh filters are washed and sanitised; HEPA and electrostatic filters are replaced on schedule. We carry standard sizes for all major AC brands in our vans.",
      },
      {
        title: "Refrigerant Gas Top-Up & Leak Test",
        description:
          "We pressure-test for slow leaks before topping up. If we find a leak, we flag it — never just keep topping up gas that leaks out. R410A, R32 and R22 systems all handled.",
      },
      {
        title: "Drain Line Flushing & Sanitising",
        description:
          "We blow out the condensate line with compressed nitrogen, then treat with anti-fungal tablets to prevent the mould and slime that cause ceiling stains and water damage.",
      },
      {
        title: "Electrical Connection Torque Check",
        description:
          "Loose terminals cause overheating and fires. We re-torque every connection on the contactor, capacitor and compressor, and inspect the insulation for heat damage.",
      },
    ],
    whyChooseUs: [
      {
        title: "Documented 21-point report on every visit",
        description:
          "You don't have to take our word for it. Every maintenance visit ends with a written report showing every reading, every fix and every recommendation — with photos on request.",
      },
      {
        title: "15–25% lower DEWA bills, guaranteed",
        description:
          "If your DEWA bill doesn't drop within the first quarter of your AMC, we'll refund that quarter. We're that confident in the difference a proper deep clean makes.",
      },
      {
        title: "Priority emergency response for AMC clients",
        description:
          "AMC clients skip the queue. If your AC breaks down during a Dubai summer heatwave, you're first in the dispatch book — guaranteed response under 60 minutes.",
      },
      {
        title: "Discounted spare parts & labour",
        description:
          "AMC clients get 15% off all spare parts and 10% off any labour outside the contract scope. No markup on emergency callouts either.",
      },
    ],
    processSteps: [
      { num: "01", title: "Free AC audit", description: "We audit every unit on your property, document age and condition, and recommend the right AMC tier (quarterly, bi-annual, monthly)." },
      { num: "02", title: "Schedule visits", description: "We agree a 12-month visit schedule that suits your tenants and occupancy. Same technician visits each time — they learn your units." },
      { num: "03", title: "Documented maintenance", description: "On each visit we run the full 21-point inspection, deep clean, top up gas if needed, and email you a report within 24 hours." },
      { num: "04", title: "Priority support", description: "Between visits, call us any time — your AMC puts you at the front of the queue. We monitor your AC's health year-round." },
    ],
    brands: ["Daikin", "LG", "Samsung", "Carrier", "Trane", "York", "Gree", "Midea", "Super General", "Hisense", "Hitachi", "Panasonic"],
    faqs: [
      {
        q: "How often should I service my AC in Dubai?",
        a: "Dubai's dusty, coastal climate means AC units need professional maintenance every 3–6 months, depending on location. Properties near construction sites or the beach need quarterly service. Our AMC plans are quarterly (most popular for villas), bi-annual (apartments), or monthly (commercial buildings).",
      },
      {
        q: "How much does AC maintenance cost in Dubai?",
        a: "A one-off AC service in Dubai starts from AED 199 per split unit (deep clean + filter + gas check). Our annual AMC starts from AED 699 per AC unit per year, which includes 4 visits and saves you 30% versus paying per visit. Commercial buildings are quoted per project.",
      },
      {
        q: "Will AC maintenance really lower my DEWA bill?",
        a: "Yes — typically by 15–25%. A 1mm dust layer on your coils cuts efficiency by 20–25%, forcing the compressor to run longer to reach the same temperature. Cleaning coils, replacing filters and topping up refrigerant restores full efficiency. Most AMC clients recover the contract cost within one quarter.",
      },
      {
        q: "What's the difference between AC cleaning and AC maintenance?",
        a: "AC cleaning is a basic service that washes filters and wipes the coil. AC maintenance is a full preventive service: 21-point inspection, deep coil clean, drain flush, gas top-up, electrical torque check, refrigerant pressure test and a documented report. Cleaning is a quick fix; maintenance prevents breakdowns.",
      },
      {
        q: "Do you service commercial buildings and offices?",
        a: "Yes. We have a commercial AC maintenance team for offices, retail, F&B, schools and residential buildings. We handle chiller plants, AHUs, FCUs, VRF/VRV systems and BMS monitoring. Contracts include monthly visits, 4-hour emergency SLA and dedicated account manager.",
      },
      {
        q: "What happens if my AC breaks down between maintenance visits?",
        a: "AMC clients get priority emergency response — typically under 60 minutes across Dubai, 24/7. We carry common spare parts in our vans, so most breakdowns are fixed same visit. AMC clients also get 15% off any spare parts and 10% off any out-of-scope labour.",
      },
    ],
    relatedServiceSlugs: ["ac-repair-dubai", "ac-installation-dubai", "emergency-ac-repair-dubai"],
  },

  "electrical-repair-dubai": {
    slug: "electrical-repair-dubai",
    url: "/services/electrical-repair-dubai",
    category: "Electrical",
    icon: "electric",
    heroImage: "/images/electrician-panel.png",
    heroBadge: "Licensed DEWA-certified electricians",
    heroTitle: "Electrical Repair Dubai — Licensed Electricians, DEWA-Compliant, 24/7",
    heroSubtitle:
      "From a tripping MCB to a burning smell at your distribution board, our licensed electricians handle every residential and commercial electrical fault in Dubai. We follow DEWA regulations, use certified components, and issue a compliance report on every job.",
    metaTitle: "Electrical Repair Dubai | Licensed Electricians 24/7 | Dubai Chill Pros",
    metaDescription:
      "Licensed electricians in Dubai for tripping MCB, short circuit, distribution board repair, sockets, switches & lighting. DEWA-compliant, 24/7 emergency. Call +971 55 166 3574.",
    keywords: [
      "electrical repair Dubai",
      "electrician Dubai",
      "electrical fault Dubai",
      "MCB tripping Dubai",
      "short circuit repair Dubai",
      "distribution board repair Dubai",
      "electrical emergency Dubai",
      "24 hour electrician Dubai",
      "DEWA certified electrician",
      "socket switch repair Dubai",
    ],
    intro: [
      "Electrical faults in Dubai are not just an inconvenience — they're a safety hazard. The combination of high ambient temperatures, dust ingress, humidity from coastal air, and aging building stock means that distribution boards, MCBs, sockets and lighting circuits fail more often here than in cooler climates. A single loose connection at a terminal block can overheat, arc, and start a fire behind your wall within minutes. That's why Dubai Chill Pros employs only DEWA-approved, certified electricians and follows DEWA regulations on every repair — large or small.",
      "Whether you have a single socket that's stopped working, an RCD that trips every time you switch on the water heater, or a distribution board that's making a buzzing sound at 11 PM, our electricians respond within 45–90 minutes anywhere in Dubai. We carry insulated tools, calibrated multimeters, certified cables, MCBs, RCDs, sockets and switches in every van — so 9 of 10 electrical repairs are completed in a single visit, with a compliance report.",
    ],
    subServicesTitle: "Electrical Faults We Repair in Dubai",
    subServices: [
      {
        title: "Distribution Board Repair",
        description:
          "Tripping main switch, burnt busbar, failed RCD, overloaded MCB, wrong-size breaker, missing earthing. We replace, upgrade and re-certify your DB to DEWA standards.",
      },
      {
        title: "MCB & RCD Tripping Faults",
        description:
          "We don't just reset the breaker. We trace the fault — neutral-earth short, appliance leakage, overloaded circuit, faulty RCD — and fix the root cause so it stays fixed.",
      },
      {
        title: "Short Circuit & Earth Fault Tracing",
        description:
          "Using insulation resistance testing and circuit tracing, we locate the fault behind your wall — without ripping out plaster. We repair, re-insulate and re-test.",
      },
      {
        title: "Socket, Switch & Lighting Repair",
        description:
          "Dead socket, broken switch, flickering light, dimmer that hums, LED driver failure, chandelier wiring. Fast, clean, certified repairs for every brand and fitting.",
      },
      {
        title: "Water Heater & Appliance Wiring",
        description:
          "We install and repair dedicated circuits for water heaters, washing machines, dishwashers, ovens and AC units — with the right MCB, RCD and cable size for each load.",
      },
      {
        title: "DEWA Reconnection & Compliance",
        description:
          "DEWA disconnected your supply for non-compliance? We issue the rectification report, fix the non-compliant work, and arrange reconnection — usually within 24 hours.",
      },
    ],
    commonProblems: [
      {
        symptom: "MCB trips every time I switch on a specific appliance",
        cause:
          "Either the appliance has an earth leakage fault (common with old water heaters, washing machines, ACs), or the MCB is undersized for the load.",
        fix:
          "Megger test on the appliance and circuit, MCB sizing check, RCD sensitivity test. We isolate the fault and recommend either appliance repair, cable upgrade, or breaker upgrade.",
      },
      {
        symptom: "RCD trips randomly with no obvious pattern",
        cause:
          "Cumulative earth leakage from multiple appliances on the circuit, moisture in an outdoor junction, degraded cable insulation, or a failing RCD itself.",
        fix:
          "Insulation resistance test on every circuit off the RCD, leakage current measurement, junction box inspection, RCD trip-time test. We identify and replace the faulty element.",
      },
      {
        symptom: "Burning smell from a socket or switch",
        cause:
          "Loose terminal connection causing arcing and overheating, overloaded socket (high-wattage appliance on a single point), or degraded insulation on old wiring.",
        fix:
          "Switch off the breaker immediately. We replace the damaged socket/switch, cut back the heat-damaged cable, re-terminate with the correct torque, and load-test the circuit.",
      },
      {
        symptom: "Buzzing sound from the distribution board",
        cause:
          "Loose busbar connection, failing contactor, overloaded breaker, or harmonic resonance from a cheap LED driver. All are fire risks and should be investigated immediately.",
        fix:
          "Power off, thermal imaging scan, torque check on every terminal, breaker load measurement, replacement of any overheating component. We then re-energise and re-check.",
      },
      {
        symptom: "Lights flicker when AC or washing machine starts",
        cause:
          "Voltage drop from an undersized cable, loose neutral connection, or a high inrush current appliance on a shared circuit.",
        fix:
          "Cable size verification, neutral integrity test, dedicated circuit recommendation for high-inrush appliances. We separate lighting from power circuits where required.",
      },
      {
        symptom: "No power to part of the property but main breaker is on",
        cause:
          "Tripped RCD/MCB that you haven't spotted, failed sub-circuit breaker, broken neutral, or a fault in the wiring between DB and the affected area.",
        fix:
          "Full circuit trace from DB to the dead zone, continuity and insulation test, breaker replacement if faulty, cable repair if damaged. We restore power safely and document the cause.",
      },
    ],
    whyChooseUs: [
      {
        title: "DEWA-approved, certified electricians only",
        description:
          "Every electrician on our team holds a Dubai Municipality electrical licence and DEWA approval. We follow DEWA regulations to the letter and issue a compliance report on every job.",
      },
      {
        title: "Fault-finding, not just resetting",
        description:
          "A tripped MCB is a symptom. We trace the root cause — insulation test, leakage measurement, thermal scan — and fix it. So the same fault doesn't trip again tomorrow.",
      },
      {
        title: "Certified components, calibrated tools",
        description:
          "We use only DEWA-approved cables, MCBs (Hager, ABB, Schneider, Legrand), RCDs and accessories. Our multimeters and insulation testers are calibrated annually.",
      },
      {
        title: "24/7 emergency electrical response",
        description:
          "Burning smell at midnight? Power out at 2 AM? Call +971 55 166 3574. Our emergency electricians are dispatched across Dubai within 45–90 minutes, every night of the year.",
      },
    ],
    processSteps: [
      { num: "01", title: "Call us with the symptom", description: "Tell us what's happening — tripping, sparking, smell, no power — and any safety concerns. We dispatch the nearest electrician." },
      { num: "02", title: "Diagnose & isolate", description: "Electrician arrives, isolates the faulty circuit, runs insulation and continuity tests, identifies the root cause." },
      { num: "03", title: "Written quote & repair", description: "You get an itemised quote covering certified parts and labour. Approve and the repair is done same visit in most cases." },
      { num: "04", title: "Compliance report", description: "We issue a compliance report on every job. Required for insurance, DEWA reconnection and property handover." },
    ],
    faqs: [
      {
        q: "How fast can an electrician reach my home in Dubai?",
        a: "Our average response time across Dubai is 45–90 minutes for standard calls and under 60 minutes for emergencies (burning smell, sparking, no power). We're based in Jumeirah Lakes Towers, so JLT, Marina, Downtown, Business Bay and Jumeirah are typically 45 minutes away.",
      },
      {
        q: "How much does an electrician cost in Dubai?",
        a: "An electrician call-out in Dubai starts from AED 150 (diagnostics + minor repair). Larger jobs like distribution board replacement or full circuit rewiring are quoted per project after inspection. We always provide a written, itemised quote before any work begins.",
      },
      {
        q: "Are your electricians licensed by DEWA?",
        a: "Yes. Every Dubai Chill Pros electrician holds a Dubai Municipality electrical licence and is DEWA-approved. We follow DEWA regulations on every job and issue a compliance report — required for insurance, DEWA reconnection and property handover.",
      },
      {
        q: "Can you help with a DEWA disconnection or compliance issue?",
        a: "Absolutely. If DEWA has disconnected your supply for non-compliance, we issue the rectification report, fix the non-compliant work, and arrange reconnection with DEWA — usually within 24 hours. We handle residential and commercial properties.",
      },
      {
        q: "Do you handle electrical emergencies at night?",
        a: "Yes. Dubai Chill Pros offers 24/7 emergency electrical repair across Dubai. Burning smell, sparking, smoke or no power — call +971 55 166 3574 and an electrician is dispatched immediately. For active electrical fires, call 997 first.",
      },
      {
        q: "Do you issue a compliance report for the work?",
        a: "Yes, on every job. Our compliance report covers the work done, the certified components used, test results (insulation, continuity, polarity, earth fault loop impedance), and the electrician's signature and licence number. Required for property handover, insurance and DEWA.",
      },
    ],
    relatedServiceSlugs: ["electrical-installation-dubai", "emergency-ac-repair-dubai", "ac-repair-dubai"],
  },

  "electrical-installation-dubai": {
    slug: "electrical-installation-dubai",
    url: "/services/electrical-installation-dubai",
    category: "Electrical",
    icon: "wiring",
    heroImage: "/images/electrician-panel.png",
    heroBadge: "Turnkey electrical installation",
    heroTitle: "Electrical Installation Dubai — Villas, Offices & Smart Homes, Done DEWA-Compliant",
    heroSubtitle:
      "Building, renovating or upgrading? Dubai Chill Pros delivers turnkey electrical installation for villas, apartments, offices, retail and F&B — from full rewiring and smart-home lighting to EV chargers, generators and surge protection. Every circuit is load-tested before sign-off.",
    metaTitle: "Electrical Installation Dubai | Rewiring, Lighting, EV Charger | Dubai Chill Pros",
    metaDescription:
      "Turnkey electrical installation in Dubai. Villa & apartment rewiring, smart lighting, EV chargers, generators, CCTV. DEWA-compliant. 12-month warranty. Call +971 55 166 3574.",
    keywords: [
      "electrical installation Dubai",
      "villa rewiring Dubai",
      "apartment rewiring Dubai",
      "EV charger installation Dubai",
      "smart home lighting Dubai",
      "generator installation Dubai",
      "CCTV installation Dubai",
      "surge protection Dubai",
      "electrical fit-out Dubai",
      "office electrical installation Dubai",
    ],
    intro: [
      "An electrical installation is the nervous system of your property. Get it right, and you have decades of safe, silent, reliable power. Get it wrong — undersized cables, wrong breaker ratings, cheap accessories, uncertified labour — and you get a lifetime of nuisance tripping, DEWA compliance issues, and a real fire risk. Dubai Chill Pros has been installing electrical systems in Dubai villas, apartments, offices and retail spaces since 2013, with a zero-tolerance policy on non-certified components and unlicensed labour.",
      "Every electrical installation we deliver follows the same engineering discipline: full load calculation, certified cable sizing (per DEWA and IEC standards), modular distribution board design, surge protection at the main incomer, dedicated circuits for high-wattage appliances, separate lighting and power circuits, full earthing and bonding, and a final certification test before handover. We coordinate with your contractor, your interior designer, DEWA, and your property management — so you don't have to.",
    ],
    subServicesTitle: "Electrical Installation Services in Dubai",
    subServices: [
      {
        title: "Villa & Apartment Full Rewiring",
        description:
          "Complete rewire of older Dubai properties — replace aging cables, upgrade the distribution board, install RCD protection on every circuit, dedicated circuits for kitchen and AC, full earthing upgrade. We work with your contractor during renovation.",
      },
      {
        title: "Smart Lighting & Home Automation",
        description:
          "Lutron, KNX, Control4, Siemens smart-home lighting systems. Dimmer control, scene setting, voice control, scheduling, mobile app control — wired into your distribution board the right way, with no flickering or humming.",
      },
      {
        title: "EV Charger Installation",
        description:
          "DEWA-approved EV charger points for villas and apartment parking — Tesla Wall Connector, ABB, Schneider, ChargePoint. We handle the load assessment, dedicated circuit, RCBO protection and DEWA certification.",
      },
      {
        title: "Generator Installation & Hookup",
        description:
          "Standby diesel generators (5 kVA to 500 kVA) with automatic transfer switch (ATS) for villas, offices and buildings. We handle the full mechanical and electrical install, fuel system, exhaust and commissioning.",
      },
      {
        title: "CCTV, Intercom & Access Control",
        description:
          "Hikvision, Dahua, Axis IP camera systems. Video intercom (Commax, Aiphone), access control (HID, Suprema), barrier systems. Full cabling, configuration and mobile app integration.",
      },
      {
        title: "Office & Retail Electrical Fit-Out",
        description:
          "Complete electrical fit-out for offices, retail and F&B — distribution board, lighting design, power outlets, server rack wiring, UPS, data cabling, signage supply. We coordinate with your fit-out contractor.",
      },
    ],
    whyChooseUs: [
      {
        title: "Certified cables, certified accessories, certified labour",
        description:
          "We use only DEWA-approved cables (Ducab, Draka), MCBs and distribution boards (Hager, ABB, Schneider, Legrand), sockets and switches (BG, MK, Schneider). Every electrician is licensed.",
      },
      {
        title: "Load calculation, not guesswork",
        description:
          "We size cables and breakers to IEC 60364 and DEWA regulations — based on actual connected load, demand factor, voltage drop and earth fault loop impedance. No undersized cables, no overloaded breakers.",
      },
      {
        title: "Coordination with your contractor & DEWA",
        description:
          "We work alongside your fit-out contractor, interior designer, MEP consultant and DEWA — attending site meetings, submitting drawings, scheduling inspections. One point of contact for you.",
      },
      {
        title: "12-month workmanship warranty + compliance report",
        description:
          "Every installation is covered by our workmanship warranty and signed off with a compliance report including test results. Required for insurance, DEWA final connection and property handover.",
      },
    ],
    processSteps: [
      { num: "01", title: "Site survey & load calculation", description: "Engineer visits, measures, calculates connected load, sizes cables and breakers to IEC/DEWA standards, recommends the right accessories." },
      { num: "02", title: "Fixed written quote & drawings", description: "Itemised quote covering cables, distribution board, accessories, labour, testing, certification. Single-line diagram and load schedule on request." },
      { num: "03", title: "Certified installation", description: "Licensed electricians install to DEWA regulations. We coordinate with your contractor, schedule DEWA inspections at each stage, and keep the site clean." },
      { num: "04", title: "Test, certify & handover", description: "Full electrical test (insulation, continuity, polarity, earth fault loop), compliance report, as-installed drawings, 12-month workmanship warranty." },
    ],
    brands: ["Hager", "ABB", "Schneider Electric", "Legrand", "Ducab", "Draka", "BG", "MK", "Lutron", "KNX", "Hikvision", "Tesla"],
    faqs: [
      {
        q: "How much does electrical installation cost in Dubai?",
        a: "A single new circuit (e.g. EV charger point) starts from AED 1,200 including dedicated RCBO, certified cable and DEWA certification. A full villa rewire ranges from AED 18,000–60,000 depending on size and specification. Office fit-outs are quoted per m². We always provide a written, itemised quote after a site survey.",
      },
      {
        q: "Do you handle DEWA inspections and final connection?",
        a: "Yes. We coordinate with DEWA at every stage — design approval, first-fix inspection, second-fix inspection, energisation. We submit the single-line diagram, load schedule, and test reports. You don't need to deal with DEWA directly.",
      },
      {
        q: "Can you install an EV charger at my villa in Dubai?",
        a: "Yes. We're DEWA-approved for EV charger installation. We install Tesla Wall Connector, ABB, Schneider, ChargePoint and DEWA's official Green Charger. The process: load assessment, dedicated circuit from your distribution board, RCBO protection, charger mount, DEWA certification — usually completed in one day.",
      },
      {
        q: "What brands do you use for switches, sockets and distribution boards?",
        a: "We use only DEWA-approved brands: Hager, ABB, Schneider Electric and Legrand for distribution boards and MCBs; Ducab and Draka for cables; BG, MK and Schneider for sockets and switches. We never use uncertified or no-name components — your insurance depends on it.",
      },
      {
        q: "Can you rewire my villa during a renovation?",
        a: "Absolutely — and we coordinate with your fit-out contractor. We do the first-fix (cables in walls, distribution board, back boxes) before plastering, and the second-fix (sockets, switches, light fittings, certification) after painting. We attend site meetings with your designer and DEWA.",
      },
      {
        q: "Do you install smart lighting and home automation systems?",
        a: "Yes. We're certified installers for Lutron, KNX, Control4 and Siemens smart-home systems. We design the lighting layout, install dimmable drivers, configure scenes and schedules, integrate with voice control (Alexa, Google, Siri), and train you on the mobile app.",
      },
    ],
    relatedServiceSlugs: ["electrical-repair-dubai", "ac-installation-dubai", "emergency-ac-repair-dubai"],
  },

  "emergency-ac-repair-dubai": {
    slug: "emergency-ac-repair-dubai",
    url: "/services/emergency-ac-repair-dubai",
    category: "AC",
    icon: "emergency",
    heroImage: "/images/emergency-service.png",
    heroBadge: "24/7/365 — average 60-minute response",
    heroTitle: "Emergency AC Repair Dubai — 24/7, 365 Days, 60-Minute Response",
    heroSubtitle:
      "Dubai summers wait for no one. When your AC fails during a heatwave at 2 AM, on a Friday night, or on Eid day, one call to +971 55 166 3574 dispatches the nearest certified technician. We arrive in fully-stocked vans and aim to restore comfort within 60 minutes.",
    metaTitle: "Emergency AC Repair Dubai | 24/7 HVAC Emergency Service | Dubai Chill Pros",
    metaDescription:
      "24/7 emergency AC repair in Dubai. AC breakdown at night? Certified technician at your door in 60 minutes. Stocked vans, transparent night rates. Call +971 55 166 3574 now.",
    keywords: [
      "emergency AC repair Dubai",
      "24 hour AC repair Dubai",
      "AC repair near me Dubai",
      "AC breakdown Dubai",
      "AC not cooling emergency Dubai",
      "emergency electrician Dubai",
      "AC repair Friday Dubai",
      "AC repair night Dubai",
      "urgent AC repair Dubai",
      "same day AC repair Dubai",
    ],
    intro: [
      "An AC breakdown in Dubai is not a comfort issue — it's a health and safety issue. Indoor temperatures can exceed 45°C within hours of an AC failure, especially in upper-floor apartments and villas with large glazing. Infants, elderly residents, pets and anyone with respiratory conditions can develop heat exhaustion within 3–4 hours. That's why Dubai Chill Pros operates a genuine 24/7/365 emergency AC and electrical service — not an answering service that calls you back in the morning, but a real certified technician dispatched to your door within 60 minutes, every night of the year.",
      "Our emergency response team is based at Jumeirah Lakes Towers and covers every community in Dubai. We staff the emergency line with real HVAC and electrical technicians, not call-centre agents. When you call +971 55 166 3574 at 3 AM with an AC that's stopped cooling, the person on the phone can diagnose the most likely cause, dispatch the nearest technician with the right spare parts, and give you an honest ETA — typically 45–90 minutes, anywhere in Dubai.",
    ],
    subServicesTitle: "When to Call Our 24/7 Emergency Team",
    subServices: [
      {
        title: "AC Completely Stops Cooling",
        description:
          "Especially during summer nights, weekends, or when you have infants, elderly or pets at home. Don't wait until morning — internal temperatures climb past 40°C within hours.",
      },
      {
        title: "Burning Smell from AC or Electrical Panel",
        description:
          "Switch off the breaker immediately and call us. Burning smell means overheating plastic insulation, often a precursor to fire. We dispatch an electrician-certified HVAC tech.",
      },
      {
        title: "Water Leaking from Indoor Unit",
        description:
          "Active water leak damaging your ceiling, walls, flooring or furniture. We isolate the unit, contain the leak, then repair the condensate drain or pump — fast.",
      },
      {
        title: "AC Tripping the Electricity Breaker",
        description:
          "Recurrent breaker trips mean an earth fault, compressor short, or moisture in the electrical compartment. Don't keep resetting the breaker — call us before it becomes a fire.",
      },
      {
        title: "Sparking, Smoke or Burning Sound",
        description:
          "If you see sparking or smoke from any AC unit, switch, socket or distribution board, call 997 (Dubai Civil Defence) first, then call us. We'll make safe and repair.",
      },
      {
        title: "Power Outage in Part of the Property",
        description:
          "No power to part of your villa or apartment while the main breaker is on. Our emergency electrician traces the fault and restores power — typically within 90 minutes.",
      },
    ],
    whyChooseUs: [
      {
        title: "Real technician answers the phone, 24/7",
        description:
          "No call centre, no answering service, no 'we'll call you back in the morning'. A real HVAC tech or electrician answers +971 55 166 3574 — every night, every weekend, every Eid.",
      },
      {
        title: "Average 60-minute response across Dubai",
        description:
          "Our Jumeirah Lakes Towers base puts every Dubai community within 45–90 minutes. JLT, Marina, Downtown, Business Bay and Jumeirah typically see a tech in under 45 minutes.",
      },
      {
        title: "Fully-stocked vans for first-visit fixes",
        description:
          "Our emergency vans carry compressors, capacitors, fan motors, PCBs, MCBs, RCDs, refrigerant and 30+ common spare parts — so 9 of 10 emergency calls are fixed same visit.",
      },
      {
        title: "Transparent night-rate pricing",
        description:
          "Yes, we charge a night-rate surcharge — every emergency service does. But we cap it (AED 100–150) and disclose it upfront before dispatch. No surprise invoices.",
      },
    ],
    processSteps: [
      { num: "01", title: "Call +971 55 166 3574", description: "Real technician answers. Describe the symptom. We assess urgency and dispatch the nearest stocked van." },
      { num: "02", title: "60-minute dispatch", description: "Certified HVAC tech or electrician arrives within 45–90 minutes anywhere in Dubai. We text you the tech's name and ETA." },
      { num: "03", title: "Stabilise & diagnose", description: "We make the situation safe, isolate the fault, run diagnostics, and give you a fixed written quote — including any night-rate surcharge." },
      { num: "04", title: "Repair & warranty", description: "Approve the quote and most emergency repairs are completed the same visit. We issue a warranty card and follow up the next day." },
    ],
    brands: ["Daikin", "LG", "Samsung", "Carrier", "Trane", "York", "Gree", "Midea", "Super General", "Hisense", "Hitachi", "Panasonic"],
    faqs: [
      {
        q: "Do you really answer the phone 24/7?",
        a: "Yes. A real HVAC technician or licensed electrician answers +971 55 166 3574 — every night, every weekend, every public holiday including Eid. We do not use a call centre or answering service. If your AC fails at 3 AM, you'll be speaking to a technician within 30 seconds.",
      },
      {
        q: "How fast can you reach me in Dubai?",
        a: "Average response time is 45–90 minutes anywhere in Dubai. JLT, Dubai Marina, JBR, Downtown, Business Bay, DIFC and Jumeirah typically see a tech in under 45 minutes. Palm Jumeirah, Al Barsha, Deira and Bur Dubai average 60–75 minutes.",
      },
      {
        q: "Is there an extra charge for night or weekend emergency service?",
        a: "Yes — a capped night-rate surcharge of AED 100–150 applies between 22:00 and 06:00, and on UAE public holidays. We disclose this upfront before dispatch, never on the invoice. Daytime weekend calls (Friday/Saturday 06:00–22:00) carry no surcharge.",
      },
      {
        q: "Can you fix the AC the same night, or just diagnose?",
        a: "Most emergency repairs are completed the same night. Our vans carry 30+ common spare parts — capacitors, fan motors, contactors, thermostats, PCBs, refrigerant, MCBs, RCDs. Compressor or PCB board replacements may need a next-day part delivery for less common brands.",
      },
      {
        q: "What should I do if I smell burning or see smoke?",
        a: "Switch off the AC and the relevant breaker at your distribution board immediately. If you see smoke or active sparking, call 997 (Dubai Civil Defence) first. Then call us. We'll dispatch an HVAC tech who is also a licensed electrician — they can make safe and repair both sides of the fault.",
      },
      {
        q: "Do you handle emergency electrical faults as well as AC?",
        a: "Yes. Dubai Chill Pros is a dual-licensed HVAC and electrical company. The same emergency team handles distribution board faults, tripping breakers, sparking sockets, no-power faults, water heater failures and any other residential or commercial electrical emergency — 24/7, across Dubai.",
      },
    ],
    relatedServiceSlugs: ["ac-repair-dubai", "electrical-repair-dubai", "ac-maintenance-dubai"],
  },
};

// ---------- Process (general, used on home) ----------
export const PROCESS = [
  {
    num: "01",
    title: "Call or WhatsApp",
    description:
      "Ring +971 55 166 3574 or message us on WhatsApp. Tell us the symptom — cooling issue, water leak, burning smell, no power — and we'll book the nearest available slot.",
  },
  {
    num: "02",
    title: "Free Diagnosis & Quote",
    description:
      "A certified technician arrives within 45–90 minutes, inspects the AC or electrical fault, and gives you a fixed, written quote. No work begins until you approve.",
  },
  {
    num: "03",
    title: "Same-Day Repair",
    description:
      "We carry genuine spare parts for every major brand in our vans, so 9 out of 10 repairs are completed the same visit — including compressors, PCBs, fans and capacitors.",
  },
  {
    num: "04",
    title: "Warranty & Cleanup",
    description:
      "Every job is covered by our workmanship warranty. We clean the work area, issue an invoice with a compliance report, and follow up to confirm everything is running perfectly.",
  },
];

// ---------- Service areas ----------
export type Area = { name: string; type: string };

export const SERVICE_AREAS: Area[] = [
  { name: "Jumeirah Lakes Towers", type: "HQ" },
  { name: "Dubai Marina", type: "5 min" },
  { name: "Jumeirah Beach Residence", type: "8 min" },
  { name: "Palm Jumeirah", type: "12 min" },
  { name: "Downtown Dubai", type: "15 min" },
  { name: "Business Bay", type: "10 min" },
  { name: "DIFC", type: "14 min" },
  { name: "Jumeirah", type: "12 min" },
  { name: "Umm Suqeim", type: "15 min" },
  { name: "Al Barsha", type: "18 min" },
  { name: "The Greens & Views", type: "6 min" },
  { name: "The Springs & Meadows", type: "9 min" },
  { name: "Arabian Ranches", type: "20 min" },
  { name: "Dubai Hills Estate", type: "18 min" },
  { name: "Mirdif", type: "25 min" },
  { name: "Deira", type: "22 min" },
  { name: "Bur Dubai", type: "18 min" },
  { name: "Al Quoz", type: "12 min" },
];

// ---------- Testimonials ----------
export type Testimonial = {
  name: string;
  area: string;
  service: string;
  rating: number;
  text: string;
  date?: string;
};

export const TESTIMONIALS: Testimonial[] = [
  {
    name: "Aisha Al Marri",
    area: "Jumeirah Lakes Towers",
    service: "Emergency AC Repair",
    rating: 5,
    date: "August 2025",
    text: "Our ducted AC died at 1 AM during the August heatwave. I called Dubai Chill Pros and a technician was at our door in under an hour. He diagnosed a faulty capacitor, replaced it on the spot, and we were cool again before 3 AM. Honest pricing, no upsell, true lifesavers.",
  },
  {
    name: "Rajesh Menon",
    area: "Dubai Marina",
    service: "AC Maintenance AMC",
    rating: 5,
    date: "July 2025",
    text: "Signed up for the annual AC maintenance contract for our 3-bedroom apartment. Quarterly visits, deep cleaning, and our DEWA bill actually dropped by AED 240 a month. Team is always punctual, professional and tidy.",
  },
  {
    name: "Sarah Williams",
    area: "Arabian Ranches",
    service: "Villa Rewiring",
    rating: 5,
    date: "June 2025",
    text: "We renovated our villa and needed full electrical rewiring plus a new distribution board. Dubai Chill Pros handled everything — DEWA coordination, smart lighting, EV charger install. The compliance report meant our insurance had no issues. Highly recommended.",
  },
  {
    name: "Mohammed Tariq",
    area: "Business Bay",
    service: "Office AC Servicing",
    rating: 5,
    date: "May 2025",
    text: "We run a 14-desk office and our tenants complained about cooling. The team serviced all four cassettes, recharged gas, and cleaned coils in one afternoon. Zero downtime, zero disruption. Now on a quarterly contract.",
  },
  {
    name: "Elena Petrova",
    area: "Palm Jumeirah",
    service: "Chiller AC Repair",
    rating: 5,
    date: "April 2025",
    text: "Other companies quoted us AED 4,800 for a chiller fault. Dubai Chill Pros found a blocked expansion valve, cleared it, and charged AED 950. That kind of honesty earns customers for life.",
  },
  {
    name: "Khalid Al Hashimi",
    area: "Dubai Hills Estate",
    service: "AC Installation",
    rating: 5,
    date: "March 2025",
    text: "Had three Daikin inverter units installed across our new villa. Spotless work, neat trunking, and the team explained every step. Got the manufacturer warranty paperwork plus their own 12-month workmanship cover.",
  },
  {
    name: "Priya Sharma",
    area: "Jumeirah",
    service: "Emergency Electrical",
    rating: 5,
    date: "February 2025",
    text: "Smell of burning from our distribution board at 11 PM. Called Dubai Chill Pros, electrician arrived in 50 minutes, isolated a burnt neutral connection, replaced the damaged busbar, and issued a compliance report the same night. Outstanding.",
  },
  {
    name: "James O'Connor",
    area: "The Springs",
    service: "AC Maintenance",
    rating: 5,
    date: "January 2025",
    text: "Booked a one-off deep clean before summer. Technician was on time, wore shoe covers, laid drop sheets, and the AC cooled noticeably better the next day. Will move to the AMC plan.",
  },
  {
    name: "Fatima Al Zaabi",
    area: "Downtown Dubai",
    service: "Smart Lighting Installation",
    rating: 5,
    date: "December 2024",
    text: "Installed Lutron smart lighting across our 4-bedroom apartment. The team handled the design, dimmer selection, app setup and even coordinated with our interior designer. Premium work, premium result.",
  },
];

// ---------- FAQ (general, used on home + /faq page) ----------
export const FAQS = [
  {
    category: "Service & Response",
    q: "How fast can Dubai Chill Pros reach my location in Dubai?",
    a: "Our average response time across Dubai is 45–90 minutes for standard calls and under 60 minutes for emergencies. We are based in Jumeirah Lakes Towers and dispatch the nearest certified technician to JLT, Dubai Marina, Downtown, Business Bay, Jumeirah, Palm Jumeirah, Al Barsha, Deira and Bur Dubai. For life-threatening electrical emergencies (smell of burning, sparking, smoke), call 997 first, then call us.",
  },
  {
    category: "Service & Response",
    q: "Are your AC and electrical technicians licensed and insured?",
    a: "Yes. Every Dubai Chill Pros technician is Dubai Municipality-approved, HVAC and electrical certified, fully insured and background-verified. We follow all UAE safety regulations, use only genuine spare parts and certified cables, and issue a written service warranty on every job.",
  },
  {
    category: "Pricing",
    q: "How much does AC repair cost in Dubai?",
    a: "AC repair in Dubai typically starts from AED 150 for diagnostics and minor fixes (thermostat reset, filter clean, capacitor swap). Compressor replacement ranges from AED 900–2,400 depending on capacity. Gas top-up is AED 250–450. Final pricing depends on the AC type (split, duct, cassette, chiller), the fault and the spare parts required. We always provide a transparent, upfront written quote before any work begins — no hidden charges, no surprise add-ons.",
  },
  {
    category: "Emergency",
    q: "Do you offer emergency AC repair in Dubai at night?",
    a: "Yes. Dubai Chill Pros offers 24/7 emergency AC and electrical repair across Dubai, every day of the year including Eid and public holidays. If your AC stops cooling at 2 AM in the middle of a Dubai summer, call +971 55 166 3574 and a certified technician will be dispatched immediately. Our night-rate surcharge is capped and disclosed upfront.",
  },
  {
    category: "Maintenance",
    q: "Do you provide annual AC maintenance contracts (AMC) in Dubai?",
    a: "Yes. We offer affordable annual AC maintenance contracts for villas, apartments, offices, retail shops and buildings in Dubai. AMC plans include scheduled cleaning (quarterly, bi-annual or monthly), filter replacement, gas top-up, drain flushing, a 21-point performance check, priority emergency response and discounted spare parts. Most clients see their DEWA bill drop 15–25% within the first quarter.",
  },
  {
    category: "Brands",
    q: "Which AC brands do you service in Dubai?",
    a: "We service and install every major brand sold in the UAE: Daikin, LG, Samsung, Carrier, Trane, York, Gree, Midea, Super General, Hisense, Hitachi, Panasonic, Sharp, Nikai, Skyworth and more. Our vans carry common spare parts for all of these brands, which is why most repairs are completed in a single visit.",
  },
  {
    category: "Commercial",
    q: "Do you handle chiller and ducted AC systems for villas and offices?",
    a: "Absolutely. We have a dedicated chiller and ducted AC team for villas, offices, retail and building-level HVAC. Services include chiller plant maintenance, duct cleaning and sealing, AHU servicing, FCU repair, VRF/VRV systems and Building Management System (BMS) troubleshooting. We also issue compliance reports for property management and insurance.",
  },
  {
    category: "Electrical",
    q: "What electrical services do you offer for homes and businesses?",
    a: "Our licensed electricians handle every residential and commercial electrical need in Dubai: distribution board upgrades, MCB/RCD trips, short circuits, earth faults, socket and switch replacement, indoor and outdoor lighting, dimmer and smart-home lighting, EV charger installation, generator hookup, surge protection, CCTV, intercom, access control, and full villa/apartment/office rewiring. All work is DEWA-compliant.",
  },
  {
    category: "Pricing",
    q: "Do you charge a call-out fee?",
    a: "Our standard call-out fee is AED 150, which includes travel to your location and a full diagnosis. This fee is waived if you proceed with the recommended repair. Emergency night-rate calls (22:00–06:00) carry an additional AED 100–150 surcharge, disclosed upfront before dispatch.",
  },
  {
    category: "Warranty",
    q: "What warranty do you offer on your work?",
    a: "Every repair and installation is covered by our 12-month workmanship warranty. If the same fault returns within 12 months due to our work, we return and fix it free — parts and labour included. Spare parts also carry the manufacturer's own warranty on top of ours.",
  },
  {
    category: "Service & Response",
    q: "Do you work on Fridays and public holidays?",
    a: "Yes. Dubai Chill Pros is open 24/7, 365 days a year — including Fridays, Saturdays, Sundays and every UAE public holiday (Eid, National Day, Ramadan hours, etc.). Emergency surcharges apply only between 22:00 and 06:00 and on public holidays; daytime weekend calls carry no surcharge.",
  },
  {
    category: "Commercial",
    q: "Can you service my office or retail shop during non-business hours?",
    a: "Absolutely. For commercial clients, we schedule maintenance and repairs outside your operating hours — early morning, late evening, overnight or weekend — to avoid any disruption to your business. AMC clients get priority scheduling.",
  },
];

// ---------- Pricing ----------
export type PricingTier = {
  name: string;
  price: string;
  unit: string;
  description: string;
  features: string[];
  highlight?: boolean;
  cta: string;
};

export const PRICING: PricingTier[] = [
  {
    name: "One-Off Service",
    price: "AED 150",
    unit: "diagnostic call-out",
    description:
      "For a single repair, gas top-up or inspection. Diagnostics fee is waived if you proceed with the repair.",
    features: [
      "45–90 min response across Dubai",
      "Full system diagnosis & written quote",
      "Genuine spare parts from major brands",
      "30-day workmanship warranty",
      "Compliance report on request",
    ],
    cta: "Book a call-out",
  },
  {
    name: "Annual AMC",
    price: "AED 699",
    unit: "per AC unit / year",
    description:
      "Best for villas and apartments. Keep every unit running at peak efficiency and skip emergency bills.",
    features: [
      "4 scheduled maintenance visits",
      "21-point performance inspection",
      "Coil & filter deep cleaning",
      "Refrigerant gas top-up included",
      "Priority emergency response",
      "15% off all spare parts",
    ],
    highlight: true,
    cta: "Start your AMC",
  },
  {
    name: "Commercial Contract",
    price: "Custom",
    unit: "tailored quote",
    description:
      "For offices, retail, F&B and buildings. Multi-unit SLAs with dedicated account manager.",
    features: [
      "Unlimited priority callouts",
      "Quarterly + on-demand visits",
      "Chiller, ducted, VRF/VRV systems",
      "BMS monitoring & reporting",
      "Dedicated account manager",
      "Monthly compliance reports",
    ],
    cta: "Request a quote",
  },
];

// ---------- Values (for About page) ----------
export const VALUES = [
  {
    title: "Honesty over upsell",
    description:
      "We don't get paid on commission. Our technicians are salaried, not incentivised to sell you a compressor you don't need. We diagnose, we explain, we quote — and we fix only what actually needs fixing.",
  },
  {
    title: "Certified, always",
    description:
      "Every technician on our team is Dubai Municipality-approved, HVAC and electrical certified, and background-verified. We follow DEWA regulations on every job, even when no one is looking.",
  },
  {
    title: "Genuine parts, every time",
    description:
      "We use only OEM and DEWA-approved spare parts and cables. No grey imports, no second-hand components, no shortcuts. Your warranty and your insurance depend on it.",
  },
  {
    title: "Fast, really fast",
    description:
      "Our Jumeirah Lakes Towers base puts every Dubai community within 45–90 minutes. We staff the emergency line with real technicians — 24/7, 365 days a year.",
  },
  {
    title: "Documented work",
    description:
      "Every job ends with a written report: what we found, what we did, what we tested, what we recommend. No 'trust me' — just paperwork that protects you.",
  },
  {
    title: "Local Dubai team",
    description:
      "We live here. We know your community, your building, your AC system, your DEWA process. When you call +971 55 166 3574, you're speaking to a neighbour, not a call centre.",
  },
];

export const STATS = [
  { value: "8,400+", label: "Jobs completed" },
  { value: "12", label: "Years in Dubai" },
  { value: "4.9★", label: "Average rating" },
  { value: "327", label: "Verified reviews" },
  { value: "18", label: "Certified techs" },
  { value: "45–90 min", label: "Response time" },
];
